---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
browsing marketplace ^yU1eIMRs

posting a product ^IqQW3aM2

checking a product listing ^Rkh9rNHg

searching for a product ^sbxp0Mtx

purchasing product ^jb2thj6Y

opened marketplace ^yc8T47Qt

closed marketplace / logged out ^mGDeeWKP

clicked on a product frame ^Kk2z4bDu

returned to marketplace  ^BkhYovdH

Clicked the "Post a product" button ^wQKCMjdU

posted the product / canceled ^58bu21Dx

opened the search bar  ^XZMB7KhF

searched a query / canceled ^lirFf2x6

clicked the "Buy" button ^llYrfcc5

purchased / canceled ^xeHpFM2P

adding attachment ^RocK5XwT

clicked the "Add attachment" button ^Xau8X8od

added attachment / canceled ^91VSRUP5

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "ellipse",
			"version": 463,
			"versionNonce": 1738326547,
			"isDeleted": false,
			"id": "TOcsssHGmm8nLqGFDEbV2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -362.4785467754262,
			"y": -297.27170954858093,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1372015667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "LJ2Uaw7daxLA_EVeGlNPL",
					"type": "arrow"
				}
			],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 875,
			"versionNonce": 2132171933,
			"isDeleted": false,
			"id": "HhdcyfoR90rZmFCyvJ6I6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -362.2774478125494,
			"y": -436.8728748509282,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1877488893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 730,
			"versionNonce": 1770063795,
			"isDeleted": false,
			"id": "3qOuJzQjSYjLd7un4_lqh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -381.44351730469117,
			"y": -453.46710759109664,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.62777420104499,
			"height": 75.37969110015035,
			"seed": 981260637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "DF_X6nK29I3o8ZXRN2KWg",
					"type": "arrow"
				}
			],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 317,
			"versionNonce": 817545469,
			"isDeleted": false,
			"id": "t_GKL3G2u2YfOIbJICIRE",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -28.703198131517638,
			"y": -314.4158580801691,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 364.787647586468,
			"height": 73.87274815039171,
			"seed": 968728115,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "LJ2Uaw7daxLA_EVeGlNPL",
					"type": "arrow"
				},
				{
					"id": "DF_X6nK29I3o8ZXRN2KWg",
					"type": "arrow"
				},
				{
					"id": "tnu4_FCY8OC6ZBX-_O6eB",
					"type": "arrow"
				},
				{
					"id": "KtCysRkLmqji2aUslj1JP",
					"type": "arrow"
				},
				{
					"id": "PrqzeU2f7ST_co92-YdTS",
					"type": "arrow"
				},
				{
					"id": "Bhs2S5lKtjHHvOatKAl9O",
					"type": "arrow"
				},
				{
					"id": "pnkoR6evglNiWgXl7YslK",
					"type": "arrow"
				},
				{
					"id": "7bvHAWZiLSmdqVPpz5UIB",
					"type": "arrow"
				}
			],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 287,
			"versionNonce": 1577818451,
			"isDeleted": false,
			"id": "yU1eIMRs",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 49.66181713951323,
			"y": -287.98438291503817,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 205,
			"height": 25,
			"seed": 470805021,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693575,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing marketplace",
			"rawText": "browsing marketplace",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing marketplace"
		},
		{
			"type": "rectangle",
			"version": 734,
			"versionNonce": 219388253,
			"isDeleted": false,
			"id": "TM5LOi9KD4rq_G4JZlLnw",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 784.4075954937318,
			"y": -498.5099804393899,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 291.0753415202448,
			"height": 73.87274815039171,
			"seed": 1485342835,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "KtCysRkLmqji2aUslj1JP",
					"type": "arrow"
				},
				{
					"id": "Bhs2S5lKtjHHvOatKAl9O",
					"type": "arrow"
				},
				{
					"id": "cVTaF8YJduQXhetY857x-",
					"type": "arrow"
				},
				{
					"id": "vSSc9MPoj96nQSH5K0LbC",
					"type": "arrow"
				}
			],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 670,
			"versionNonce": 848492275,
			"isDeleted": false,
			"id": "IqQW3aM2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 834.8365302169896,
			"y": -473.93971790779125,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 176,
			"height": 25,
			"seed": 947432509,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693575,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "posting a product",
			"rawText": "posting a product",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "posting a product"
		},
		{
			"type": "rectangle",
			"version": 610,
			"versionNonce": 762471869,
			"isDeleted": false,
			"id": "HbVMaRVEyZIBe9seMBqzp",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 752.4602228355045,
			"y": -315.65529549966527,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 364.787647586468,
			"height": 73.87274815039171,
			"seed": 595475805,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "tnu4_FCY8OC6ZBX-_O6eB",
					"type": "arrow"
				},
				{
					"id": "XAs5N1dNl9WqhZVHPHYfD",
					"type": "arrow"
				},
				{
					"id": "sAW4SciJhP58ZIc2qTvM7",
					"type": "arrow"
				},
				{
					"id": "7bvHAWZiLSmdqVPpz5UIB",
					"type": "arrow"
				}
			],
			"updated": 1676660693575,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 709,
			"versionNonce": 1704829075,
			"isDeleted": false,
			"id": "Rkh9rNHg",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 815.623032557371,
			"y": -290.2620712502296,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 249,
			"height": 25,
			"seed": 143954675,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "checking a product listing",
			"rawText": "checking a product listing",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "checking a product listing"
		},
		{
			"type": "rectangle",
			"version": 484,
			"versionNonce": 83404317,
			"isDeleted": false,
			"id": "YhtkNLGW5gaE6YsjAghMh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1097.604283028855,
			"y": -140.1339124493134,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 364.787647586468,
			"height": 73.87274815039171,
			"seed": 854071197,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "PrqzeU2f7ST_co92-YdTS",
					"type": "arrow"
				},
				{
					"id": "pnkoR6evglNiWgXl7YslK",
					"type": "arrow"
				}
			],
			"updated": 1676660693576,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 564,
			"versionNonce": 1625429555,
			"isDeleted": false,
			"id": "sbxp0Mtx",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1159.3566588655137,
			"y": -117.85557978768537,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 236,
			"height": 25,
			"seed": 1627159731,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "searching for a product",
			"rawText": "searching for a product",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "searching for a product"
		},
		{
			"type": "rectangle",
			"version": 640,
			"versionNonce": 647486077,
			"isDeleted": false,
			"id": "sdlexrGoI-z5SWvfNa_Se",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1452.304053333282,
			"y": -318.00137734780833,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 364.787647586468,
			"height": 73.87274815039171,
			"seed": 189824563,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "XAs5N1dNl9WqhZVHPHYfD",
					"type": "arrow"
				},
				{
					"id": "sAW4SciJhP58ZIc2qTvM7",
					"type": "arrow"
				}
			],
			"updated": 1676660693576,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 667,
			"versionNonce": 323409875,
			"isDeleted": false,
			"id": "jb2thj6Y",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1545.204997946212,
			"y": -293.6464734344288,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 183,
			"height": 25,
			"seed": 1856238205,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "purchasing product",
			"rawText": "purchasing product",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "purchasing product"
		},
		{
			"type": "arrow",
			"version": 109,
			"versionNonce": 1259438813,
			"isDeleted": false,
			"id": "LJ2Uaw7daxLA_EVeGlNPL",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -309.8719079434778,
			"y": -275.6212411275711,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 274.1110622586597,
			"height": 1.4037755831736263,
			"seed": 1198485405,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TOcsssHGmm8nLqGFDEbV2",
				"focus": 0.03235067529433428,
				"gap": 8.97202281912918
			},
			"endBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": 0.013618803933870539,
				"gap": 7.057647553300512
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					274.1110622586597,
					-1.4037755831736263
				]
			]
		},
		{
			"type": "text",
			"version": 37,
			"versionNonce": 1256351091,
			"isDeleted": false,
			"id": "yc8T47Qt",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -266.2599075274221,
			"y": -315.53027432232375,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 192,
			"height": 25,
			"seed": 1503202301,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened marketplace",
			"rawText": "opened marketplace",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened marketplace"
		},
		{
			"type": "arrow",
			"version": 99,
			"versionNonce": 385294141,
			"isDeleted": false,
			"id": "DF_X6nK29I3o8ZXRN2KWg",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 145.93896529252856,
			"y": -325.71941558808663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 436.07926866419075,
			"height": 93.44553277791204,
			"seed": 981660157,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": 0.1128352514897428,
				"gap": 11.303557507917589
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": -0.11160839827121449,
				"gap": 8.8084702237878
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-56.06728495656682,
					-87.21583637774802
				],
				[
					-436.07926866419075,
					-93.44553277791204
				]
			]
		},
		{
			"type": "text",
			"version": 128,
			"versionNonce": 1325088531,
			"isDeleted": false,
			"id": "mGDeeWKP",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -235.6856248924188,
			"y": -454.484427546751,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 320,
			"height": 25,
			"seed": 1307805427,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "closed marketplace / logged out",
			"rawText": "closed marketplace / logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "closed marketplace / logged out"
		},
		{
			"type": "arrow",
			"version": 315,
			"versionNonce": 548024221,
			"isDeleted": false,
			"id": "tnu4_FCY8OC6ZBX-_O6eB",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 340.0928809943187,
			"y": -294.52047112833094,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 398.6989938872877,
			"height": 5.169895538058256,
			"seed": 1649381491,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": -0.37223730363917146,
				"gap": 4.00843153936836
			},
			"endBinding": {
				"elementId": "HbVMaRVEyZIBe9seMBqzp",
				"focus": 0.5982924576492228,
				"gap": 13.668347953898092
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					398.6989938872877,
					-5.169895538058256
				]
			]
		},
		{
			"type": "text",
			"version": 120,
			"versionNonce": 973595827,
			"isDeleted": false,
			"id": "Kk2z4bDu",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 373.39871309146235,
			"y": -326.47148509178635,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 266,
			"height": 25,
			"seed": 1153898547,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "tnu4_FCY8OC6ZBX-_O6eB",
					"type": "arrow"
				}
			],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked on a product frame",
			"rawText": "clicked on a product frame",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked on a product frame"
		},
		{
			"type": "arrow",
			"version": 453,
			"versionNonce": 912012285,
			"isDeleted": false,
			"id": "KtCysRkLmqji2aUslj1JP",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 159.00673930911168,
			"y": -323.0360402863367,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 617.2815667791473,
			"height": 134.36580390366777,
			"seed": 404671155,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": -0.1760993604731187,
				"gap": 8.620182206167641
			},
			"endBinding": {
				"elementId": "TM5LOi9KD4rq_G4JZlLnw",
				"gap": 8.119289405472841,
				"focus": -0.027586010908183484
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					119.25746400233712,
					-124.40721803539196
				],
				[
					617.2815667791473,
					-134.36580390366777
				]
			]
		},
		{
			"type": "arrow",
			"version": 249,
			"versionNonce": 330225235,
			"isDeleted": false,
			"id": "PrqzeU2f7ST_co92-YdTS",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 153.93989854407135,
			"y": -230.62872371393962,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 933.883054125112,
			"height": 137.3551572715634,
			"seed": 436108893,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": 0.21940911688032688,
				"gap": 9.914386215837709
			},
			"endBinding": {
				"elementId": "YhtkNLGW5gaE6YsjAghMh",
				"focus": -0.37073838003383597,
				"gap": 9.781330359671642
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					117.0562186107964,
					112.6331740577013
				],
				[
					933.883054125112,
					137.3551572715634
				]
			]
		},
		{
			"type": "rectangle",
			"version": 144,
			"versionNonce": 1678683229,
			"isDeleted": false,
			"id": "p2mQxdhMrEYZz-9-gP1Uk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 693.4175920753933,
			"y": -570.5805358862741,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1139.7742132764654,
			"height": 564.2290578519387,
			"seed": 510748413,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 134,
			"versionNonce": 717657075,
			"isDeleted": false,
			"id": "6pjhlT--sZ0zPbjPabgWZ",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 693.8885045048903,
			"y": -201.1521201957206,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1135.9046023702335,
			"height": 1.4389077414999747,
			"seed": 1972187901,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1135.9046023702335,
					1.4389077414999747
				]
			]
		},
		{
			"type": "line",
			"version": 204,
			"versionNonce": 965941437,
			"isDeleted": false,
			"id": "reyKtyLHhrOhT47-HkJLe",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 693.8885045048903,
			"y": -363.5588997437612,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1137.34339700105,
			"height": 2.2847494328243556,
			"seed": 682257885,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1137.34339700105,
					2.2847494328243556
				]
			]
		},
		{
			"type": "arrow",
			"version": 405,
			"versionNonce": 794140051,
			"isDeleted": false,
			"id": "XAs5N1dNl9WqhZVHPHYfD",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1129.186732093666,
			"y": -303.3882270243365,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 315.9171322074485,
			"height": 1.790531079865275,
			"seed": 1780261757,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "HbVMaRVEyZIBe9seMBqzp",
				"focus": -0.6786998139733377,
				"gap": 11.93886167169353
			},
			"endBinding": {
				"elementId": "sdlexrGoI-z5SWvfNa_Se",
				"focus": 0.5124587452349312,
				"gap": 7.200189032167259
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					315.9171322074485,
					1.790531079865275
				]
			]
		},
		{
			"type": "arrow",
			"version": 427,
			"versionNonce": 1351285021,
			"isDeleted": false,
			"id": "Bhs2S5lKtjHHvOatKAl9O",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 775.4792906718457,
			"y": -431.2558749469755,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 588.8407603462264,
			"height": 107.59036275549704,
			"seed": 1232261203,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TM5LOi9KD4rq_G4JZlLnw",
				"gap": 8.928304821886172,
				"focus": -0.6430147266778521
			},
			"endBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": -0.1250432256630266,
				"gap": 9.249654111309411
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-460.8950594374186,
					12.202207599758424
				],
				[
					-588.8407603462264,
					107.59036275549704
				]
			]
		},
		{
			"type": "arrow",
			"version": 143,
			"versionNonce": 210924339,
			"isDeleted": false,
			"id": "pnkoR6evglNiWgXl7YslK",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1088.883221922545,
			"y": -119.90980414554599,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 905.6719303158864,
			"height": 111.22347058627008,
			"seed": 1389551517,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "YhtkNLGW5gaE6YsjAghMh",
				"focus": 0.27086930294628725,
				"gap": 8.721061106310003
			},
			"endBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": 0.1266440489079884,
				"gap": 9.409835197961257
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-793.148211698827,
					-22.118395465752258
				],
				[
					-905.6719303158864,
					-111.22347058627008
				]
			]
		},
		{
			"type": "arrow",
			"version": 448,
			"versionNonce": 308792701,
			"isDeleted": false,
			"id": "sAW4SciJhP58ZIc2qTvM7",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1442.7513900230606,
			"y": -259.43870053223384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 315.9171322074483,
			"height": 1.798130286750279,
			"seed": 195800797,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "sdlexrGoI-z5SWvfNa_Se",
				"focus": -0.5982827056264051,
				"gap": 9.552663310221192
			},
			"endBinding": {
				"elementId": "HbVMaRVEyZIBe9seMBqzp",
				"focus": 0.4315889208577497,
				"gap": 9.586387393639598
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-315.9171322074483,
					-1.798130286750279
				]
			]
		},
		{
			"type": "arrow",
			"version": 352,
			"versionNonce": 48469203,
			"isDeleted": false,
			"id": "7bvHAWZiLSmdqVPpz5UIB",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": 346.3772837075426,
			"y": -263.2762250858491,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 394.94338957992727,
			"height": 0.5463378854088887,
			"seed": 1153781875,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "HbVMaRVEyZIBe9seMBqzp",
				"focus": -0.4371452722836071,
				"gap": 11.139549548034665
			},
			"endBinding": {
				"elementId": "t_GKL3G2u2YfOIbJICIRE",
				"focus": 0.37475670768580993,
				"gap": 10.292834252592115
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					394.94338957992727,
					0.5463378854088887
				]
			]
		},
		{
			"type": "text",
			"version": 184,
			"versionNonce": 1047205341,
			"isDeleted": false,
			"id": "BkhYovdH",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 399.2840430621769,
			"y": -256.0969494817298,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 253,
			"height": 25,
			"seed": 969037715,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "tnu4_FCY8OC6ZBX-_O6eB",
					"type": "arrow"
				}
			],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to marketplace ",
			"rawText": "returned to marketplace ",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to marketplace "
		},
		{
			"type": "text",
			"version": 74,
			"versionNonce": 31425139,
			"isDeleted": false,
			"id": "wQKCMjdU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 305.61939123472393,
			"y": -493.9013601794746,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 360,
			"height": 25,
			"seed": 1205353117,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Clicked the \"Post a product\" button",
			"rawText": "Clicked the \"Post a product\" button",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Clicked the \"Post a product\" button"
		},
		{
			"type": "text",
			"version": 121,
			"versionNonce": 799429181,
			"isDeleted": false,
			"id": "58bu21Dx",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 346.2063936406197,
			"y": -416.2164184738714,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 304,
			"height": 25,
			"seed": 358925437,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "posted the product / canceled",
			"rawText": "posted the product / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "posted the product / canceled"
		},
		{
			"type": "text",
			"version": 55,
			"versionNonce": 1112325139,
			"isDeleted": false,
			"id": "XZMB7KhF",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 385.18635361413646,
			"y": -86.11708040447252,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 233,
			"height": 25,
			"seed": 36012115,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened the search bar ",
			"rawText": "opened the search bar ",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened the search bar "
		},
		{
			"type": "text",
			"version": 98,
			"versionNonce": 1660617373,
			"isDeleted": false,
			"id": "lirFf2x6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 376.4637576942856,
			"y": -173.15291128072226,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 284,
			"height": 25,
			"seed": 79715453,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "searched a query / canceled",
			"rawText": "searched a query / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "searched a query / canceled"
		},
		{
			"type": "text",
			"version": 75,
			"versionNonce": 540661273,
			"isDeleted": false,
			"id": "llYrfcc5",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1150.0795215123137,
			"y": -328.72464786996346,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 239,
			"height": 25,
			"seed": 965116093,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678218361338,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the \"Buy\" button",
			"rawText": "clicked the \"Buy\" button",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the \"Buy\" button"
		},
		{
			"type": "text",
			"version": 159,
			"versionNonce": 1025156861,
			"isDeleted": false,
			"id": "xeHpFM2P",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1194.6481345780692,
			"y": -250.26064703281315,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 210,
			"height": 25,
			"seed": 764684851,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "purchased / canceled",
			"rawText": "purchased / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "purchased / canceled"
		},
		{
			"type": "rectangle",
			"version": 662,
			"versionNonce": 881136467,
			"isDeleted": false,
			"id": "53GWuYAsrx1tz0f3j9ak2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1598.0935106829982,
			"y": -499.17122804420836,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 205.00258982228115,
			"height": 73.87274815039171,
			"seed": 1285571955,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "KtCysRkLmqji2aUslj1JP",
					"type": "arrow"
				},
				{
					"id": "Bhs2S5lKtjHHvOatKAl9O",
					"type": "arrow"
				},
				{
					"id": "cVTaF8YJduQXhetY857x-",
					"type": "arrow"
				},
				{
					"id": "vSSc9MPoj96nQSH5K0LbC",
					"type": "arrow"
				}
			],
			"updated": 1676660693576,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 658,
			"versionNonce": 277266269,
			"isDeleted": false,
			"id": "RocK5XwT",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1611.4916336104418,
			"y": -474.81632413082883,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 185,
			"height": 25,
			"seed": 8863549,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "adding attachment",
			"rawText": "adding attachment",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "adding attachment"
		},
		{
			"type": "arrow",
			"version": 359,
			"versionNonce": 1490809789,
			"isDeleted": false,
			"id": "cVTaF8YJduQXhetY857x-",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": 1083.431543792799,
			"y": -438.3931133960671,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 510.3056271559658,
			"height": 0.13827680242377483,
			"seed": 916299581,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660985106,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "53GWuYAsrx1tz0f3j9ak2",
				"focus": -0.6495205023940187,
				"gap": 4.356339734233416
			},
			"endBinding": {
				"elementId": "TM5LOi9KD4rq_G4JZlLnw",
				"focus": 0.6257848813021495,
				"gap": 7.948606778822295
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					510.3056271559658,
					0.13827680242377483
				]
			]
		},
		{
			"type": "arrow",
			"version": 381,
			"versionNonce": 1744860189,
			"isDeleted": false,
			"id": "vSSc9MPoj96nQSH5K0LbC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1084.2069454213533,
			"y": -484.8085673260745,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 510.30562715596557,
			"height": 2.4445607318726275,
			"seed": 435229843,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660985106,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TM5LOi9KD4rq_G4JZlLnw",
				"focus": -0.6370361100030404,
				"gap": 8.724008407376687
			},
			"endBinding": {
				"elementId": "53GWuYAsrx1tz0f3j9ak2",
				"focus": 0.5242410786571238,
				"gap": 3.5809381056792517
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					510.30562715596557,
					2.4445607318726275
				]
			]
		},
		{
			"type": "text",
			"version": 185,
			"versionNonce": 1937808019,
			"isDeleted": false,
			"id": "Xau8X8od",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1137.2687678471495,
			"y": -511.2067724075454,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 363,
			"height": 25,
			"seed": 151682611,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the \"Add attachment\" button",
			"rawText": "clicked the \"Add attachment\" button",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the \"Add attachment\" button"
		},
		{
			"type": "text",
			"version": 318,
			"versionNonce": 1985629213,
			"isDeleted": false,
			"id": "91VSRUP5",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1200.0462973220685,
			"y": -423.08287097413375,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 295,
			"height": 25,
			"seed": 2056705245,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660693576,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "added attachment / canceled",
			"rawText": "added attachment / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "added attachment / canceled"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#fff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%