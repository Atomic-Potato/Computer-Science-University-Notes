---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
browsing feed ^85VfsHc5

using marketplace ^nwTx9csb

chatting ^wkdEbNu4

creating post ^13UfRiei

logged in ^kPdNmZUu

logged out ^otUp4XwH

opened chats ^GMN3v1Xz

returned to feed ^z1ANA83b

returned to feed ^ZqSxZcWj

returned to feed ^8D5OzAyx

opened marketplace ^vhF7hR0Q

started creating a post ^gc1FZB19

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 264,
			"versionNonce": 1115627581,
			"isDeleted": false,
			"id": "GU79_xeYudhIX1tub13lm",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 70.3413330748453,
			"y": -325.87761104895367,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 265.64544677734375,
			"height": 95.74892791406502,
			"seed": 315328915,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "jn8S0GTwPJT7HOWIma3R1",
					"type": "arrow"
				},
				{
					"id": "jyi13qyDKDBkfJNB6sl6i",
					"type": "arrow"
				},
				{
					"id": "_EgP0KWgRyiMXxIiV6OKh",
					"type": "arrow"
				},
				{
					"id": "SPawDTNjmS2ZQgJ0G1ttQ",
					"type": "arrow"
				},
				{
					"id": "N9UYL_7CUuEQGngcZnGOX",
					"type": "arrow"
				},
				{
					"id": "Urd5Zmw_3iCCDnw6ScAwd",
					"type": "arrow"
				},
				{
					"id": "wpeZa4VaPzOk5Cem4drtj",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 129,
			"versionNonce": 2098870003,
			"isDeleted": false,
			"id": "85VfsHc5",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 131.25710142406342,
			"y": -291.10979639710746,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 132,
			"height": 25,
			"seed": 1750444627,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676661024759,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing feed",
			"rawText": "browsing feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing feed"
		},
		{
			"type": "text",
			"version": 105,
			"versionNonce": 15030131,
			"isDeleted": false,
			"id": "nwTx9csb",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 868.6078998499902,
			"y": -287.53850921985304,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 25,
			"seed": 1910510813,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655942347,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "using marketplace",
			"rawText": "using marketplace",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "using marketplace"
		},
		{
			"type": "text",
			"version": 182,
			"versionNonce": 65557907,
			"isDeleted": false,
			"id": "wkdEbNu4",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 911.9498240292781,
			"y": -577.8802989696622,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82,
			"height": 25,
			"seed": 1755405523,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655938150,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "chatting",
			"rawText": "chatting",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "chatting"
		},
		{
			"type": "text",
			"version": 308,
			"versionNonce": 1656875795,
			"isDeleted": false,
			"id": "13UfRiei",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 882.2536159886198,
			"y": -8.938956288545228,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 133,
			"height": 25,
			"seed": 1402219261,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655947146,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "creating post",
			"rawText": "creating post",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "creating post"
		},
		{
			"type": "rectangle",
			"version": 387,
			"versionNonce": 556420445,
			"isDeleted": false,
			"id": "YWqqHUR16zSKWJvYY-OP1",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 820.3314702577293,
			"y": -321.92498537290703,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 265.64544677734375,
			"height": 96.28531916693699,
			"seed": 1964682067,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "_EgP0KWgRyiMXxIiV6OKh",
					"type": "arrow"
				},
				{
					"id": "Urd5Zmw_3iCCDnw6ScAwd",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 405,
			"versionNonce": 1955764669,
			"isDeleted": false,
			"id": "vRzGOXhn7mxOtB6cHwOA0",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 817.8277253606732,
			"y": -43.03643760025267,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 265.64544677734375,
			"height": 94.91924549791224,
			"seed": 1458532275,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "SPawDTNjmS2ZQgJ0G1ttQ",
					"type": "arrow"
				},
				{
					"id": "wpeZa4VaPzOk5Cem4drtj",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 444,
			"versionNonce": 1643272733,
			"isDeleted": false,
			"id": "Z3K6wKzjeBLvdypMzhgS7",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 822.8568048285028,
			"y": -612.8689631485171,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 265.64544677734375,
			"height": 96.28531916693699,
			"seed": 478281533,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "jyi13qyDKDBkfJNB6sl6i",
					"type": "arrow"
				},
				{
					"id": "N9UYL_7CUuEQGngcZnGOX",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 254,
			"versionNonce": 574295677,
			"isDeleted": false,
			"id": "TOcsssHGmm8nLqGFDEbV2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -320.09902050481327,
			"y": -292.73128338429905,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1372015667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "jn8S0GTwPJT7HOWIma3R1",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 462,
			"versionNonce": 1775038589,
			"isDeleted": false,
			"id": "HhdcyfoR90rZmFCyvJ6I6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1698.6541398195563,
			"y": -354.1665564577914,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1877488893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655724452,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 311,
			"versionNonce": 437658067,
			"isDeleted": false,
			"id": "3qOuJzQjSYjLd7un4_lqh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1679.4880703274146,
			"y": -370.7607891979598,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.62777420104499,
			"height": 75.37969110015035,
			"seed": 981260637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "22H5SxIaIAn8Fu7NVzJxa",
					"type": "arrow"
				}
			],
			"updated": 1676655724452,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 384,
			"versionNonce": 1981477235,
			"isDeleted": false,
			"id": "jn8S0GTwPJT7HOWIma3R1",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -267.29768873008663,
			"y": -271.90585878412844,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 335.9669867601053,
			"height": 0.7087241782141973,
			"seed": 1007678333,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TOcsssHGmm8nLqGFDEbV2",
				"focus": -0.012157628423065356,
				"gap": 9.16154627408384
			},
			"endBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": -0.14722834217102912,
				"gap": 1.6720350448266004
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					335.9669867601053,
					0.7087241782141973
				]
			]
		},
		{
			"type": "arrow",
			"version": 511,
			"versionNonce": 1113412413,
			"isDeleted": false,
			"id": "jyi13qyDKDBkfJNB6sl6i",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 201.69791199143367,
			"y": -338.10387787507557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 607.8048297354266,
			"height": 231.55337393501952,
			"seed": 1999324691,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": -0.11658459858773086,
				"gap": 12.2262668261219
			},
			"endBinding": {
				"elementId": "Z3K6wKzjeBLvdypMzhgS7",
				"focus": 0.17287062980534917,
				"gap": 13.354063101642623
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					55.63287722700579,
					-216.3548714873932
				],
				[
					607.8048297354266,
					-231.55337393501952
				]
			]
		},
		{
			"type": "arrow",
			"version": 278,
			"versionNonce": 457329427,
			"isDeleted": false,
			"id": "_EgP0KWgRyiMXxIiV6OKh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 339.32433863633105,
			"y": -281.01510805568773,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 470.5731185210359,
			"height": 11.014703039087863,
			"seed": 1850522301,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": -0.1202790038602281,
				"gap": 3.337558784142061
			},
			"endBinding": {
				"elementId": "YWqqHUR16zSKWJvYY-OP1",
				"focus": -0.13921760433247088,
				"gap": 10.434013100362336
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					470.5731185210359,
					11.014703039087863
				]
			]
		},
		{
			"type": "arrow",
			"version": 481,
			"versionNonce": 1764352925,
			"isDeleted": false,
			"id": "SPawDTNjmS2ZQgJ0G1ttQ",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 201.15688185426183,
			"y": -223.6067948142461,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 611.712073967896,
			"height": 224.79948989822827,
			"seed": 450294557,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": 0.09987095834960821,
				"gap": 6.521888320642574
			},
			"endBinding": {
				"elementId": "vRzGOXhn7mxOtB6cHwOA0",
				"focus": 0.03654211505315646,
				"gap": 4.958769538515298
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					49.67057226726723,
					218.90378211375
				],
				[
					611.712073967896,
					224.79948989822827
				]
			]
		},
		{
			"type": "rectangle",
			"version": 82,
			"versionNonce": 26046643,
			"isDeleted": false,
			"id": "fVSHP85Qhe_ef_s2-cS-9",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 680.6792320936911,
			"y": -759.2008648164176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 507.23959061212145,
			"height": 890.1556934772562,
			"seed": 146971827,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "jyi13qyDKDBkfJNB6sl6i",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 57,
			"versionNonce": 1019570173,
			"isDeleted": false,
			"id": "VAdpG8uDKnggc8XfaSyPR",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 679.917383898339,
			"y": -411.34356459010644,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 508.39057273165554,
			"height": 0.8825943476244333,
			"seed": 1009389683,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					508.39057273165554,
					-0.8825943476244333
				]
			]
		},
		{
			"type": "line",
			"version": 59,
			"versionNonce": 1789059667,
			"isDeleted": false,
			"id": "jm4X-5cRTVDjsc6hlBwVm",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 678.1520771776358,
			"y": -131.55221596498933,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 507.50786035857675,
			"height": 0.8826238539880364,
			"seed": 401527293,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					507.50786035857675,
					-0.8826238539880364
				]
			]
		},
		{
			"type": "rectangle",
			"version": 193,
			"versionNonce": 791765085,
			"isDeleted": false,
			"id": "d6ILUAWNeTrum__fwHUaC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -43.81612685655841,
			"y": -841.0827253668174,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1344.3872230395248,
			"height": 1020.8779499121945,
			"seed": 376245299,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "22H5SxIaIAn8Fu7NVzJxa",
					"type": "arrow"
				}
			],
			"updated": 1676655719600,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 607,
			"versionNonce": 221802355,
			"isDeleted": false,
			"id": "22H5SxIaIAn8Fu7NVzJxa",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1313.5017876543625,
			"y": -328.776738538776,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 358.7525178719725,
			"height": 0.995603672523032,
			"seed": 752485693,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655724453,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "d6ILUAWNeTrum__fwHUaC",
				"gap": 12.930691471395834,
				"focus": -0.005134448963639611
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"gap": 7.568801791864533,
				"focus": -0.14392503318748306
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					358.7525178719725,
					0.995603672523032
				]
			]
		},
		{
			"type": "text",
			"version": 100,
			"versionNonce": 1983859901,
			"isDeleted": false,
			"id": "kPdNmZUu",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -145.84509896157465,
			"y": -302.2894819875783,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 25,
			"seed": 334721117,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged in",
			"rawText": "logged in",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged in"
		},
		{
			"type": "text",
			"version": 245,
			"versionNonce": 1415492925,
			"isDeleted": false,
			"id": "otUp4XwH",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1435.1382943109563,
			"y": -361.7203144311249,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 25,
			"seed": 1525530813,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655724453,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged out",
			"rawText": "logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged out"
		},
		{
			"type": "arrow",
			"version": 136,
			"versionNonce": 294694173,
			"isDeleted": false,
			"id": "N9UYL_7CUuEQGngcZnGOX",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 810.0341690635532,
			"y": -539.3310236879884,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 579.7278867018613,
			"height": 202.69217667638452,
			"seed": 121314387,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Z3K6wKzjeBLvdypMzhgS7",
				"focus": -0.43864420488095407,
				"gap": 12.82263576494961
			},
			"endBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": 0.03215731169874449,
				"gap": 10.761235962650176
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-506.73041799842326,
					10.630723478330992
				],
				[
					-579.7278867018613,
					202.69217667638452
				]
			]
		},
		{
			"type": "arrow",
			"version": 80,
			"versionNonce": 250740531,
			"isDeleted": false,
			"id": "Urd5Zmw_3iCCDnw6ScAwd",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 808.7978880771439,
			"y": -240.4478432711357,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 461.66702139842283,
			"height": 8.743677643205217,
			"seed": 821324307,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "YWqqHUR16zSKWJvYY-OP1",
				"focus": -0.711996719468198,
				"gap": 11.533582180585427
			},
			"endBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": 0.5176615531245963,
				"gap": 11.144086826531975
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-461.66702139842283,
					-8.743677643205217
				]
			]
		},
		{
			"type": "arrow",
			"version": 113,
			"versionNonce": 278331773,
			"isDeleted": false,
			"id": "wpeZa4VaPzOk5Cem4drtj",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 808.911706938442,
			"y": -23.450069801980703,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 588.9686020991469,
			"height": 196.32288935344866,
			"seed": 1580990643,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "vRzGOXhn7mxOtB6cHwOA0",
				"focus": 0.5487976561742686,
				"gap": 8.916018422231218
			},
			"endBinding": {
				"elementId": "GU79_xeYudhIX1tub13lm",
				"focus": 0.02491093998898219,
				"gap": 10.355723979459299
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-521.3901333440551,
					-4.439485524494728
				],
				[
					-588.9686020991469,
					-196.32288935344866
				]
			]
		},
		{
			"type": "text",
			"version": 48,
			"versionNonce": 695312595,
			"isDeleted": false,
			"id": "GMN3v1Xz",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 493.94120745861267,
			"y": -603.4591900738881,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 131,
			"height": 25,
			"seed": 1729952499,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened chats",
			"rawText": "opened chats",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened chats"
		},
		{
			"type": "text",
			"version": 42,
			"versionNonce": 412338653,
			"isDeleted": false,
			"id": "z1ANA83b",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 465.4786366028835,
			"y": -533.74629904509,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 170,
			"height": 25,
			"seed": 2003096051,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to feed",
			"rawText": "returned to feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to feed"
		},
		{
			"type": "text",
			"version": 80,
			"versionNonce": 1120669299,
			"isDeleted": false,
			"id": "ZqSxZcWj",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 449.0081934924226,
			"y": -226.83618032407878,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 170,
			"height": 25,
			"seed": 1928703741,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719600,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to feed",
			"rawText": "returned to feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to feed"
		},
		{
			"type": "text",
			"version": 106,
			"versionNonce": 714638909,
			"isDeleted": false,
			"id": "8D5OzAyx",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 444.11215246409324,
			"y": -42.813650980097464,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 170,
			"height": 25,
			"seed": 1519169149,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719601,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to feed",
			"rawText": "returned to feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to feed"
		},
		{
			"type": "text",
			"version": 154,
			"versionNonce": 1304938515,
			"isDeleted": false,
			"id": "vhF7hR0Q",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 462.94781358138766,
			"y": -309.0019653234237,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 192,
			"height": 25,
			"seed": 761380669,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655719601,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened marketplace",
			"rawText": "opened marketplace",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened marketplace"
		},
		{
			"type": "text",
			"version": 241,
			"versionNonce": 1676412339,
			"isDeleted": false,
			"id": "gc1FZB19",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 400.5785367011112,
			"y": 28.53057758094195,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 244,
			"height": 25,
			"seed": 1276613789,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676655854769,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "started creating a post",
			"rawText": "started creating a post",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "started creating a post"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%