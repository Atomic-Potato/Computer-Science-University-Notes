---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
buyer:user ^QarZbQJC

buyProduct ^XGtv8nYR

purchaseHandler:app ^qPI99GKL

sendBillingInfo ^18hImprj

sendConfirmationCode ^b5u59hKj

confirmCode ^B11C9udw

marketStorage:database ^SonfSUnM

seller:user ^WYIN3Efc

requestProduct ^WuncKFSX

alt ^SqEUDDfy

[can be shipped] ^Owcswltl

startShipping ^A6MG5iH4

notifySeller ^QVnzOcT2

sendMoney ^I1OFqHs0

confirmTransactionSuccess ^oZyjphPg

confirmPurchase ^gxqDcMFh

ref ^HQeXRAjc

Billing account 
connection ^2DGhoFEY

connectToBillingAccount ^1MvuomJ3

[else] ^DClpodU9

notifySeller ^flPHwNgt

confirmNotification ^t3lIGKOQ

openChatWithSeller ^nxauXTFg

confirmProductReceival  ^xTk1KlPD

sendMoney ^oJGvFCRj

confirmTransactionSuccess ^u19xkcJn

confirmTransactionSuccess ^uweLUDy0

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "line",
			"version": 856,
			"versionNonce": 1386380866,
			"isDeleted": false,
			"id": "IF1dE1K2Oz0w-DGdODafA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1353.1693591035532,
			"y": 293.44045240046216,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 9.305089743598273,
			"height": 1071.4672839399589,
			"seed": 834231234,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722509732,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.305089743598273,
					1071.4672839399589
				]
			]
		},
		{
			"type": "text",
			"version": 247,
			"versionNonce": 373650142,
			"isDeleted": false,
			"id": "QarZbQJC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 332.73462827288006,
			"y": -98.97528352200175,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 99,
			"height": 25,
			"seed": 57213726,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "buyer:user",
			"rawText": "buyer:user",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "buyer:user"
		},
		{
			"type": "rectangle",
			"version": 344,
			"versionNonce": 1898328578,
			"isDeleted": false,
			"id": "wYM9WXYWI8bvP5T-6GAVq",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 267.25082013708584,
			"y": -111.90735466253864,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 233.05232979172854,
			"height": 47.54578928711754,
			"seed": 99796418,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 204,
			"versionNonce": 659857858,
			"isDeleted": false,
			"id": "zin511GFllb8hyFYx-vad",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 437.44999756541716,
			"y": -71.77257659255653,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 115.9395994857901,
			"height": 1.1652238671127293,
			"seed": 1000939038,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-115.9395994857901,
					-1.1652238671127293
				]
			]
		},
		{
			"type": "line",
			"version": 450,
			"versionNonce": 1838082370,
			"isDeleted": false,
			"id": "GedpNlG1HNTE5gdU4gw1x",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 376.74077632519266,
			"y": -58.449445716816285,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.491213673993457,
			"height": 1457.040719229613,
			"seed": 974332866,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722464363,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.491213673993457,
					1457.040719229613
				]
			]
		},
		{
			"type": "rectangle",
			"version": 833,
			"versionNonce": 502115773,
			"isDeleted": false,
			"id": "iEqPVIdTntB2bMF_IGuaj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 349.21035100334007,
			"y": -33.13904678858171,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 43.22521159685449,
			"height": 1376.5731279163974,
			"seed": 176349854,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1677572891641,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1029,
			"versionNonce": 1251653534,
			"isDeleted": false,
			"id": "8w0nzVOA8dsPcFUvDtDXU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 127.98949641917687,
			"y": 6.221653940805027,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 182.42792451745123,
			"height": 0.5160084325983121,
			"seed": 2079834242,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "dot",
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					182.42792451745123,
					0.5160084325983121
				]
			]
		},
		{
			"type": "text",
			"version": 301,
			"versionNonce": 1262786882,
			"isDeleted": false,
			"id": "XGtv8nYR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 161.76561142436393,
			"y": -25.70143658885499,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 110,
			"height": 25,
			"seed": 704491486,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "buyProduct",
			"rawText": "buyProduct",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "buyProduct"
		},
		{
			"type": "text",
			"version": 424,
			"versionNonce": 1809716190,
			"isDeleted": false,
			"id": "qPI99GKL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 601.2271921339291,
			"y": 246.3468847440035,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 195,
			"height": 25,
			"seed": 604262558,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "purchaseHandler:app",
			"rawText": "purchaseHandler:app",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "purchaseHandler:app"
		},
		{
			"type": "rectangle",
			"version": 499,
			"versionNonce": 1470374146,
			"isDeleted": false,
			"id": "KyEMemOxvJV84QLn1sb53",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 579.7392243741567,
			"y": 237.1346707908064,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 233.05232979172854,
			"height": 47.54578928711754,
			"seed": 1235030082,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 383,
			"versionNonce": 2095835166,
			"isDeleted": false,
			"id": "j2M6hM9v1Tqoqope0gB-6",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 801.4961161031695,
			"y": 275.00203068588587,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 206.91951409220292,
			"height": 0.11947611487158838,
			"seed": 1991019742,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-206.91951409220292,
					-0.11947611487158838
				]
			]
		},
		{
			"type": "line",
			"version": 631,
			"versionNonce": 1569862978,
			"isDeleted": false,
			"id": "dLYF_yY8P7WAaBB6VsNwS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 689.9553017316814,
			"y": 288.48891588918434,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 2.919606356095983,
			"height": 1064.387306814313,
			"seed": 2008743298,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722452340,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.919606356095983,
					1064.387306814313
				]
			]
		},
		{
			"type": "arrow",
			"version": 2426,
			"versionNonce": 1144164354,
			"isDeleted": false,
			"id": "vzJcis98KD_dKW07X-tFE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 431.024237144695,
			"y": 372.1620373817757,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 215.05218835872932,
			"height": 1.0325302536570575,
			"seed": 696310850,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					215.05218835872932,
					-1.0325302536570575
				]
			]
		},
		{
			"type": "text",
			"version": 401,
			"versionNonce": 973072670,
			"isDeleted": false,
			"id": "18hImprj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 484.00090658469094,
			"y": 349.99317693981527,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 111,
			"height": 20,
			"seed": 895062238,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "sendBillingInfo",
			"rawText": "sendBillingInfo",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sendBillingInfo"
		},
		{
			"type": "rectangle",
			"version": 1467,
			"versionNonce": 37244467,
			"isDeleted": false,
			"id": "bLBuPREcfzRPQxan5BzcJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 671.4661335091184,
			"y": 362.0915789211177,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 32.90943772472106,
			"height": 645.041914303082,
			"seed": 1248619842,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				}
			],
			"updated": 1677572894732,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1613,
			"versionNonce": 1788941662,
			"isDeleted": false,
			"id": "_LV4qwTYC6y7KbREpJoED",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 643.2329591716145,
			"y": 415.11218063887765,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 213.588317421358,
			"height": 0.3999933947889929,
			"seed": 1805453662,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "b5u59hKj",
				"focus": -1.379978850651036,
				"gap": 8.262062977713867
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-213.588317421358,
					0.3999933947889929
				]
			]
		},
		{
			"type": "text",
			"version": 404,
			"versionNonce": 1537996674,
			"isDeleted": false,
			"id": "b5u59hKj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 467.97089619390067,
			"y": 390.0784568885861,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 168,
			"height": 20,
			"seed": 1647072094,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				}
			],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "sendConfirmationCode",
			"rawText": "sendConfirmationCode",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sendConfirmationCode"
		},
		{
			"type": "arrow",
			"version": 1827,
			"versionNonce": 2127739294,
			"isDeleted": false,
			"id": "Hu4uXCeu4VvkrBmvqWU6g",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 433.85945283488604,
			"y": 463.92095591057205,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 212.23475891023463,
			"height": 2.26591083606138,
			"seed": 448467330,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					212.23475891023463,
					-2.26591083606138
				]
			]
		},
		{
			"type": "text",
			"version": 402,
			"versionNonce": 403027778,
			"isDeleted": false,
			"id": "B11C9udw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 489.5616038074061,
			"y": 440.82153280866737,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 92,
			"height": 20,
			"seed": 754677790,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmCode",
			"rawText": "confirmCode",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmCode"
		},
		{
			"type": "text",
			"version": 625,
			"versionNonce": 499504606,
			"isDeleted": false,
			"id": "SonfSUnM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 887.0694788448145,
			"y": 244.66788888537957,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 246,
			"height": 25,
			"seed": 1041066754,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "marketStorage:database",
			"rawText": "marketStorage:database",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "marketStorage:database"
		},
		{
			"type": "rectangle",
			"version": 688,
			"versionNonce": 1787920130,
			"isDeleted": false,
			"id": "LfmN2m7TWXW533GslKVs6",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 865.5815110850422,
			"y": 235.4556749321825,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 293.94881132086715,
			"height": 47.54578928711754,
			"seed": 68435486,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 579,
			"versionNonce": 1619749406,
			"isDeleted": false,
			"id": "9TAAMjyBUPl-w2_vwd1Nv",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1137.5368523172262,
			"y": 273.32303482726195,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 257.1179635953738,
			"height": 0.11947611487158838,
			"seed": 619494082,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-257.1179635953738,
					-0.11947611487158838
				]
			]
		},
		{
			"type": "line",
			"version": 655,
			"versionNonce": 1338920642,
			"isDeleted": false,
			"id": "pt86xTJAOpeFZZx-MPm1e",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1012.1166421659236,
			"y": 289.9421318711062,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 0.9133953978832778,
			"height": 364.2253674260611,
			"seed": 2050086366,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.9133953978832778,
					364.2253674260611
				]
			]
		},
		{
			"type": "text",
			"version": 797,
			"versionNonce": 1725248002,
			"isDeleted": false,
			"id": "WYIN3Efc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1305.9339174918289,
			"y": 250.05290703313574,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 100,
			"height": 25,
			"seed": 1736856798,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722503631,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "seller:user",
			"rawText": "seller:user",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "seller:user"
		},
		{
			"type": "rectangle",
			"version": 883,
			"versionNonce": 30435102,
			"isDeleted": false,
			"id": "-O6L16KIetuXQIge0VK3Y",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1240.450109356035,
			"y": 237.12083589259885,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 233.05232979172854,
			"height": 47.54578928711754,
			"seed": 2052878338,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722503632,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 743,
			"versionNonce": 253993410,
			"isDeleted": false,
			"id": "5Dvnu8wjjDc0Bc0tZGbKk",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1410.6492867843663,
			"y": 277.2556139625809,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 115.9395994857901,
			"height": 1.1652238671127293,
			"seed": 1004800286,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722503632,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-115.9395994857901,
					-1.1652238671127293
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1496,
			"versionNonce": 361428061,
			"isDeleted": false,
			"id": "NAqqEMrfH-fdad4aYMTHJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 997.35058674173,
			"y": 560.4400213917348,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 30.06690852493486,
			"height": 41.66955439798935,
			"seed": 623575454,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "vzJcis98KD_dKW07X-tFE",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				},
				{
					"id": "Hu4uXCeu4VvkrBmvqWU6g",
					"type": "arrow"
				}
			],
			"updated": 1677572906351,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1696,
			"versionNonce": 982841054,
			"isDeleted": false,
			"id": "IBPwfVWXfZpPhzalEUMar",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 724.7108480234974,
			"y": 564.238433326005,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 253.63339696771789,
			"height": 2.6683734581461636,
			"seed": 1961625822,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					253.63339696771789,
					-2.6683734581461636
				]
			]
		},
		{
			"type": "text",
			"version": 420,
			"versionNonce": 477499650,
			"isDeleted": false,
			"id": "WuncKFSX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 798.4577974488043,
			"y": 540.609066999581,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 124,
			"height": 20,
			"seed": 2053469890,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722579789,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "requestProduct",
			"rawText": "requestProduct",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "requestProduct"
		},
		{
			"type": "rectangle",
			"version": 989,
			"versionNonce": 953051934,
			"isDeleted": false,
			"id": "dbKYiO8OEozpmnldE8kl1",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 118.21835031118985,
			"y": 524.9485225542983,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1363.6746777087444,
			"height": 797.0290533298001,
			"seed": 940060674,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "IBPwfVWXfZpPhzalEUMar",
					"type": "arrow"
				}
			],
			"updated": 1676722191677,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 670,
			"versionNonce": 1375198658,
			"isDeleted": false,
			"id": "SqEUDDfy",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 132.9398723389262,
			"y": 535.4804147739936,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 32,
			"height": 25,
			"seed": 1339312414,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "alt",
			"rawText": "alt",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "alt"
		},
		{
			"type": "line",
			"version": 704,
			"versionNonce": 1347376990,
			"isDeleted": false,
			"id": "axFlCpB-TPTvBYEn2REfJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 175.70218991442687,
			"y": 527.0488696139954,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.22383799511635516,
			"height": 20.817592068941792,
			"seed": 2101796802,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.22383799511635516,
					20.817592068941792
				]
			]
		},
		{
			"type": "line",
			"version": 686,
			"versionNonce": 544920962,
			"isDeleted": false,
			"id": "X75MwzIiIvEfssbW-1WCb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 122.65089386474563,
			"y": 562.8640862816391,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 35.815216667643654,
			"height": 0.4476909566672873,
			"seed": 115963230,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.815216667643654,
					-0.4476909566672873
				]
			]
		},
		{
			"type": "line",
			"version": 687,
			"versionNonce": 1500035998,
			"isDeleted": false,
			"id": "kxMv0r2rsIGEBhQTPpZW7",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 175.92602790954368,
			"y": 548.3141526396045,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 19.026828242272586,
			"height": 14.997624598701833,
			"seed": 1318688642,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191677,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-19.026828242272586,
					14.997624598701833
				]
			]
		},
		{
			"type": "text",
			"version": 1146,
			"versionNonce": 1531499842,
			"isDeleted": false,
			"id": "Owcswltl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 137.43844526852013,
			"y": 584.1709714951539,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 131,
			"height": 20,
			"seed": 672548290,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "[can be shipped]",
			"rawText": "[can be shipped]",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "[can be shipped]"
		},
		{
			"type": "arrow",
			"version": 1785,
			"versionNonce": 2051774430,
			"isDeleted": false,
			"id": "yOomSOnvjfK4YOGn7Wpf8",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 975.8262566153078,
			"y": 598.3920666687593,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 247.58984985366226,
			"height": 1.402358884891271,
			"seed": 222426690,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-247.58984985366226,
					1.402358884891271
				]
			]
		},
		{
			"type": "text",
			"version": 374,
			"versionNonce": 1405148418,
			"isDeleted": false,
			"id": "A6MG5iH4",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 815.3059235630719,
			"y": 574.4777636637459,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 102,
			"height": 20,
			"seed": 111391746,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "startShipping",
			"rawText": "startShipping",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "startShipping"
		},
		{
			"type": "rectangle",
			"version": 1626,
			"versionNonce": 336776179,
			"isDeleted": false,
			"id": "9f6lkNZ9TD8yme39426ym",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1340.9776479052603,
			"y": 663.5466382830758,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 30.06690852493486,
			"height": 74.71515574071458,
			"seed": 214340290,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "vzJcis98KD_dKW07X-tFE",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				},
				{
					"id": "Hu4uXCeu4VvkrBmvqWU6g",
					"type": "arrow"
				},
				{
					"id": "IBPwfVWXfZpPhzalEUMar",
					"type": "arrow"
				},
				{
					"id": "yOomSOnvjfK4YOGn7Wpf8",
					"type": "arrow"
				}
			],
			"updated": 1677572906351,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1588,
			"versionNonce": 1638649026,
			"isDeleted": false,
			"id": "tiJu-cyS42MOr4Va1VMaM",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 733.5065579843006,
			"y": 666.3814568381256,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 586.0631819642995,
			"height": 1.9146922084308926,
			"seed": 1083186818,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722232859,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					586.0631819642995,
					-1.9146922084308926
				]
			]
		},
		{
			"type": "text",
			"version": 507,
			"versionNonce": 965851230,
			"isDeleted": false,
			"id": "QVnzOcT2",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 825.8220918061272,
			"y": 641.4497956081321,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 89,
			"height": 20,
			"seed": 1912103746,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "notifySeller",
			"rawText": "notifySeller",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "notifySeller"
		},
		{
			"type": "arrow",
			"version": 1470,
			"versionNonce": 1865120002,
			"isDeleted": false,
			"id": "sao4Ez4TVpKqRDJSlxviQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 736.799091192541,
			"y": 702.9482786062231,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 581.0161052936614,
			"height": 6.334854335681712,
			"seed": 1976527774,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722236233,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					581.0161052936614,
					-6.334854335681712
				]
			]
		},
		{
			"type": "text",
			"version": 556,
			"versionNonce": 230096030,
			"isDeleted": false,
			"id": "I1OFqHs0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 822.2269580333343,
			"y": 681.0736699711086,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 81,
			"height": 20,
			"seed": 1992982338,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "sendMoney",
			"rawText": "sendMoney",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sendMoney"
		},
		{
			"type": "arrow",
			"version": 1414,
			"versionNonce": 1057755074,
			"isDeleted": false,
			"id": "ZPK6jaZxBXzjtPi2bo3kX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1317.8900944277686,
			"y": 735.0819201411746,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 582.2785975977332,
			"height": 4.514546949404064,
			"seed": 1225250142,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722250993,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-582.2785975977332,
					4.514546949404064
				]
			]
		},
		{
			"type": "text",
			"version": 608,
			"versionNonce": 1831450846,
			"isDeleted": false,
			"id": "oZyjphPg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1039.227760998264,
			"y": 710.4589758452009,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 210,
			"height": 20,
			"seed": 91544926,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmTransactionSuccess",
			"rawText": "confirmTransactionSuccess",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmTransactionSuccess"
		},
		{
			"type": "arrow",
			"version": 874,
			"versionNonce": 504450050,
			"isDeleted": false,
			"id": "sz7-oPeAFCucNZrD7GqLV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 645.8384284602417,
			"y": 780.973334797106,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 218.044981269186,
			"height": 3.0074712189468755,
			"seed": 554225794,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-218.044981269186,
					3.0074712189468755
				]
			]
		},
		{
			"type": "text",
			"version": 500,
			"versionNonce": 2138762526,
			"isDeleted": false,
			"id": "gxqDcMFh",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 499.4041753722696,
			"y": 759.4073237101437,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 125,
			"height": 20,
			"seed": 789320386,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmPurchase",
			"rawText": "confirmPurchase",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmPurchase"
		},
		{
			"type": "rectangle",
			"version": 569,
			"versionNonce": 2102911325,
			"isDeleted": false,
			"id": "2Sp63-KQlIzT_Bjj2vN51",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 688.7121599365173,
			"y": -36.36809172205406,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 333.9064843234039,
			"height": 165.2157585396276,
			"seed": 923542978,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1677572887913,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 445,
			"versionNonce": 265990466,
			"isDeleted": false,
			"id": "HQeXRAjc",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 699.4226181674753,
			"y": -26.21766069804042,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 31,
			"height": 25,
			"seed": 730042206,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722279768,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ref",
			"rawText": "ref",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ref"
		},
		{
			"type": "line",
			"version": 474,
			"versionNonce": 1968536542,
			"isDeleted": false,
			"id": "yD5DlMLqCajbJuR51CN_0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 742.1849357429769,
			"y": -34.64920585803864,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 0.22383799511635516,
			"height": 20.817592068941792,
			"seed": 1808145794,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722279768,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.22383799511635516,
					20.817592068941792
				]
			]
		},
		{
			"type": "line",
			"version": 456,
			"versionNonce": 1370962178,
			"isDeleted": false,
			"id": "DF4XMZDNnLSJF0-ph3TPE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 689.1336396932952,
			"y": 1.1660108096048987,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 35.815216667643654,
			"height": 0.4476909566672873,
			"seed": 827716510,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722279768,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.815216667643654,
					-0.4476909566672873
				]
			]
		},
		{
			"type": "line",
			"version": 457,
			"versionNonce": 859197470,
			"isDeleted": false,
			"id": "cbiCzYm9JPcD85gUtIK5v",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 742.4087737380933,
			"y": -13.38392283242959,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 19.026828242272586,
			"height": 14.997624598701833,
			"seed": 770383170,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722279768,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-19.026828242272586,
					14.997624598701833
				]
			]
		},
		{
			"type": "text",
			"version": 614,
			"versionNonce": 2116864194,
			"isDeleted": false,
			"id": "2DGhoFEY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 756.3195013537711,
			"y": 20.925914433299255,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 211,
			"height": 70,
			"seed": 440833026,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722279768,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Billing account \nconnection",
			"rawText": "Billing account \nconnection",
			"baseline": 60,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Billing account \nconnection"
		},
		{
			"type": "arrow",
			"version": 171,
			"versionNonce": 797073026,
			"isDeleted": false,
			"id": "_nzCyzs5s8PTyiFiGHqFT",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 413.5167853886362,
			"y": 40.05216375050671,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 239.1603325551058,
			"height": 1.9443959422609112,
			"seed": 567977054,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722276450,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					239.1603325551058,
					-1.9443959422609112
				]
			]
		},
		{
			"type": "text",
			"version": 239,
			"versionNonce": 1195000478,
			"isDeleted": false,
			"id": "1MvuomJ3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 433.37379598980283,
			"y": 11.267340365731712,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 185,
			"height": 20,
			"seed": 2110313026,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722276450,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "connectToBillingAccount",
			"rawText": "connectToBillingAccount",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "connectToBillingAccount"
		},
		{
			"type": "line",
			"version": 122,
			"versionNonce": 1625532930,
			"isDeleted": false,
			"id": "LdKkP-pNVrmhe-3_ZEp0P",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 120.65452809385556,
			"y": 855.8427825524461,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 1359.679863201104,
			"height": 3.032781733418801,
			"seed": 1821537118,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1359.679863201104,
					-3.032781733418801
				]
			]
		},
		{
			"type": "text",
			"version": 1215,
			"versionNonce": 1342533406,
			"isDeleted": false,
			"id": "DClpodU9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 135.2038283633138,
			"y": 875.1606234972612,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 20,
			"seed": 1692039298,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "[else]",
			"rawText": "[else]",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "[else]"
		},
		{
			"type": "arrow",
			"version": 1632,
			"versionNonce": 815995330,
			"isDeleted": false,
			"id": "b4o9rkwf_9s_W0C8C4Cbq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 725.443472875902,
			"y": 900.5156712633997,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 598.1361816743477,
			"height": 3.388390742968454,
			"seed": 1562745374,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					598.1361816743477,
					-3.388390742968454
				]
			]
		},
		{
			"type": "text",
			"version": 567,
			"versionNonce": 1912986462,
			"isDeleted": false,
			"id": "flPHwNgt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 817.7590066977286,
			"y": 875.5840100334061,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 89,
			"height": 20,
			"seed": 623845058,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "notifySeller",
			"rawText": "notifySeller",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "notifySeller"
		},
		{
			"type": "arrow",
			"version": 1470,
			"versionNonce": 342107102,
			"isDeleted": false,
			"id": "V8phKQX9uKtnwRWEskBF6",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1323.6482478966705,
			"y": 947.4569742461158,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 599.5645538572429,
			"height": 3.9309409001245967,
			"seed": 128027842,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722204281,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-599.5645538572429,
					3.9309409001245967
				]
			]
		},
		{
			"type": "text",
			"version": 703,
			"versionNonce": 162447262,
			"isDeleted": false,
			"id": "t3lIGKOQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1080.2022970164176,
			"y": 921.072287205764,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 145,
			"height": 20,
			"seed": 1721505886,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmNotification",
			"rawText": "confirmNotification",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmNotification"
		},
		{
			"type": "arrow",
			"version": 945,
			"versionNonce": 1028985154,
			"isDeleted": false,
			"id": "WdyA44OHvQN9Wui7oQJD1",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 648.6421464976536,
			"y": 1002.1432082509059,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 220.33391460358007,
			"height": 0.7185378845529158,
			"seed": 1508891586,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191678,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-220.33391460358007,
					0.7185378845529158
				]
			]
		},
		{
			"type": "text",
			"version": 608,
			"versionNonce": 993074142,
			"isDeleted": false,
			"id": "nxauXTFg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 479.29001489834855,
			"y": 976.4846914958083,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 148,
			"height": 20,
			"seed": 1650342238,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "openChatWithSeller",
			"rawText": "openChatWithSeller",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "openChatWithSeller"
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 551917826,
			"isDeleted": false,
			"id": "TIgnoz689UswIjVJIdJYI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1024.2185173499424,
			"y": 627.2605264037168,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 25.423110784096252,
			"height": 17.675118970997914,
			"seed": 752144414,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.1791353448013524,
					0.7263757501621058
				],
				[
					-5.326755501188359,
					1.9370020004321304
				],
				[
					-8.232242313206257,
					3.6318706564951526
				],
				[
					-11.864129158331707,
					5.810997906981356
				],
				[
					-15.253866470457751,
					8.23224231320637
				],
				[
					-18.40150281547517,
					10.895628158115755
				],
				[
					-20.82273912738492,
					12.832613969917588
				],
				[
					-23.001874472186387,
					14.769615970349719
				],
				[
					-24.212492628141263,
					15.980250314935006
				],
				[
					-24.938860283988106,
					16.70661797078185
				],
				[
					-25.180993628357328,
					17.190868470889882
				],
				[
					-25.423110784096252,
					17.675118970997914
				],
				[
					-25.423110784096252,
					17.675118970997914
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 22,
			"versionNonce": 2090725406,
			"isDeleted": false,
			"id": "L-RV_3bYpHuCkLtp6VV69",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 999.0375237215851,
			"y": 628.7132779040409,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 26.14949462857362,
			"height": 24.454609783880187,
			"seed": 1725033986,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.4842505001080326,
					0
				],
				[
					1.4527515003240978,
					0.24212525005407315
				],
				[
					2.9055030006481957,
					1.4527515003240978
				],
				[
					5.326755501188472,
					3.3897454064410795
				],
				[
					8.958626157683511,
					5.810997906981356
				],
				[
					15.01174931471894,
					9.927110969269279
				],
				[
					18.159369471105947,
					13.07474731428681
				],
				[
					20.580621971646224,
					15.253866470457751
				],
				[
					22.03337347197032,
					16.948735126520774
				],
				[
					23.001858283555976,
					18.40148662684487
				],
				[
					23.728242128033344,
					19.61212097143016
				],
				[
					24.212492628141263,
					21.06485628312396
				],
				[
					25.180993628357328,
					22.75974112781728
				],
				[
					26.14949462857362,
					24.454609783880187
				],
				[
					26.14949462857362,
					24.454609783880187
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "rectangle",
			"version": 1746,
			"versionNonce": 71721149,
			"isDeleted": false,
			"id": "VJD2Cx_Re4WkL2xCMtFRZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1343.5651670422642,
			"y": 893.136815546238,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 30.06690852493486,
			"height": 58.39289052926466,
			"seed": 285047746,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "vzJcis98KD_dKW07X-tFE",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				},
				{
					"id": "Hu4uXCeu4VvkrBmvqWU6g",
					"type": "arrow"
				},
				{
					"id": "IBPwfVWXfZpPhzalEUMar",
					"type": "arrow"
				},
				{
					"id": "yOomSOnvjfK4YOGn7Wpf8",
					"type": "arrow"
				}
			],
			"updated": 1677572906351,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 53,
			"versionNonce": 1508260958,
			"isDeleted": false,
			"id": "Yeo-Rad0ZgdwJZnW7zaRG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 421.2388099144292,
			"y": 1129.9907797212234,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 233.5610864516849,
			"height": 1.104272478213943,
			"seed": 1331499586,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					233.5610864516849,
					-1.104272478213943
				]
			]
		},
		{
			"type": "text",
			"version": 746,
			"versionNonce": 1274069122,
			"isDeleted": false,
			"id": "xTk1KlPD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 440.5135076279047,
			"y": 1102.6005090938418,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 187,
			"height": 20,
			"seed": 984360222,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmProductReceival ",
			"rawText": "confirmProductReceival ",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmProductReceival "
		},
		{
			"type": "arrow",
			"version": 189,
			"versionNonce": 1754085186,
			"isDeleted": false,
			"id": "6PFk31f6Qg7qiPrflktJ9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 723.257158467964,
			"y": 1166.2390384475477,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 605.5606493395276,
			"height": 2.9943156953486323,
			"seed": 1889470686,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722416562,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					605.5606493395276,
					-2.9943156953486323
				]
			]
		},
		{
			"type": "text",
			"version": 800,
			"versionNonce": 382296130,
			"isDeleted": false,
			"id": "oJGvFCRj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 756.6878139528932,
			"y": 1138.8487678201661,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 81,
			"height": 20,
			"seed": 861469698,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "sendMoney",
			"rawText": "sendMoney",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sendMoney"
		},
		{
			"type": "arrow",
			"version": 1586,
			"versionNonce": 1280302402,
			"isDeleted": false,
			"id": "ZCpty2gO9rUAGWC_4JNFO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1328.2131805123893,
			"y": 1205.307259366591,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 603.6612210700445,
			"height": 4.63225131365175,
			"seed": 93750622,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722413140,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-603.6612210700445,
					4.63225131365175
				]
			]
		},
		{
			"type": "text",
			"version": 696,
			"versionNonce": 83363842,
			"isDeleted": false,
			"id": "u19xkcJn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1053.6893325704784,
			"y": 1180.4481317299915,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 210,
			"height": 20,
			"seed": 688228226,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmTransactionSuccess",
			"rawText": "confirmTransactionSuccess",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmTransactionSuccess"
		},
		{
			"type": "arrow",
			"version": 1652,
			"versionNonce": 1819144478,
			"isDeleted": false,
			"id": "8DNxNuBbToe-kjtyWyFis",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 660.9017429888186,
			"y": 1236.4567177597671,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 252.43467192279672,
			"height": 0.381960261004906,
			"seed": 1728093150,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-252.43467192279672,
					-0.381960261004906
				]
			]
		},
		{
			"type": "text",
			"version": 783,
			"versionNonce": 1316730818,
			"isDeleted": false,
			"id": "uweLUDy0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 443.1093795444478,
			"y": 1198.4911124163452,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 210,
			"height": 20,
			"seed": 2077104386,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676722191679,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmTransactionSuccess",
			"rawText": "confirmTransactionSuccess",
			"baseline": 14,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmTransactionSuccess"
		},
		{
			"type": "rectangle",
			"version": 1770,
			"versionNonce": 307942803,
			"isDeleted": false,
			"id": "vEDpA89OYrsfAh4dtBTnF",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1347.298915712483,
			"y": 1157.11183156149,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 30.06690852493486,
			"height": 53.66085726608726,
			"seed": 2091471582,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "vzJcis98KD_dKW07X-tFE",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				},
				{
					"id": "Hu4uXCeu4VvkrBmvqWU6g",
					"type": "arrow"
				},
				{
					"id": "IBPwfVWXfZpPhzalEUMar",
					"type": "arrow"
				},
				{
					"id": "yOomSOnvjfK4YOGn7Wpf8",
					"type": "arrow"
				}
			],
			"updated": 1677572906351,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1860,
			"versionNonce": 1972715805,
			"isDeleted": false,
			"id": "ZAZ8iAKmp9P7rKK2ZiQya",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 675.4398895431357,
			"y": 1163.5068680339264,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 30.06690852493486,
			"height": 53.66085726608726,
			"seed": 1567259998,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				},
				{
					"id": "vzJcis98KD_dKW07X-tFE",
					"type": "arrow"
				},
				{
					"id": "_LV4qwTYC6y7KbREpJoED",
					"type": "arrow"
				},
				{
					"id": "Hu4uXCeu4VvkrBmvqWU6g",
					"type": "arrow"
				},
				{
					"id": "IBPwfVWXfZpPhzalEUMar",
					"type": "arrow"
				},
				{
					"id": "yOomSOnvjfK4YOGn7Wpf8",
					"type": "arrow"
				}
			],
			"updated": 1677572906351,
			"link": null,
			"locked": false
		},
		{
			"type": "freedraw",
			"version": 84,
			"versionNonce": 1011101186,
			"isDeleted": false,
			"id": "RktOa3WVekmRkdOWF3z97",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1377.1371183856907,
			"y": 1341.553640145752,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 25.423110784096252,
			"height": 17.675118970997914,
			"seed": 387843934,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722472443,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.1791353448013524,
					0.7263757501621058
				],
				[
					-5.326755501188359,
					1.9370020004321304
				],
				[
					-8.232242313206257,
					3.6318706564951526
				],
				[
					-11.864129158331707,
					5.810997906981356
				],
				[
					-15.253866470457751,
					8.23224231320637
				],
				[
					-18.40150281547517,
					10.895628158115755
				],
				[
					-20.82273912738492,
					12.832613969917588
				],
				[
					-23.001874472186387,
					14.769615970349719
				],
				[
					-24.212492628141263,
					15.980250314935006
				],
				[
					-24.938860283988106,
					16.70661797078185
				],
				[
					-25.180993628357328,
					17.190868470889882
				],
				[
					-25.423110784096252,
					17.675118970997914
				],
				[
					-25.423110784096252,
					17.675118970997914
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 84,
			"versionNonce": 1004481310,
			"isDeleted": false,
			"id": "9DustzX5Cv_JJJ0A3THYT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1351.9561247573336,
			"y": 1343.006391646076,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 26.14949462857362,
			"height": 24.454609783880187,
			"seed": 1999578498,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722472443,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.4842505001080326,
					0
				],
				[
					1.4527515003240978,
					0.24212525005407315
				],
				[
					2.9055030006481957,
					1.4527515003240978
				],
				[
					5.326755501188472,
					3.3897454064410795
				],
				[
					8.958626157683511,
					5.810997906981356
				],
				[
					15.01174931471894,
					9.927110969269279
				],
				[
					18.159369471105947,
					13.07474731428681
				],
				[
					20.580621971646224,
					15.253866470457751
				],
				[
					22.03337347197032,
					16.948735126520774
				],
				[
					23.001858283555976,
					18.40148662684487
				],
				[
					23.728242128033344,
					19.61212097143016
				],
				[
					24.212492628141263,
					21.06485628312396
				],
				[
					25.180993628357328,
					22.75974112781728
				],
				[
					26.14949462857362,
					24.454609783880187
				],
				[
					26.14949462857362,
					24.454609783880187
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 69,
			"versionNonce": 1399600926,
			"isDeleted": false,
			"id": "wbXD5t23dwHrSulctioOm",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 705.9518804224879,
			"y": 1338.9366948403733,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 25.423110784096252,
			"height": 17.675118970997914,
			"seed": 1431510466,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722475592,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.1791353448013524,
					0.7263757501621058
				],
				[
					-5.326755501188359,
					1.9370020004321304
				],
				[
					-8.232242313206257,
					3.6318706564951526
				],
				[
					-11.864129158331707,
					5.810997906981356
				],
				[
					-15.253866470457751,
					8.23224231320637
				],
				[
					-18.40150281547517,
					10.895628158115755
				],
				[
					-20.82273912738492,
					12.832613969917588
				],
				[
					-23.001874472186387,
					14.769615970349719
				],
				[
					-24.212492628141263,
					15.980250314935006
				],
				[
					-24.938860283988106,
					16.70661797078185
				],
				[
					-25.180993628357328,
					17.190868470889882
				],
				[
					-25.423110784096252,
					17.675118970997914
				],
				[
					-25.423110784096252,
					17.675118970997914
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 69,
			"versionNonce": 300732866,
			"isDeleted": false,
			"id": "kdr_w68V6FgbggUA_qunk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 680.7708867941308,
			"y": 1340.3894463406973,
			"strokeColor": "#000",
			"backgroundColor": "#ffffff",
			"width": 26.14949462857362,
			"height": 24.454609783880187,
			"seed": 860362590,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676722475592,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.4842505001080326,
					0
				],
				[
					1.4527515003240978,
					0.24212525005407315
				],
				[
					2.9055030006481957,
					1.4527515003240978
				],
				[
					5.326755501188472,
					3.3897454064410795
				],
				[
					8.958626157683511,
					5.810997906981356
				],
				[
					15.01174931471894,
					9.927110969269279
				],
				[
					18.159369471105947,
					13.07474731428681
				],
				[
					20.580621971646224,
					15.253866470457751
				],
				[
					22.03337347197032,
					16.948735126520774
				],
				[
					23.001858283555976,
					18.40148662684487
				],
				[
					23.728242128033344,
					19.61212097143016
				],
				[
					24.212492628141263,
					21.06485628312396
				],
				[
					25.180993628357328,
					22.75974112781728
				],
				[
					26.14949462857362,
					24.454609783880187
				],
				[
					26.14949462857362,
					24.454609783880187
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#d1d1d1",
		"currentItemStrokeColor": "#000",
		"currentItemBackgroundColor": "#d1d1d1",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "center",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "triangle",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%