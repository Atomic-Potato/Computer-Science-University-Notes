---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Creating post ^MF1moHnk

opened post creation ^2LnhbHHi

posted / closed post creation / logged out ^ot9dmdKh

adding attachment ^RsL7CHTT

clicked the "Add attachment" button ^Y4iSEnld

added attachment / canceled ^kJL89zsm

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "ellipse",
			"version": 486,
			"versionNonce": 842422749,
			"isDeleted": false,
			"id": "TOcsssHGmm8nLqGFDEbV2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -454.86393449336646,
			"y": -295.8719756148089,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1372015667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				}
			],
			"updated": 1676660734525,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 902,
			"versionNonce": 871387155,
			"isDeleted": false,
			"id": "HhdcyfoR90rZmFCyvJ6I6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -440.6650750372,
			"y": -436.8728748509282,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1877488893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660730310,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 755,
			"versionNonce": 2114629277,
			"isDeleted": false,
			"id": "3qOuJzQjSYjLd7un4_lqh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -459.83114452934177,
			"y": -453.46710759109664,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.62777420104499,
			"height": 75.37969110015035,
			"seed": 981260637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				}
			],
			"updated": 1676660730310,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 391,
			"versionNonce": 1607944595,
			"isDeleted": false,
			"id": "fXTDtliCcPk6XZLef5gVC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 6.232517823296007,
			"y": -322.12395876341986,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1121724083,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "Pk-6A3cnXPU-3Xm0ye0Tx",
					"type": "arrow"
				},
				{
					"id": "m4SsamIhs3UJpRQ3qkL_x",
					"type": "arrow"
				}
			],
			"updated": 1676660713270,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 223,
			"versionNonce": 1681087613,
			"isDeleted": false,
			"id": "MF1moHnk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 98.81584447838287,
			"y": -288.32939790869943,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 136,
			"height": 25,
			"seed": 1357518397,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660683298,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Creating post",
			"rawText": "Creating post",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Creating post"
		},
		{
			"type": "arrow",
			"version": 461,
			"versionNonce": 292099645,
			"isDeleted": false,
			"id": "rvqnbU6IYXNetkUznSOWn",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -400.334478699747,
			"y": -279.4542142445666,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 398.92466278396034,
			"height": 2.2215087197823777,
			"seed": 43366419,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660734526,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TOcsssHGmm8nLqGFDEbV2",
				"focus": -0.21013247900507664,
				"gap": 11.231431061886603
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.035914352207139455,
				"gap": 7.642333739082687
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					398.92466278396034,
					-2.2215087197823777
				]
			]
		},
		{
			"type": "text",
			"version": 86,
			"versionNonce": 216785715,
			"isDeleted": false,
			"id": "2LnhbHHi",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -307.4060442548044,
			"y": -311.5632621080254,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 208,
			"height": 25,
			"seed": 549029075,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660740087,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened post creation",
			"rawText": "opened post creation",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened post creation"
		},
		{
			"type": "arrow",
			"version": 295,
			"versionNonce": 1077073331,
			"isDeleted": false,
			"id": "MU1uLPLGF985i4XvrLCCU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 123.74602733652584,
			"y": -330.153754998936,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 491.8015122549362,
			"height": 89.3551772928443,
			"seed": 353991219,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660730310,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.027262815384043633,
				"gap": 8.029796235516159
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": -0.10284572345703547,
				"gap": 9.307711600025172
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-54.78694727436293,
					-88.10299786624614
				],
				[
					-491.8015122549362,
					-89.3551772928443
				]
			]
		},
		{
			"type": "text",
			"version": 197,
			"versionNonce": 1239008253,
			"isDeleted": false,
			"id": "ot9dmdKh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -336.5831790782772,
			"y": -464.63131313587223,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 432,
			"height": 25,
			"seed": 425195165,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660738104,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "posted / closed post creation / logged out",
			"rawText": "posted / closed post creation / logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "posted / closed post creation / logged out"
		},
		{
			"type": "rectangle",
			"version": 554,
			"versionNonce": 402562867,
			"isDeleted": false,
			"id": "MiAYYPI94i7mVse3G1zOt",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 839.6542525884887,
			"y": -321.9908601140505,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1285211667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "Pk-6A3cnXPU-3Xm0ye0Tx",
					"type": "arrow"
				},
				{
					"id": "m4SsamIhs3UJpRQ3qkL_x",
					"type": "arrow"
				}
			],
			"updated": 1676660713270,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 379,
			"versionNonce": 1374063837,
			"isDeleted": false,
			"id": "RsL7CHTT",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 915.22818224017,
			"y": -289.87236738490776,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 185,
			"height": 25,
			"seed": 1944754333,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660707817,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "adding attachment",
			"rawText": "adding attachment",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "adding attachment"
		},
		{
			"type": "arrow",
			"version": 391,
			"versionNonce": 1841479773,
			"isDeleted": false,
			"id": "Pk-6A3cnXPU-3Xm0ye0Tx",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": 323.62873351858866,
			"y": -260.7634700578725,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 510.3056271559658,
			"height": 0.13827680242377483,
			"seed": 279613075,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660713270,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "MiAYYPI94i7mVse3G1zOt",
				"focus": -0.4951057192769884,
				"gap": 5.719891913934305
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.4928495001185567,
				"gap": 11.587459426322255
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					510.3056271559658,
					0.13827680242377483
				]
			]
		},
		{
			"type": "arrow",
			"version": 413,
			"versionNonce": 592055581,
			"isDeleted": false,
			"id": "m4SsamIhs3UJpRQ3qkL_x",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 324.40413514714305,
			"y": -307.17892398788,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 510.30562715596557,
			"height": 2.4445607318726275,
			"seed": 268015645,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676660713270,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.6438107819571274,
				"gap": 12.362861054876646
			},
			"endBinding": {
				"elementId": "MiAYYPI94i7mVse3G1zOt",
				"focus": 0.5514647527710969,
				"gap": 4.944490285380141
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					510.30562715596557,
					2.4445607318726275
				]
			]
		},
		{
			"type": "text",
			"version": 234,
			"versionNonce": 714294173,
			"isDeleted": false,
			"id": "Y4iSEnld",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 377.4659575729395,
			"y": -333.5771290693508,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 363,
			"height": 25,
			"seed": 941704243,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660712728,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the \"Add attachment\" button",
			"rawText": "clicked the \"Add attachment\" button",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the \"Add attachment\" button"
		},
		{
			"type": "text",
			"version": 367,
			"versionNonce": 1844056243,
			"isDeleted": false,
			"id": "kJL89zsm",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 440.2434870478585,
			"y": -245.45322763593924,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 295,
			"height": 25,
			"seed": 1219136637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676660712728,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "added attachment / canceled",
			"rawText": "added attachment / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "added attachment / canceled"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#f1f3f5",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%