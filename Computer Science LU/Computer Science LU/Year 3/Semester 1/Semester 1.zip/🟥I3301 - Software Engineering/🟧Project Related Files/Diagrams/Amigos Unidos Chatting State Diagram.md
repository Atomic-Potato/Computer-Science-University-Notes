---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
browsing chats list ^MF1moHnk

browsing messages ^clo0ga6V

typing a message ^xPkNUj3t

opened a user chat ^V9yTNArc

adding a user to chat list ^E3hYIa6p

pressed the "Add user" button ^NyocFbtQ

pressed on the input box ^hiaC2njj

sent a message / canceled typing ^rDjMKRpg

returned to chats list ^VJGOHnIM

Added user / canceled ^R5LNPSfu

opened chatting ^2LnhbHHi

closed chatting / logged out ^ot9dmdKh

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "ellipse",
			"version": 452,
			"versionNonce": 911444019,
			"isDeleted": false,
			"id": "TOcsssHGmm8nLqGFDEbV2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -362.4785467754262,
			"y": -297.27170954858093,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1372015667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				}
			],
			"updated": 1676658309888,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 866,
			"versionNonce": 816744573,
			"isDeleted": false,
			"id": "HhdcyfoR90rZmFCyvJ6I6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -362.2774478125494,
			"y": -436.8728748509282,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1877488893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 719,
			"versionNonce": 1572473299,
			"isDeleted": false,
			"id": "3qOuJzQjSYjLd7un4_lqh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -381.44351730469117,
			"y": -453.46710759109664,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.62777420104499,
			"height": 75.37969110015035,
			"seed": 981260637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				}
			],
			"updated": 1676658309888,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 331,
			"versionNonce": 1197060925,
			"isDeleted": false,
			"id": "fXTDtliCcPk6XZLef5gVC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -88.45878793585723,
			"y": -320.1854643883445,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1121724083,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "gFsFcI5Ax0g_69j_3VGzi",
					"type": "arrow"
				},
				{
					"id": "ElZnece0MPhMNd9dzh__l",
					"type": "arrow"
				},
				{
					"id": "tAZq6w3kV_nzp-TlrFGjy",
					"type": "arrow"
				},
				{
					"id": "8NZuSBiZAesohQIL-RhLr",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				}
			],
			"updated": 1676658314768,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 131,
			"versionNonce": 69162867,
			"isDeleted": false,
			"id": "MF1moHnk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -26.882665572528936,
			"y": -288.0669716592017,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 186,
			"height": 25,
			"seed": 1357518397,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing chats list",
			"rawText": "browsing chats list",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing chats list"
		},
		{
			"type": "rectangle",
			"version": 564,
			"versionNonce": 953118333,
			"isDeleted": false,
			"id": "knQwXUFmqoIxN6FfPwZ2y",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 491.0917725997173,
			"y": -330.71459716268845,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 867397747,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "gFsFcI5Ax0g_69j_3VGzi",
					"type": "arrow"
				},
				{
					"id": "qlYSNMFRrxC2LTDa4Q0-_",
					"type": "arrow"
				},
				{
					"id": "pdFN02Wpw7nPVtiJ3EmPg",
					"type": "arrow"
				},
				{
					"id": "tAZq6w3kV_nzp-TlrFGjy",
					"type": "arrow"
				}
			],
			"updated": 1676658311920,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 502,
			"versionNonce": 2009723155,
			"isDeleted": false,
			"id": "clo0ga6V",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 552.6318366491965,
			"y": -302.59056102337075,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 179,
			"height": 25,
			"seed": 667960381,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing messages",
			"rawText": "browsing messages",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing messages"
		},
		{
			"type": "rectangle",
			"version": 711,
			"versionNonce": 285377491,
			"isDeleted": false,
			"id": "PLfG_KfEz_fTErbjM7bSO",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1229.3202225187326,
			"y": -345.71368733987373,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 167160467,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "qlYSNMFRrxC2LTDa4Q0-_",
					"type": "arrow"
				},
				{
					"id": "pdFN02Wpw7nPVtiJ3EmPg",
					"type": "arrow"
				}
			],
			"updated": 1676658311920,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 603,
			"versionNonce": 2049988275,
			"isDeleted": false,
			"id": "xPkNUj3t",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1299.6958344981015,
			"y": -317.5949723427196,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 169,
			"height": 25,
			"seed": 906837021,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "typing a message",
			"rawText": "typing a message",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "typing a message"
		},
		{
			"type": "arrow",
			"version": 287,
			"versionNonce": 1085006333,
			"isDeleted": false,
			"id": "rvqnbU6IYXNetkUznSOWn",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -307.9176873721141,
			"y": -280.63804088806484,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 211.81656569717416,
			"height": 0.02093728152846097,
			"seed": 43366419,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TOcsssHGmm8nLqGFDEbV2",
				"focus": -0.21013247900507664,
				"gap": 11.231431061886603
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.035914352207139455,
				"gap": 7.642333739082687
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					211.81656569717416,
					0.02093728152846097
				]
			]
		},
		{
			"type": "arrow",
			"version": 183,
			"versionNonce": 1509492819,
			"isDeleted": false,
			"id": "gFsFcI5Ax0g_69j_3VGzi",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 227.05243346318787,
			"y": -303.75629861351325,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 256.94641257197014,
			"height": 0.6194982879208624,
			"seed": 812854099,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.5850670009802375,
				"gap": 9.7024651300747
			},
			"endBinding": {
				"elementId": "knQwXUFmqoIxN6FfPwZ2y",
				"focus": 0.3646406024536411,
				"gap": 7.0929265645593205
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					256.94641257197014,
					-0.6194982879208624
				]
			]
		},
		{
			"type": "arrow",
			"version": 530,
			"versionNonce": 607689309,
			"isDeleted": false,
			"id": "qlYSNMFRrxC2LTDa4Q0-_",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 802.1340682793606,
			"y": -320.93438506459427,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 420.544087440015,
			"height": 2.004311880960927,
			"seed": 2091305437,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "knQwXUFmqoIxN6FfPwZ2y",
				"focus": -0.7675404078613978,
				"gap": 5.23353941067279
			},
			"endBinding": {
				"elementId": "PLfG_KfEz_fTErbjM7bSO",
				"focus": 0.32342630506291253,
				"gap": 6.6420667993569396
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					420.544087440015,
					2.004311880960927
				]
			]
		},
		{
			"type": "text",
			"version": 279,
			"versionNonce": 1291486707,
			"isDeleted": false,
			"id": "V9yTNArc",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 247.17667383122227,
			"y": -331.38107834055285,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 195,
			"height": 25,
			"seed": 482123283,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened a user chat",
			"rawText": "opened a user chat",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened a user chat"
		},
		{
			"type": "rectangle",
			"version": 620,
			"versionNonce": 985393939,
			"isDeleted": false,
			"id": "oqCAlBIDl49gSVW6t6qB7",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 497.4622383471493,
			"y": -126.6898614719725,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1466423379,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "gFsFcI5Ax0g_69j_3VGzi",
					"type": "arrow"
				},
				{
					"id": "qlYSNMFRrxC2LTDa4Q0-_",
					"type": "arrow"
				},
				{
					"id": "ElZnece0MPhMNd9dzh__l",
					"type": "arrow"
				},
				{
					"id": "8NZuSBiZAesohQIL-RhLr",
					"type": "arrow"
				}
			],
			"updated": 1676658314768,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 581,
			"versionNonce": 171659155,
			"isDeleted": false,
			"id": "E3hYIa6p",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 518.6708015652597,
			"y": -96.11066907466278,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 266,
			"height": 25,
			"seed": 366922333,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "adding a user to chat list",
			"rawText": "adding a user to chat list",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "adding a user to chat list"
		},
		{
			"type": "arrow",
			"version": 194,
			"versionNonce": 1167157021,
			"isDeleted": false,
			"id": "ElZnece0MPhMNd9dzh__l",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 60.63658780319963,
			"y": -227.44217592583414,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 425.0626441393821,
			"height": 145.20045491202666,
			"seed": 1618416883,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.11544107533075433,
				"gap": 10.624499266200843
			},
			"endBinding": {
				"elementId": "oqCAlBIDl49gSVW6t6qB7",
				"focus": -0.15564044854999426,
				"gap": 11.763006404567648
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					40.398520294598654,
					137.0037200707764
				],
				[
					425.0626441393821,
					145.20045491202666
				]
			]
		},
		{
			"type": "text",
			"version": 381,
			"versionNonce": 603055411,
			"isDeleted": false,
			"id": "NyocFbtQ",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 120.90375349556999,
			"y": -63.61453844893964,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 303,
			"height": 25,
			"seed": 2038678173,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "pressed the \"Add user\" button",
			"rawText": "pressed the \"Add user\" button",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "pressed the \"Add user\" button"
		},
		{
			"type": "text",
			"version": 387,
			"versionNonce": 946895741,
			"isDeleted": false,
			"id": "hiaC2njj",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 875.6152240477011,
			"y": -350.07343141826124,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 247,
			"height": 25,
			"seed": 1101877725,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "qlYSNMFRrxC2LTDa4Q0-_",
					"type": "arrow"
				}
			],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "pressed on the input box",
			"rawText": "pressed on the input box",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "pressed on the input box"
		},
		{
			"type": "arrow",
			"version": 210,
			"versionNonce": 562349779,
			"isDeleted": false,
			"id": "pdFN02Wpw7nPVtiJ3EmPg",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1222.8828768699295,
			"y": -282.09188497522064,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 414.16114572806055,
			"height": 0.7907912245114517,
			"seed": 1983763325,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "PLfG_KfEz_fTErbjM7bSO",
				"focus": -0.536814045315067,
				"gap": 6.437345648802989
			},
			"endBinding": {
				"elementId": "knQwXUFmqoIxN6FfPwZ2y",
				"focus": 0.20963362035797115,
				"gap": 11.821202273181314
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-414.16114572806055,
					0.7907912245114517
				]
			]
		},
		{
			"type": "text",
			"version": 501,
			"versionNonce": 992871389,
			"isDeleted": false,
			"id": "rDjMKRpg",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 855.0173993922355,
			"y": -275.9232994249603,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 333,
			"height": 25,
			"seed": 249099805,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "qlYSNMFRrxC2LTDa4Q0-_",
					"type": "arrow"
				}
			],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "sent a message / canceled typing",
			"rawText": "sent a message / canceled typing",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sent a message / canceled typing"
		},
		{
			"type": "arrow",
			"version": 197,
			"versionNonce": 1502246003,
			"isDeleted": false,
			"id": "tAZq6w3kV_nzp-TlrFGjy",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 485.5326557377877,
			"y": -268.5166433261918,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 257.90665606657564,
			"height": 1.4398251266447915,
			"seed": 554157363,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309888,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "knQwXUFmqoIxN6FfPwZ2y",
				"focus": -0.48323645884273353,
				"gap": 5.559116861929624
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.3092176390349246,
				"gap": 10.276031338098903
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-257.90665606657564,
					1.4398251266447915
				]
			]
		},
		{
			"type": "text",
			"version": 75,
			"versionNonce": 836468797,
			"isDeleted": false,
			"id": "VJGOHnIM",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 249.92230990367153,
			"y": -256.9073488601971,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 224,
			"height": 25,
			"seed": 1202967101,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309889,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to chats list",
			"rawText": "returned to chats list",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to chats list"
		},
		{
			"type": "arrow",
			"version": 175,
			"versionNonce": 197750291,
			"isDeleted": false,
			"id": "8NZuSBiZAesohQIL-RhLr",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 486.53038358655533,
			"y": -109.78436724082758,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 407.2812450166142,
			"height": 120.4761451328875,
			"seed": 1541665533,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309889,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "oqCAlBIDl49gSVW6t6qB7",
				"focus": 0.4861200063663049,
				"gap": 10.931854760594035
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.038344613037703,
				"gap": 7.806162818319905
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-357.3825285349637,
					-6.293509333891961
				],
				[
					-407.2812450166142,
					-120.4761451328875
				]
			]
		},
		{
			"type": "text",
			"version": 99,
			"versionNonce": 431946227,
			"isDeleted": false,
			"id": "R5LNPSfu",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 182.08498957717762,
			"y": -143.18263852567713,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 223,
			"height": 25,
			"seed": 1311563677,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658325750,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Added user / canceled",
			"rawText": "Added user / canceled",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Added user / canceled"
		},
		{
			"type": "text",
			"version": 50,
			"versionNonce": 993538995,
			"isDeleted": false,
			"id": "2LnhbHHi",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -299.0074534719192,
			"y": -311.5632621080254,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 155,
			"height": 25,
			"seed": 549029075,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309889,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "opened chatting",
			"rawText": "opened chatting",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "opened chatting"
		},
		{
			"type": "arrow",
			"version": 158,
			"versionNonce": 1516000509,
			"isDeleted": false,
			"id": "MU1uLPLGF985i4XvrLCCU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 62.463131805093326,
			"y": -328.2152606238606,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 352.12841165409964,
			"height": 91.26596458456362,
			"seed": 353991219,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676658309889,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.12953943637633578,
				"gap": 8.029796235516159
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": -0.13685936813840463,
				"gap": 9.307711600024952
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-40.961847432780246,
					-82.28307021972984
				],
				[
					-352.12841165409964,
					-91.26596458456362
				]
			]
		},
		{
			"type": "text",
			"version": 124,
			"versionNonce": 1207780691,
			"isDeleted": false,
			"id": "ot9dmdKh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -263.794674768968,
			"y": -464.63131313587223,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 284,
			"height": 25,
			"seed": 425195165,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676658309889,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "closed chatting / logged out",
			"rawText": "closed chatting / logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "closed chatting / logged out"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#f1f3f5",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%