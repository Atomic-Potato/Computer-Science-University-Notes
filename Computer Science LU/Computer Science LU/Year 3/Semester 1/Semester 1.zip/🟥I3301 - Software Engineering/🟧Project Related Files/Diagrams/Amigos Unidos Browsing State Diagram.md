---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
browsing posts feed ^MF1moHnk

logged in ^2LnhbHHi

logged out ^ot9dmdKh

searching for a user ^5UalC7nG

browsing user search results ^7E1J8CqK

browsing a user profile ^KJmTQfES

browsing own user profile ^BIqrCHqE

writing a comment ^sRfpAgIo

browsing comments ^8qlIY9z5

logged out ^Gy2EeojP

logged out ^6hq48ZsV

clicked on own profile picture ^WMCEY4VG

returned to posts feed ^CujzXy00

clicked on poster
profile picture ^GvRrRwCr

clicked the 
search bar ^uH6DNeZm

clicked the search key ^FVUhny7v

clicked the search bar ^G5nJJcvg

clicked a user from 
the search results ^wp4DKKxz

clicked on a post ^hhnmTw1d

clicked the 
"Comment" button ^YrfVyMZY

posted comment /
canceled ^sGOhXa1g

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "ellipse",
			"version": 790,
			"versionNonce": 1496973085,
			"isDeleted": false,
			"id": "TOcsssHGmm8nLqGFDEbV2",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -207.686575719328,
			"y": -305.70286128187627,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1372015667,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				}
			],
			"updated": 1676662685813,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1064,
			"versionNonce": 1857998131,
			"isDeleted": false,
			"id": "HhdcyfoR90rZmFCyvJ6I6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -452.4020047944544,
			"y": -22.168677376039852,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 43.64067748954198,
			"height": 42.109422055501966,
			"seed": 1877488893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685813,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 919,
			"versionNonce": 2068190077,
			"isDeleted": false,
			"id": "3qOuJzQjSYjLd7un4_lqh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -471.5680742865962,
			"y": -38.762910116208275,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.62777420104499,
			"height": 75.37969110015035,
			"seed": 981260637,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "EXKOSaiffIbkYORgp9_kf",
					"type": "arrow"
				},
				{
					"id": "0Y8KtOEW1YJ1Y8zF0FAtp",
					"type": "arrow"
				}
			],
			"updated": 1676662685813,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 408,
			"versionNonce": 1383378643,
			"isDeleted": false,
			"id": "fXTDtliCcPk6XZLef5gVC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 6.232517823296007,
			"y": -322.12395876341986,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1121724083,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "nrZXykmDa0u8uv5TlbUfT",
					"type": "arrow"
				},
				{
					"id": "mRHT4ddCUberUvO3yKcYq",
					"type": "arrow"
				},
				{
					"id": "s58RBTx6qHPnax3QXdRlz",
					"type": "arrow"
				},
				{
					"id": "NrGOY0X1p_HOlQc95OIRj",
					"type": "arrow"
				},
				{
					"id": "GF5vgksdpLD9CED2DJW97",
					"type": "arrow"
				}
			],
			"updated": 1676662685813,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 318,
			"versionNonce": 1066441693,
			"isDeleted": false,
			"id": "MF1moHnk",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 64.02926606013392,
			"y": -291.18630022786186,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 196,
			"height": 25,
			"seed": 1357518397,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685813,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing posts feed",
			"rawText": "browsing posts feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing posts feed"
		},
		{
			"type": "arrow",
			"version": 1061,
			"versionNonce": 876436595,
			"isDeleted": false,
			"id": "rvqnbU6IYXNetkUznSOWn",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -153.02998481493688,
			"y": -288.32915254439513,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 151.62016889915017,
			"height": 2.763584738181919,
			"seed": 43366419,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TOcsssHGmm8nLqGFDEbV2",
				"focus": -0.21013247900507664,
				"gap": 11.231431061886603
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.035914352207139455,
				"gap": 7.642333739082687
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					151.62016889915017,
					2.763584738181919
				]
			]
		},
		{
			"type": "text",
			"version": 150,
			"versionNonce": 1043011645,
			"isDeleted": false,
			"id": "2LnhbHHi",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -130.44953884615057,
			"y": -318.5853098844677,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 84,
			"height": 25,
			"seed": 549029075,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged in",
			"rawText": "logged in",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged in"
		},
		{
			"type": "arrow",
			"version": 834,
			"versionNonce": 1608472083,
			"isDeleted": false,
			"id": "MU1uLPLGF985i4XvrLCCU",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 162.86912652737414,
			"y": -231.04207810161466,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 593.4246172409221,
			"height": 181.58934684319217,
			"seed": 353991219,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.376581439006005,
				"gap": 8.963091465495694
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": -0.4919280095106303,
				"gap": 10.69063205147264
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-57.604036026259394,
					36.97045383581826
				],
				[
					-528.1757499389835,
					35.78668544848591
				],
				[
					-593.4246172409221,
					181.58934684319217
				]
			]
		},
		{
			"type": "text",
			"version": 335,
			"versionNonce": 284625053,
			"isDeleted": false,
			"id": "ot9dmdKh",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -173.42815057406648,
			"y": -192.4376985229461,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 25,
			"seed": 425195165,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged out",
			"rawText": "logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged out"
		},
		{
			"type": "rectangle",
			"version": 779,
			"versionNonce": 1683037107,
			"isDeleted": false,
			"id": "lz2_83u6oN41TVBqqDHrK",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 627.509287623081,
			"y": -480.2227680393984,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 2089241725,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "Q9-xJzSkEjmyG0NEhFo8C",
					"type": "arrow"
				},
				{
					"id": "EgvAMbYiedTCf38MM75Pr",
					"type": "arrow"
				},
				{
					"id": "s58RBTx6qHPnax3QXdRlz",
					"type": "arrow"
				}
			],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 778,
			"versionNonce": 430304509,
			"isDeleted": false,
			"id": "5UalC7nG",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 679.9383019707923,
			"y": -450.8118698593248,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 204,
			"height": 25,
			"seed": 1807713747,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "searching for a user",
			"rawText": "searching for a user",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "searching for a user"
		},
		{
			"type": "rectangle",
			"version": 834,
			"versionNonce": 767110483,
			"isDeleted": false,
			"id": "ix2XQbipsKqzaSL0rUZnC",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1223.2060683275863,
			"y": -473.37153941095437,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1170229715,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "EgvAMbYiedTCf38MM75Pr",
					"type": "arrow"
				},
				{
					"id": "Pto8thcQxjqUksx8UXefv",
					"type": "arrow"
				}
			],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 918,
			"versionNonce": 129582429,
			"isDeleted": false,
			"id": "7E1J8CqK",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1235.9914706987665,
			"y": -443.9606412308808,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 283,
			"height": 25,
			"seed": 748695773,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing user search results",
			"rawText": "browsing user search results",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing user search results"
		},
		{
			"type": "rectangle",
			"version": 983,
			"versionNonce": 920898141,
			"isDeleted": false,
			"id": "BNGb2gHVa0Uh0HuIKpF32",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 627.1687300074799,
			"y": -286.8235927779808,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1773113363,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "mKhR6AASXa5YJgkqiOidx",
					"type": "arrow"
				},
				{
					"id": "Pto8thcQxjqUksx8UXefv",
					"type": "arrow"
				},
				{
					"id": "0Y8KtOEW1YJ1Y8zF0FAtp",
					"type": "arrow"
				},
				{
					"id": "GF5vgksdpLD9CED2DJW97",
					"type": "arrow"
				}
			],
			"updated": 1676662746186,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1011,
			"versionNonce": 511873469,
			"isDeleted": false,
			"id": "KJmTQfES",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 668.8415135943062,
			"y": -255.17656474848093,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 224,
			"height": 25,
			"seed": 1994354333,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing a user profile",
			"rawText": "browsing a user profile",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing a user profile"
		},
		{
			"type": "rectangle",
			"version": 817,
			"versionNonce": 1844851859,
			"isDeleted": false,
			"id": "_7Com-JR_A8evd7JjqRDp",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 625.5821494933367,
			"y": -42.735335303978985,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 53471507,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "nrZXykmDa0u8uv5TlbUfT",
					"type": "arrow"
				},
				{
					"id": "mRHT4ddCUberUvO3yKcYq",
					"type": "arrow"
				},
				{
					"id": "EXKOSaiffIbkYORgp9_kf",
					"type": "arrow"
				},
				{
					"id": "mKhR6AASXa5YJgkqiOidx",
					"type": "arrow"
				}
			],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 866,
			"versionNonce": 223170903,
			"isDeleted": false,
			"id": "BIqrCHqE",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 659.1171081883938,
			"y": -15.944811853420362,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 243,
			"height": 25,
			"seed": 1995253149,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678218264589,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing own user profile",
			"rawText": "browsing own user profile",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing own user profile"
		},
		{
			"type": "rectangle",
			"version": 1059,
			"versionNonce": 2030578227,
			"isDeleted": false,
			"id": "6u0K9QWtC66rrmF5mukLq",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1220.041236680827,
			"y": -731.7663518966201,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1090181661,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "pwQ2H4RFdcS3BcJ_6LCou",
					"type": "arrow"
				},
				{
					"id": "dXXRLeiDRQLwmN38UaRV6",
					"type": "arrow"
				}
			],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1118,
			"versionNonce": 445449853,
			"isDeleted": false,
			"id": "sRfpAgIo",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1286.3166682781787,
			"y": -702.3554537165464,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 25,
			"seed": 72163891,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "writing a comment",
			"rawText": "writing a comment",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "writing a comment"
		},
		{
			"type": "rectangle",
			"version": 932,
			"versionNonce": 1703570387,
			"isDeleted": false,
			"id": "JUZ2EsSgicNNQp4PJrsHF",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 624.4142819193565,
			"y": -731.4437342626705,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 305.8087562689704,
			"height": 82.11878919630946,
			"seed": 1644455581,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "rvqnbU6IYXNetkUznSOWn",
					"type": "arrow"
				},
				{
					"id": "MU1uLPLGF985i4XvrLCCU",
					"type": "arrow"
				},
				{
					"id": "NrGOY0X1p_HOlQc95OIRj",
					"type": "arrow"
				},
				{
					"id": "pwQ2H4RFdcS3BcJ_6LCou",
					"type": "arrow"
				},
				{
					"id": "dXXRLeiDRQLwmN38UaRV6",
					"type": "arrow"
				}
			],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1009,
			"versionNonce": 1602301661,
			"isDeleted": false,
			"id": "8qlIY9z5",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 689.8202822481073,
			"y": -702.032836082597,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 178,
			"height": 25,
			"seed": 2077269427,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "browsing comments",
			"rawText": "browsing comments",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "browsing comments"
		},
		{
			"type": "arrow",
			"version": 202,
			"versionNonce": 932411763,
			"isDeleted": false,
			"id": "nrZXykmDa0u8uv5TlbUfT",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 185.1675621982415,
			"y": -231.02975825433032,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 424.64793613978793,
			"height": 229.69610173408023,
			"seed": 1987943699,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.11280390024311396,
				"gap": 8.97541131278004
			},
			"endBinding": {
				"elementId": "_7Com-JR_A8evd7JjqRDp",
				"focus": -0.2559425877837526,
				"gap": 15.76665115530733
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					31.950400216238847,
					198.87551443917408
				],
				[
					424.64793613978793,
					229.69610173408023
				]
			]
		},
		{
			"type": "arrow",
			"version": 197,
			"versionNonce": 1485916989,
			"isDeleted": false,
			"id": "mRHT4ddCUberUvO3yKcYq",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 613.7278518536543,
			"y": -25.875320564929268,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 405.08647373744407,
			"height": 202.54623107667769,
			"seed": 968007123,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "_7Com-JR_A8evd7JjqRDp",
				"focus": 0.29615025923974647,
				"gap": 11.85429763968233
			},
			"endBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.24695766326844873,
				"gap": 11.583617925503319
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-371.1798313685825,
					-21.27613307165541
				],
				[
					-405.08647373744407,
					-202.54623107667769
				]
			]
		},
		{
			"type": "arrow",
			"version": 518,
			"versionNonce": 745132819,
			"isDeleted": false,
			"id": "EXKOSaiffIbkYORgp9_kf",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 747.7318290192036,
			"y": 47.72197470814183,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1175.6548582516261,
			"height": 82.63421720766863,
			"seed": 2019963645,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "_7Com-JR_A8evd7JjqRDp",
				"focus": -0.21360319855226867,
				"gap": 8.33852081581135
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": 1.1875189449370875,
				"gap": 15.876896825302026
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-128.98395743475976,
					82.63421720766863
				],
				[
					-1053.069419932011,
					72.05152239118303
				],
				[
					-1175.6548582516261,
					4.727260044642776
				]
			]
		},
		{
			"type": "text",
			"version": 368,
			"versionNonce": 102685597,
			"isDeleted": false,
			"id": "Gy2EeojP",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 90.616874377248,
			"y": 102.35306802208515,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 25,
			"seed": 464204691,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged out",
			"rawText": "logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged out"
		},
		{
			"type": "rectangle",
			"version": 85,
			"versionNonce": 344193203,
			"isDeleted": false,
			"id": "yrPx6TCZwXTjpddmKS6bF",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 549.9026986300992,
			"y": -806.1771541301496,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1045.652188387784,
			"height": 655.6072443181818,
			"seed": 1823727901,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 74,
			"versionNonce": 1616601085,
			"isDeleted": false,
			"id": "DbdEFc5QPSjC37DArOk53",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 548.2429862721447,
			"y": -567.170917446911,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1045.652188387784,
			"height": 0,
			"seed": 1970173053,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1045.652188387784,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 38,
			"versionNonce": 1880389309,
			"isDeleted": false,
			"id": "mKhR6AASXa5YJgkqiOidx",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 773.6743258748904,
			"y": -191.72602583546325,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.9067721209526098,
			"height": 137.5558104560439,
			"seed": 2051774333,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662746186,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "BNGb2gHVa0Uh0HuIKpF32",
				"focus": 0.04400749720854916,
				"gap": 12.978777746208095
			},
			"endBinding": {
				"elementId": "_7Com-JR_A8evd7JjqRDp",
				"focus": -0.023237374023656217,
				"gap": 11.434880075440361
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.9067721209526098,
					137.5558104560439
				]
			]
		},
		{
			"type": "arrow",
			"version": 73,
			"versionNonce": 1565022301,
			"isDeleted": false,
			"id": "Q9-xJzSkEjmyG0NEhFo8C",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 946.9936194710917,
			"y": -455.8334233872307,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 255.60388901654414,
			"height": 2.147934857536768,
			"seed": 1849754173,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "lz2_83u6oN41TVBqqDHrK",
				"focus": -0.3606202926908987,
				"gap": 13.675575579040242
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					255.60388901654414,
					-2.147934857536768
				]
			]
		},
		{
			"type": "arrow",
			"version": 53,
			"versionNonce": 1011722227,
			"isDeleted": false,
			"id": "EgvAMbYiedTCf38MM75Pr",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1207.9673097284447,
			"y": -413.94872956829676,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 262.0476935891544,
			"height": 4.295833812040428,
			"seed": 915432307,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ix2XQbipsKqzaSL0rUZnC",
				"focus": -0.4847779880368325,
				"gap": 15.238758599141761
			},
			"endBinding": {
				"elementId": "lz2_83u6oN41TVBqqDHrK",
				"focus": 0.4178858310029697,
				"gap": 12.601572247238778
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-262.0476935891544,
					-4.295833812040428
				]
			]
		},
		{
			"type": "arrow",
			"version": 118,
			"versionNonce": 580984723,
			"isDeleted": false,
			"id": "Pto8thcQxjqUksx8UXefv",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1341.1390554775255,
			"y": -382.80371003704676,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 397.2791073978166,
			"height": 140.1588554867986,
			"seed": 1454638941,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662746186,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ix2XQbipsKqzaSL0rUZnC",
				"focus": 0.11259491172729372,
				"gap": 8.449040177598107
			},
			"endBinding": {
				"elementId": "BNGb2gHVa0Uh0HuIKpF32",
				"focus": 0.1343692107087195,
				"gap": 10.882461803258593
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-44.0325927734375,
					134.2457131778492
				],
				[
					-397.2791073978166,
					140.1588554867986
				]
			]
		},
		{
			"type": "arrow",
			"version": 170,
			"versionNonce": 651833747,
			"isDeleted": false,
			"id": "s58RBTx6qHPnax3QXdRlz",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 323.15891768821245,
			"y": -279.1449102689154,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 288.7991055575284,
			"height": 154.35813210227275,
			"seed": 1061401811,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.542743308477259,
				"gap": 11.11764359594605
			},
			"endBinding": {
				"elementId": "lz2_83u6oN41TVBqqDHrK",
				"focus": 0.0885264608474947,
				"gap": 15.551264377340203
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					55.30626145926351,
					-13.899258558407155
				],
				[
					81.3285966352982,
					-141.90990101207387
				],
				[
					288.7991055575284,
					-154.35813210227275
				]
			]
		},
		{
			"type": "arrow",
			"version": 108,
			"versionNonce": 1883874589,
			"isDeleted": false,
			"id": "NrGOY0X1p_HOlQc95OIRj",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 172.63198519113695,
			"y": -329.45020681491405,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 438.1780450994318,
			"height": 360.16901189630676,
			"seed": 1042407795,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": 0.03737824336738134,
				"gap": 7.326248051494218
			},
			"endBinding": {
				"elementId": "JUZ2EsSgicNNQp4PJrsHF",
				"focus": 0.29207735269385515,
				"gap": 13.604251628787836
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					49.79292436079555,
					-319.5048384232955
				],
				[
					438.1780450994318,
					-360.16901189630676
				]
			]
		},
		{
			"type": "arrow",
			"version": 63,
			"versionNonce": 1315211059,
			"isDeleted": false,
			"id": "pwQ2H4RFdcS3BcJ_6LCou",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 940.1254638947637,
			"y": -716.2210096850692,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 271.71336454503694,
			"height": 1.0739674287683556,
			"seed": 56354515,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "JUZ2EsSgicNNQp4PJrsHF",
				"focus": -0.6046781078885568,
				"gap": 9.902425706436759
			},
			"endBinding": {
				"elementId": "6u0K9QWtC66rrmF5mukLq",
				"focus": 0.6534409294991476,
				"gap": 8.202408241026319
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					271.71336454503694,
					-1.0739674287683556
				]
			]
		},
		{
			"type": "arrow",
			"version": 50,
			"versionNonce": 493943165,
			"isDeleted": false,
			"id": "dXXRLeiDRQLwmN38UaRV6",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1207.542886918661,
			"y": -673.2624202434332,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 266.34349149816194,
			"height": 3.221866383272072,
			"seed": 468191347,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6u0K9QWtC66rrmF5mukLq",
				"focus": -0.3599176641138377,
				"gap": 12.498349762165958
			},
			"endBinding": {
				"elementId": "JUZ2EsSgicNNQp4PJrsHF",
				"focus": 0.5203146489238465,
				"gap": 10.97635723217212
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-266.34349149816194,
					3.221866383272072
				]
			]
		},
		{
			"type": "arrow",
			"version": 880,
			"versionNonce": 724604701,
			"isDeleted": false,
			"id": "0Y8KtOEW1YJ1Y8zF0FAtp",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 945.0725989159689,
			"y": -213.4726205588875,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1604.0183177504193,
			"height": 475.51182997693195,
			"seed": 995103325,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662746186,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "BNGb2gHVa0Uh0HuIKpF32",
				"focus": 0.5883988407984996,
				"gap": 12.095112639518447
			},
			"endBinding": {
				"elementId": "3qOuJzQjSYjLd7un4_lqh",
				"focus": -0.09413266876517506,
				"gap": 3.2209236846205087
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					57.25999932657328,
					1.8263223015867993
				],
				[
					57.550962240714625,
					475.51182997693195
				],
				[
					-1546.4139278129132,
					474.36552925745025
				],
				[
					-1546.4673555097047,
					216.6701882524531
				],
				[
					-1419.6757050447386,
					216.13473090687063
				]
			]
		},
		{
			"type": "text",
			"version": 388,
			"versionNonce": 1735311837,
			"isDeleted": false,
			"id": "6hq48ZsV",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 81.31716744850064,
			"y": 230.22092092855064,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104,
			"height": 25,
			"seed": 1967914483,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "logged out",
			"rawText": "logged out",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "logged out"
		},
		{
			"type": "arrow",
			"version": 135,
			"versionNonce": 1327346995,
			"isDeleted": false,
			"id": "GF5vgksdpLD9CED2DJW97",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 321.5522808337231,
			"y": -264.0064651636331,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 294.35478861792944,
			"height": 17.85504985695985,
			"seed": 865804701,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662746187,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "fXTDtliCcPk6XZLef5gVC",
				"focus": -0.5459009492730997,
				"gap": 9.511006741456697
			},
			"endBinding": {
				"elementId": "BNGb2gHVa0Uh0HuIKpF32",
				"focus": 0.00082725887360957,
				"gap": 11.261660555827348
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					34.59297581722848,
					17.296528063322427
				],
				[
					294.35478861792944,
					17.85504985695985
				]
			]
		},
		{
			"type": "text",
			"version": 90,
			"versionNonce": 1398046269,
			"isDeleted": false,
			"id": "WMCEY4VG",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 286.2689312572958,
			"y": -64.9199447761265,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 283,
			"height": 25,
			"seed": 1117358387,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked on own profile picture",
			"rawText": "clicked on own profile picture",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked on own profile picture"
		},
		{
			"type": "text",
			"version": 178,
			"versionNonce": 417812499,
			"isDeleted": false,
			"id": "CujzXy00",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 302.7597181610788,
			"y": 7.6765421687748585,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 234,
			"height": 25,
			"seed": 1526994109,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "returned to posts feed",
			"rawText": "returned to posts feed",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "returned to posts feed"
		},
		{
			"type": "text",
			"version": 159,
			"versionNonce": 1208200861,
			"isDeleted": false,
			"id": "GvRrRwCr",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 360.3406583711568,
			"y": -230.90351726603365,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 166,
			"height": 50,
			"seed": 25249469,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked on poster\nprofile picture",
			"rawText": "clicked on poster\nprofile picture",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked on poster\nprofile picture"
		},
		{
			"type": "text",
			"version": 46,
			"versionNonce": 1850332595,
			"isDeleted": false,
			"id": "uH6DNeZm",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 420.45481152196623,
			"y": -492.55857311375627,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 115,
			"height": 50,
			"seed": 609338813,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662685814,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the \nsearch bar",
			"rawText": "clicked the \nsearch bar",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the \nsearch bar"
		},
		{
			"type": "text",
			"version": 141,
			"versionNonce": 514101629,
			"isDeleted": false,
			"id": "FVUhny7v",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 949.8226503264325,
			"y": -489.55826653082687,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 220,
			"height": 25,
			"seed": 1458695293,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662748999,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the search key",
			"rawText": "clicked the search key",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the search key"
		},
		{
			"type": "text",
			"version": 225,
			"versionNonce": 207643229,
			"isDeleted": false,
			"id": "G5nJJcvg",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 982.662713948459,
			"y": -405.2915703062045,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 222,
			"height": 25,
			"seed": 2026180819,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662765458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the search bar",
			"rawText": "clicked the search bar",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the search bar"
		},
		{
			"type": "text",
			"version": 329,
			"versionNonce": 97511261,
			"isDeleted": false,
			"id": "wp4DKKxz",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1028.55228904261,
			"y": -300.8732258282947,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 200,
			"height": 50,
			"seed": 998049683,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676662794429,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked a user from \nthe search results",
			"rawText": "clicked a user from \nthe search results",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked a user from \nthe search results"
		},
		{
			"type": "text",
			"version": 58,
			"versionNonce": 421170611,
			"isDeleted": false,
			"id": "hhnmTw1d",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 332.9608223529404,
			"y": -723.9366971815973,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 171,
			"height": 25,
			"seed": 628421565,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662818500,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked on a post",
			"rawText": "clicked on a post",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked on a post"
		},
		{
			"type": "text",
			"version": 61,
			"versionNonce": 454033843,
			"isDeleted": false,
			"id": "YrfVyMZY",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 979.0351007983259,
			"y": -774.3266062567028,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 171,
			"height": 50,
			"seed": 746872659,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662899109,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "clicked the \n\"Comment\" button",
			"rawText": "clicked the \n\"Comment\" button",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "clicked the \n\"Comment\" button"
		},
		{
			"type": "text",
			"version": 118,
			"versionNonce": 193650237,
			"isDeleted": false,
			"id": "sGOhXa1g",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 994.4686400597473,
			"y": -658.4630741123849,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 174,
			"height": 50,
			"seed": 1597007613,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676662915967,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "posted comment /\ncanceled",
			"rawText": "posted comment /\ncanceled",
			"baseline": 43,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "posted comment /\ncanceled"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#f1f3f5",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "center",
		"currentItemStrokeSharpness": "round",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "sharp",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%