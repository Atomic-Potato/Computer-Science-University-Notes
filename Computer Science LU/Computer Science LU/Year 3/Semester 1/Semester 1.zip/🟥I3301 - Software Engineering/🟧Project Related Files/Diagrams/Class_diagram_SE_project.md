---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
User    ^3qQr0wek

Post 

- user
- title
- description
- attachment_arr
- time_stamp
- likes_count
- comments_count

+ set_title
+ set_description
+ set_attachment ^FunYxfOs

Message 

- chat
- content
- timestamp
- sender

+ display_msg
+ display_timestamp
+ display_sender
 ^OaRf45pQ

Chat

- user
- to_user
- messages_arr

+ display_msgs ^amY9tSNo

Notification

- user
- activity_toNotify

+ send_noti ^gkL5YwpS

Marketplace

- user

+ mpListing_recommend
+ mpListing_display
 ^GyBpQhIr

Post feed

- user 

+ post_recommend 
+ post_filter
+ post_display ^GWgWg4Io

Profile

- user

+ display_profpic
+ display_flwnum
+ display_username
+ display_posts ^irK3AdhL

Transaction

- from_user
- to_user
- trans_ammount

+ validate_trans
+ conduct_trans ^hm5UrQQ0

Report 

- user
- content

+ display_msgAtsubmit ^U7jug7Mo

Search 

- search_query

- conduct_search
+ display_result ^1vxmqOLA

Marketplace listing

- seller
- contact_info 
- prod_name
- prod_imgs
- prod_descp
- price

+ display_listing ^y9Np6hcY

- username
- follow_num
- profile_pic
- email
- password
- bio

+ create_acc
+ delete_acc
+ login
+logout
+update_profile
//SEARCH
+search
//POSTS 
+ view_post
+ add_post
+ remove_post
+ like_post
+ commentOn_post
//PROFILE
+ view_profile
+ follow
+ unfollow
+ mute
+ report
+ block
//CHAT
+ create_chat
+ delete_chat
+ open_chat
+ send_msg
//MAKETPLACE
+ create_listing
+ view_listing
+ buy

 ^reWbTxt0

displays that 
the report was
successfully
sent
 ^SHd96dS6

"//" will be used 
to indicate 
comment lines 
within a class ^wxJBgoK2

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "text",
			"version": 336,
			"versionNonce": 1989513491,
			"isDeleted": false,
			"id": "3qQr0wek",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 2998.431599265302,
			"y": -1310.1415818297735,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 107,
			"height": 35,
			"seed": 2009985020,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "User   ",
			"rawText": "User   ",
			"baseline": 25,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "User   "
		},
		{
			"type": "text",
			"version": 463,
			"versionNonce": 336985501,
			"isDeleted": false,
			"id": "FunYxfOs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3417.5315992032847,
			"y": -1304.8884319485148,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 260,
			"height": 451,
			"seed": 209485636,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Post \n\n- user\n- title\n- description\n- attachment_arr\n- time_stamp\n- likes_count\n- comments_count\n\n+ set_title\n+ set_description\n+ set_attachment",
			"rawText": "Post \n\n- user\n- title\n- description\n- attachment_arr\n- time_stamp\n- likes_count\n- comments_count\n\n+ set_title\n+ set_description\n+ set_attachment",
			"baseline": 441,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Post \n\n- user\n- title\n- description\n- attachment_arr\n- time_stamp\n- likes_count\n- comments_count\n\n+ set_title\n+ set_description\n+ set_attachment"
		},
		{
			"type": "text",
			"version": 470,
			"versionNonce": 1585968819,
			"isDeleted": false,
			"id": "OaRf45pQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3396.4210137807177,
			"y": -486.1725403336212,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 280,
			"height": 382,
			"seed": 1029468356,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Message \n\n- chat\n- content\n- timestamp\n- sender\n\n+ display_msg\n+ display_timestamp\n+ display_sender\n",
			"rawText": "Message \n\n- chat\n- content\n- timestamp\n- sender\n\n+ display_msg\n+ display_timestamp\n+ display_sender\n",
			"baseline": 372,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Message \n\n- chat\n- content\n- timestamp\n- sender\n\n+ display_msg\n+ display_timestamp\n+ display_sender\n"
		},
		{
			"type": "text",
			"version": 391,
			"versionNonce": 656294397,
			"isDeleted": false,
			"id": "amY9tSNo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3423.6593689856104,
			"y": -797.0814528340452,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 218,
			"height": 243,
			"seed": 1144332796,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Chat\n\n- user\n- to_user\n- messages_arr\n\n+ display_msgs",
			"rawText": "Chat\n\n- user\n- to_user\n- messages_arr\n\n+ display_msgs",
			"baseline": 233,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Chat\n\n- user\n- to_user\n- messages_arr\n\n+ display_msgs"
		},
		{
			"type": "text",
			"version": 536,
			"versionNonce": 308062291,
			"isDeleted": false,
			"id": "gkL5YwpS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 4305.635499833714,
			"y": -1300.2341404266067,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 267,
			"height": 208,
			"seed": 2138302148,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Notification\n\n- user\n- activity_toNotify\n\n+ send_noti",
			"rawText": "Notification\n\n- user\n- activity_toNotify\n\n+ send_noti",
			"baseline": 198,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Notification\n\n- user\n- activity_toNotify\n\n+ send_noti"
		},
		{
			"type": "text",
			"version": 463,
			"versionNonce": 1298070109,
			"isDeleted": false,
			"id": "GyBpQhIr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3841.4421205070375,
			"y": -167.5277459051838,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 310,
			"height": 243,
			"seed": 512334716,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Marketplace\n\n- user\n\n+ mpListing_recommend\n+ mpListing_display\n",
			"rawText": "Marketplace\n\n- user\n\n+ mpListing_recommend\n+ mpListing_display\n",
			"baseline": 233,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Marketplace\n\n- user\n\n+ mpListing_recommend\n+ mpListing_display\n"
		},
		{
			"type": "text",
			"version": 517,
			"versionNonce": 2011833843,
			"isDeleted": false,
			"id": "GWgWg4Io",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 4290.43022443156,
			"y": -912.4341550445105,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 265,
			"height": 243,
			"seed": 729366780,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Post feed\n\n- user \n\n+ post_recommend \n+ post_filter\n+ post_display",
			"rawText": "Post feed\n\n- user \n\n+ post_recommend \n+ post_filter\n+ post_display",
			"baseline": 233,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Post feed\n\n- user \n\n+ post_recommend \n+ post_filter\n+ post_display"
		},
		{
			"type": "text",
			"version": 359,
			"versionNonce": 1873389245,
			"isDeleted": false,
			"id": "irK3AdhL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3880.96785377317,
			"y": -1299.6720679336445,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 268,
			"height": 278,
			"seed": 383842756,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.854773881707587,
			"fontFamily": 1,
			"text": "Profile\n\n- user\n\n+ display_profpic\n+ display_flwnum\n+ display_username\n+ display_posts",
			"rawText": "Profile\n\n- user\n\n+ display_profpic\n+ display_flwnum\n+ display_username\n+ display_posts",
			"baseline": 268,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Profile\n\n- user\n\n+ display_profpic\n+ display_flwnum\n+ display_username\n+ display_posts"
		},
		{
			"type": "text",
			"version": 411,
			"versionNonce": 1983311763,
			"isDeleted": false,
			"id": "hm5UrQQ0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3874.752691930525,
			"y": -931.6902628287427,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 242,
			"height": 278,
			"seed": 1596675708,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Transaction\n\n- from_user\n- to_user\n- trans_ammount\n\n+ validate_trans\n+ conduct_trans",
			"rawText": "Transaction\n\n- from_user\n- to_user\n- trans_ammount\n\n+ validate_trans\n+ conduct_trans",
			"baseline": 268,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Transaction\n\n- from_user\n- to_user\n- trans_ammount\n\n+ validate_trans\n+ conduct_trans"
		},
		{
			"type": "text",
			"version": 469,
			"versionNonce": 1621083933,
			"isDeleted": false,
			"id": "U7jug7Mo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 2563.7447477728324,
			"y": -950.1063769378608,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 311,
			"height": 208,
			"seed": 964737532,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Report \n\n- user\n- content\n\n+ display_msgAtsubmit",
			"rawText": "Report \n\n- user\n- content\n\n+ display_msgAtsubmit",
			"baseline": 198,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Report \n\n- user\n- content\n\n+ display_msgAtsubmit"
		},
		{
			"type": "text",
			"version": 409,
			"versionNonce": 1333364019,
			"isDeleted": false,
			"id": "1vxmqOLA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 2645.69804065866,
			"y": -1303.7732186058217,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 242,
			"height": 208,
			"seed": 895548540,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Search \n\n- search_query\n\n- conduct_search\n+ display_result",
			"rawText": "Search \n\n- search_query\n\n- conduct_search\n+ display_result",
			"baseline": 198,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Search \n\n- search_query\n\n- conduct_search\n+ display_result"
		},
		{
			"type": "text",
			"version": 544,
			"versionNonce": 582146941,
			"isDeleted": false,
			"id": "y9Np6hcY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3881.0282997839013,
			"y": -575.0773326718725,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 258,
			"height": 347,
			"seed": 1284230852,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 27.85477388170759,
			"fontFamily": 1,
			"text": "Marketplace listing\n\n- seller\n- contact_info \n- prod_name\n- prod_imgs\n- prod_descp\n- price\n\n+ display_listing",
			"rawText": "Marketplace listing\n\n- seller\n- contact_info \n- prod_name\n- prod_imgs\n- prod_descp\n- price\n\n+ display_listing",
			"baseline": 337,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Marketplace listing\n\n- seller\n- contact_info \n- prod_name\n- prod_imgs\n- prod_descp\n- price\n\n+ display_listing"
		},
		{
			"type": "text",
			"version": 571,
			"versionNonce": 991454931,
			"isDeleted": false,
			"id": "reWbTxt0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 2984.57102550099,
			"y": -1236.6262538933668,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 258,
			"height": 1318,
			"seed": 635673535,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129031,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "- username\n- follow_num\n- profile_pic\n- email\n- password\n- bio\n\n+ create_acc\n+ delete_acc\n+ login\n+logout\n+update_profile\n//SEARCH\n+search\n//POSTS \n+ view_post\n+ add_post\n+ remove_post\n+ like_post\n+ commentOn_post\n//PROFILE\n+ view_profile\n+ follow\n+ unfollow\n+ mute\n+ report\n+ block\n//CHAT\n+ create_chat\n+ delete_chat\n+ open_chat\n+ send_msg\n//MAKETPLACE\n+ create_listing\n+ view_listing\n+ buy\n\n",
			"rawText": "- username\n- follow_num\n- profile_pic\n- email\n- password\n- bio\n\n+ create_acc\n+ delete_acc\n+ login\n+logout\n+update_profile\n//SEARCH\n+search\n//POSTS \n+ view_post\n+ add_post\n+ remove_post\n+ like_post\n+ commentOn_post\n//PROFILE\n+ view_profile\n+ follow\n+ unfollow\n+ mute\n+ report\n+ block\n//CHAT\n+ create_chat\n+ delete_chat\n+ open_chat\n+ send_msg\n//MAKETPLACE\n+ create_listing\n+ view_listing\n+ buy\n\n",
			"baseline": 1308,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "- username\n- follow_num\n- profile_pic\n- email\n- password\n- bio\n\n+ create_acc\n+ delete_acc\n+ login\n+logout\n+update_profile\n//SEARCH\n+search\n//POSTS \n+ view_post\n+ add_post\n+ remove_post\n+ like_post\n+ commentOn_post\n//PROFILE\n+ view_profile\n+ follow\n+ unfollow\n+ mute\n+ report\n+ block\n//CHAT\n+ create_chat\n+ delete_chat\n+ open_chat\n+ send_msg\n//MAKETPLACE\n+ create_listing\n+ view_listing\n+ buy\n\n"
		},
		{
			"type": "line",
			"version": 879,
			"versionNonce": 1847878621,
			"isDeleted": false,
			"id": "XQDm1Bpm8btiR5yIGdXRb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 2959.153208566583,
			"y": -1697.5815185430818,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 322.05681057618773,
			"height": 239.45742956516335,
			"seed": 1683758385,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.338225451292624,
					236.24921688769928
				],
				[
					318.98707325186496,
					237.67913996237718
				],
				[
					322.05681057618773,
					48.244713369440255
				],
				[
					283.65679147944587,
					-1.7782896027861856
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 910,
			"versionNonce": 1068110963,
			"isDeleted": false,
			"id": "xQKhv3ylrNO2mWg1HB_BT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3502.2770273647625,
			"y": -1732.058898437844,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 322.05681057618773,
			"height": 239.45742956516335,
			"seed": 1446598271,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.338225451292624,
					236.24921688769928
				],
				[
					318.98707325186496,
					237.67913996237718
				],
				[
					322.05681057618773,
					48.244713369440255
				],
				[
					283.65679147944587,
					-1.7782896027861856
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1122,
			"versionNonce": 1996873789,
			"isDeleted": false,
			"id": "QzFBjay4dXN4Z49A9BK_n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 2308.6136744141554,
			"y": -809.5680466212955,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 177.32459665867378,
			"height": 144.78425431836476,
			"seed": 683412863,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.2874277811598207,
					142.8444578332657
				],
				[
					175.63439817502817,
					143.70903884240713
				],
				[
					177.32459665867376,
					29.170424416072702
				],
				[
					156.1815322228286,
					-1.075215475957635
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 38,
			"versionNonce": 1291128339,
			"isDeleted": false,
			"id": "lNFd6wKIG9NLDDp_sidKA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 2492.0307388047117,
			"y": -736.8830339404951,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 61.92562203189982,
			"height": 14.77124929201284,
			"seed": 515839231,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					61.92562203189982,
					-14.77124929201284
				]
			]
		},
		{
			"type": "text",
			"version": 111,
			"versionNonce": 1933103261,
			"isDeleted": false,
			"id": "SHd96dS6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 2336.1731435145884,
			"y": -784.6231895603557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 120,
			"height": 105,
			"seed": 147814033,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "displays that \nthe report was\nsuccessfully\nsent\n",
			"rawText": "displays that \nthe report was\nsuccessfully\nsent\n",
			"baseline": 99,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "displays that \nthe report was\nsuccessfully\nsent\n"
		},
		{
			"type": "text",
			"version": 224,
			"versionNonce": 368038835,
			"isDeleted": false,
			"id": "wxJBgoK2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3547.8675599234575,
			"y": -1694.6767449048978,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 229,
			"height": 139,
			"seed": 216502431,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"fontSize": 27.492147956197208,
			"fontFamily": 1,
			"text": "\"//\" will be used \nto indicate \ncomment lines \nwithin a class",
			"rawText": "\"//\" will be used \nto indicate \ncomment lines \nwithin a class",
			"baseline": 129,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "\"//\" will be used \nto indicate \ncomment lines \nwithin a class"
		},
		{
			"id": "etA7-emXKzkEnahVm6j3S",
			"type": "rectangle",
			"x": 2952.070185159101,
			"y": -1324.2317385330975,
			"width": 316.03162082311974,
			"height": 1350.4497998621496,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1179171667,
			"version": 80,
			"versionNonce": 1998514131,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676652236695,
			"link": null,
			"locked": false
		},
		{
			"id": "_s2d0z1NFHi8zaBZZiIJ1",
			"type": "rectangle",
			"x": 3381.896481946126,
			"y": -493.0718865364779,
			"width": 307.1786566793253,
			"height": 381.77172608283126,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 545831795,
			"version": 206,
			"versionNonce": 717284691,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"id": "o7RR2jtY3SzgcmifU_4U6",
			"type": "rectangle",
			"x": 3842.5810358802514,
			"y": -1315.3347418242347,
			"width": 331.05006595918394,
			"height": 319.6716927081583,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 801908627,
			"version": 316,
			"versionNonce": 856050941,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651150599,
			"link": null,
			"locked": false
		},
		{
			"id": "VaC-RzHb0Ezy3pcHRkgTo",
			"type": "rectangle",
			"x": 3819.9302682584366,
			"y": -168.85631338021437,
			"width": 357.1855760225026,
			"height": 252.6434192733078,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1253626877,
			"version": 66,
			"versionNonce": 1388233459,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"id": "SvkbS8Gj6go6NrgTGhF2m",
			"type": "rectangle",
			"x": 4279.915455065502,
			"y": -1320.5618263625106,
			"width": 331.0500659591835,
			"height": 257.87053293556346,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1818659645,
			"version": 60,
			"versionNonce": 1337547197,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 318,
			"versionNonce": 644869267,
			"isDeleted": false,
			"id": "KZBU2mAMg4ykC9Q_cNicq",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3399.910345062625,
			"y": -1318.5316698360234,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 307.1786566793253,
			"height": 479.34433970105863,
			"seed": 1487283955,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 275,
			"versionNonce": 708909597,
			"isDeleted": false,
			"id": "Wl25rYej6UYsR06Y2RZdW",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3394.010525712926,
			"y": -802.9568436420948,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 307.1786566793253,
			"height": 273.7449433880522,
			"seed": 277885651,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 101,
			"versionNonce": 1770709555,
			"isDeleted": false,
			"id": "tTicqokdnjrwvrE2eG17A",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 4267.980506355551,
			"y": -920.9090316950534,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 331.0500659591835,
			"height": 257.87053293556346,
			"seed": 1641065619,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"id": "KH2m4aYBOkYsLwt5Fma9L",
			"type": "rectangle",
			"x": 2614.4954430343623,
			"y": -1322.594804527907,
			"width": 297.01112084935494,
			"height": 251.6548073624017,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1466981459,
			"version": 64,
			"versionNonce": 1924255357,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"id": "adl3S42HV-NpJb2IfNyDM",
			"type": "rectangle",
			"x": 2547.192406333408,
			"y": -965.5961072537211,
			"width": 339.4413089205391,
			"height": 245.8023608819302,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1894031219,
			"version": 48,
			"versionNonce": 620110803,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false
		},
		{
			"id": "7TE7dCKa3DRDEH1UI3BbW",
			"type": "line",
			"x": 2607.034685592542,
			"y": -1188.3507095096336,
			"width": 315.1832611255104,
			"height": 0,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 306745747,
			"version": 28,
			"versionNonce": 1741485789,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					315.1832611255104,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "l0Ch3tkoMdWxjJ7hCzxtb",
			"type": "line",
			"x": 2611.9748703826854,
			"y": -1264.4294231564322,
			"width": 302.33884673184366,
			"height": 4.940184790143576,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 459477875,
			"version": 46,
			"versionNonce": 13119859,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					302.33884673184366,
					-4.940184790143576
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "UPV4JZGT-tIsDbUOcRcyO",
			"type": "line",
			"x": 2547.1206168398016,
			"y": -900.8337655285884,
			"width": 336.8756549777431,
			"height": 3.1337321393102684,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1246002163,
			"version": 50,
			"versionNonce": 1948521277,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					336.8756549777431,
					-3.1337321393102684
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "iYi6UOfaiiKlNhlcctWDW",
			"type": "line",
			"x": 2546.337183804974,
			"y": -792.7201638647011,
			"width": 336.8756811681301,
			"height": 3.1337321393102684,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1110336435,
			"version": 28,
			"versionNonce": 1581746963,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					336.8756811681301,
					-3.1337321393102684
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "u1vzo94-_Oky-gQCXVuho",
			"type": "line",
			"x": 2955.1717573127817,
			"y": -1255.9440033325964,
			"width": 311.65911258564483,
			"height": 0.9139576859047338,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 43284883,
			"version": 41,
			"versionNonce": 874029981,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					311.65911258564483,
					-0.9139576859047338
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "FMEe-iOwMAvyH9IXLDk0E",
			"type": "line",
			"x": 2944.2043261896474,
			"y": -1013.7456137680014,
			"width": 325.3683862126313,
			"height": 3.655830743619731,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1745295229,
			"version": 53,
			"versionNonce": 837464243,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					325.3683862126313,
					3.655830743619731
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "IhtxkrAOuIDbLPqQe479a",
			"type": "freedraw",
			"x": 3400.952270332392,
			"y": -1250.919544640289,
			"width": 314.8305280494501,
			"height": 6.1217138076553965,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1390866557,
			"version": 30,
			"versionNonce": 1004283901,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651129032,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.749061087901282,
					0
				],
				[
					3.4981221758030188,
					0
				],
				[
					14.86699001136094,
					0
				],
				[
					34.106661978278225,
					0
				],
				[
					71.71138766075592,
					0
				],
				[
					100.57086637532984,
					0
				],
				[
					135.5520296617574,
					0
				],
				[
					181.027559475594,
					0
				],
				[
					227.3775905975799,
					0.8745305439508684
				],
				[
					259.7351914879564,
					1.7490610879015094
				],
				[
					287.7201104227779,
					2.6235916318521504
				],
				[
					304.3361615220406,
					5.247183263704528
				],
				[
					313.0814084899448,
					6.1217138076553965
				],
				[
					314.8305280494501,
					6.1217138076553965
				],
				[
					313.95602674130123,
					6.1217138076553965
				],
				[
					312.20690718179594,
					5.247183263704528
				],
				[
					311.3324058736471,
					4.372652719753887
				],
				[
					310.4579045654982,
					3.4981221758030188
				],
				[
					309.58328631414133,
					3.4981221758030188
				],
				[
					308.70878500599247,
					3.4981221758030188
				],
				[
					308.70878500599247,
					3.4981221758030188
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				308.70878500599247,
				3.4981221758030188
			]
		},
		{
			"id": "r_XSTne2HAzrkfnI6vZOF",
			"type": "freedraw",
			"x": 3394.8305857605383,
			"y": -979.8154853167739,
			"width": 308.7822316870956,
			"height": null,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 493887581,
			"version": 35,
			"versionNonce": 406672829,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1676651868666,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.8212031999076074,
					0
				],
				[
					1.6424613077581682,
					0
				],
				[
					7.391048430941134,
					0
				],
				[
					16.424558169640864,
					0
				],
				[
					31.20670993946694,
					0
				],
				[
					51.73744883247556,
					0
				],
				[
					76.37431354090855,
					0
				],
				[
					130.57548178899367,
					0
				],
				[
					154.39114329751948,
					0
				],
				[
					232.40791814618663,
					0
				],
				[
					257.04478285462005,
					0
				],
				[
					308.7822316870956,
					0
				],
				[
					308.7822316870956,
					0
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				328.8229582810586,
				0
			]
		},
		{
			"type": "rectangle",
			"version": 327,
			"versionNonce": 1258779411,
			"isDeleted": false,
			"id": "eY1UQl82DAvNNop5kAtRD",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3851.928944323193,
			"y": -942.3088274547204,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 331.05006595918394,
			"height": 319.6716927081583,
			"seed": 554618195,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651152894,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 481,
			"versionNonce": 442848531,
			"isDeleted": false,
			"id": "7Ku_8u4D9WFgAcGLrD0hF",
			"fillStyle": "hachure",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": 3860.082337290719,
			"y": -578.0895752917384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 331.05006595918394,
			"height": 361.2110993085935,
			"seed": 1638611869,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1676651166406,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 90,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%