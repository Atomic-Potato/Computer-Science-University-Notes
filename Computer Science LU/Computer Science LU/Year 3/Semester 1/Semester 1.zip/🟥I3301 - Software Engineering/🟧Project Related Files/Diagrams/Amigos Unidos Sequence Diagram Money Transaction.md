---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
buyer:user ^QarZbQJC

connectToBillingAccount ^XGtv8nYR

alt ^4Hcp777z

[account already
connected] ^s8HDWU3p

billingAccountHanlder:app ^d2fPstH8

connect ^ifX6lKTD

BILLING ACCOUNT CONNECTION ^7yX7b7xp

continueToTransaction ^G1VlPprS

requestBillingAccountInfo ^JjPGmI7M

sendBillingAcountInfo ^QmxYYzGR

PayPal:externalPayingApp ^IKNMa17L

syncAccounts ^NNjmn51U

confirmSync ^suPTuQwG

continueToTransaction ^2QkPUjtw

[else] ^qVXXSelz

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "text",
			"version": 261,
			"versionNonce": 2020240759,
			"isDeleted": false,
			"id": "QarZbQJC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 332.73462827288006,
			"y": -98.97528352200175,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 99,
			"height": 25,
			"seed": 57213726,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "buyer:user",
			"rawText": "buyer:user",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "buyer:user"
		},
		{
			"type": "rectangle",
			"version": 358,
			"versionNonce": 1809222009,
			"isDeleted": false,
			"id": "wYM9WXYWI8bvP5T-6GAVq",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 267.25082013708584,
			"y": -111.90735466253864,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 233.05232979172854,
			"height": 47.54578928711754,
			"seed": 99796418,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 218,
			"versionNonce": 1238083223,
			"isDeleted": false,
			"id": "zin511GFllb8hyFYx-vad",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 437.44999756541716,
			"y": -71.77257659255653,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 115.9395994857901,
			"height": 1.1652238671127293,
			"seed": 1000939038,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-115.9395994857901,
					-1.1652238671127293
				]
			]
		},
		{
			"type": "line",
			"version": 593,
			"versionNonce": 1192817241,
			"isDeleted": false,
			"id": "GedpNlG1HNTE5gdU4gw1x",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 378.06125698834694,
			"y": -59.76983809484227,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.9034380241662916,
			"height": 624.7091852042566,
			"seed": 974332866,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.9034380241662916,
					624.7091852042566
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1033,
			"versionNonce": 1685565650,
			"isDeleted": false,
			"id": "iEqPVIdTntB2bMF_IGuaj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 362.91417631045454,
			"y": -33.13904678858171,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 23.90572013201707,
			"height": 561.1066563103691,
			"seed": 176349854,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "8w0nzVOA8dsPcFUvDtDXU",
					"type": "arrow"
				}
			],
			"updated": 1678268422556,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 1271,
			"versionNonce": 1675312953,
			"isDeleted": false,
			"id": "8w0nzVOA8dsPcFUvDtDXU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 66.62533549134022,
			"y": 11.636381521403251,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 285.78191284933484,
			"height": 1.8541653267352416,
			"seed": 2079834242,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "iEqPVIdTntB2bMF_IGuaj",
				"focus": 0.8330445153717077,
				"gap": 10.506927969779412
			},
			"lastCommittedPoint": null,
			"startArrowhead": "dot",
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					285.78191284933484,
					1.8541653267352416
				]
			]
		},
		{
			"type": "text",
			"version": 555,
			"versionNonce": 1239821527,
			"isDeleted": false,
			"id": "XGtv8nYR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 95.6265193683077,
			"y": -16.717171897697597,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 231,
			"height": 25,
			"seed": 704491486,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "connectToBillingAccount",
			"rawText": "connectToBillingAccount",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "connectToBillingAccount"
		},
		{
			"type": "rectangle",
			"version": 1010,
			"versionNonce": 1350627353,
			"isDeleted": false,
			"id": "Cd1Bb0f57Gv5N4U3GHAvZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 178.69056677053425,
			"y": 70.03650340992124,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 931.3053546837294,
			"height": 430.2404748727441,
			"seed": 1435622110,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 567,
			"versionNonce": 676887031,
			"isDeleted": false,
			"id": "4Hcp777z",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 190.14233278873348,
			"y": 79.4456514288213,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 32,
			"height": 25,
			"seed": 1765034498,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "alt",
			"rawText": "alt",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "alt"
		},
		{
			"type": "line",
			"version": 592,
			"versionNonce": 50169081,
			"isDeleted": false,
			"id": "yKFp09xAbFIaKb7aUfOw_",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 232.16334257699384,
			"y": 71.75538927393666,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 0.22383799511635516,
			"height": 20.817592068941792,
			"seed": 714002206,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.22383799511635516,
					20.817592068941792
				]
			]
		},
		{
			"type": "line",
			"version": 574,
			"versionNonce": 1497637655,
			"isDeleted": false,
			"id": "ZXn3wSD-6Z_nJpfuvc6Ax",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 179.11204652731215,
			"y": 107.5706059415802,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 35.815216667643654,
			"height": 0.4476909566672873,
			"seed": 635419074,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.815216667643654,
					-0.4476909566672873
				]
			]
		},
		{
			"type": "line",
			"version": 575,
			"versionNonce": 1725201881,
			"isDeleted": false,
			"id": "qzu0kkAdTIhEGiL_HZuU9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 232.3871805721102,
			"y": 93.02067229954571,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 19.026828242272586,
			"height": 14.997624598701833,
			"seed": 1952660318,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-19.026828242272586,
					14.997624598701833
				]
			]
		},
		{
			"type": "text",
			"version": 115,
			"versionNonce": 2099095607,
			"isDeleted": false,
			"id": "s8HDWU3p",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 191.50205265047225,
			"y": 116.98643656952305,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 136,
			"height": 40,
			"seed": 2042162398,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "[account already\nconnected]",
			"rawText": "[account already\nconnected]",
			"baseline": 34,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "[account already\nconnected]"
		},
		{
			"type": "text",
			"version": 439,
			"versionNonce": 723081913,
			"isDeleted": false,
			"id": "d2fPstH8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 545.4523443870825,
			"y": -100.40014504551564,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 235,
			"height": 25,
			"seed": 1639698882,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "billingAccountHanlder:app",
			"rawText": "billingAccountHanlder:app",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "billingAccountHanlder:app"
		},
		{
			"type": "rectangle",
			"version": 436,
			"versionNonce": 835291479,
			"isDeleted": false,
			"id": "MRjV5TgVXfefltzdDYQ0p",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 536.3360773050506,
			"y": -112.11216198193276,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 249.77676277388605,
			"height": 47.54578928711754,
			"seed": 99918686,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 348,
			"versionNonce": 1349491609,
			"isDeleted": false,
			"id": "w1975kR2wdmswn0_0Nn4f",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 776.530087008131,
			"y": -73.83565654413763,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 230.53289210292496,
			"height": 0.07362455434522985,
			"seed": 2074102146,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-230.53289210292496,
					0.07362455434522985
				]
			]
		},
		{
			"type": "line",
			"version": 672,
			"versionNonce": 1687963255,
			"isDeleted": false,
			"id": "kLXX3h0dupnYnM6vSdx7g",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 655.6979296254361,
			"y": -58.72071400561731,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.210529858660607,
			"height": 627.6652273603336,
			"seed": 68130910,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.210529858660607,
					627.6652273603336
				]
			]
		},
		{
			"type": "arrow",
			"version": 149,
			"versionNonce": 1997193337,
			"isDeleted": false,
			"id": "Lndu5B0UmFQhEavR-Nze8",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 413.68337739822766,
			"y": 34.147002844103355,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 201.64527450394928,
			"height": 2.842170943040401e-14,
			"seed": 1817578846,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					201.64527450394928,
					-2.842170943040401e-14
				]
			]
		},
		{
			"type": "text",
			"version": 60,
			"versionNonce": 1683644311,
			"isDeleted": false,
			"id": "ifX6lKTD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 475.7994188606627,
			"y": 8.283582187906092,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 20,
			"seed": 2028757470,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "connect",
			"rawText": "connect",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "connect"
		},
		{
			"type": "text",
			"version": 755,
			"versionNonce": 1823361369,
			"isDeleted": false,
			"id": "7yX7b7xp",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 378.8390532023063,
			"y": -235.98885132805134,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 613,
			"height": 45,
			"seed": 71439426,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 1,
			"text": "BILLING ACCOUNT CONNECTION",
			"rawText": "BILLING ACCOUNT CONNECTION",
			"baseline": 32,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "BILLING ACCOUNT CONNECTION"
		},
		{
			"type": "rectangle",
			"version": 109,
			"versionNonce": 859329719,
			"isDeleted": false,
			"id": "w_0JCaSfo_6DaqC6yXzDK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 327.63603788635214,
			"y": -272.16620855377124,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 695.4416448419745,
			"height": 114.52378706498581,
			"seed": 994367902,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 88,
			"versionNonce": 2058204729,
			"isDeleted": false,
			"id": "lvY_CfgGiz0GwztzBdCOt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 997.8112643851509,
			"y": -271.48872625764943,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 24.16667657009043,
			"height": 27.318847575026723,
			"seed": 1816067550,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 111,
			"versionNonce": 416982487,
			"isDeleted": false,
			"id": "HDkv_lVAfzinksik71bJY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 632.213350106298,
			"y": 124.85594588929854,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 220.02476524618476,
			"height": 0.13261614136118283,
			"seed": 210259714,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-220.02476524618476,
					-0.13261614136118283
				]
			]
		},
		{
			"type": "text",
			"version": 162,
			"versionNonce": 1944880921,
			"isDeleted": false,
			"id": "G1VlPprS",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 437.1153162602427,
			"y": 87.72806771404198,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 180,
			"height": 20,
			"seed": 1508217858,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "continueToTransaction",
			"rawText": "continueToTransaction",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "continueToTransaction"
		},
		{
			"type": "line",
			"version": 199,
			"versionNonce": 1951781623,
			"isDeleted": false,
			"id": "KU0mEMgTTYCt5VzZ-Kr_T",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 179.09107195621863,
			"y": 175.58228063325427,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 932.9660220043795,
			"height": 0.3392460569443756,
			"seed": 1357438942,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					932.9660220043795,
					-0.3392460569443756
				]
			]
		},
		{
			"type": "arrow",
			"version": 167,
			"versionNonce": 48118777,
			"isDeleted": false,
			"id": "lgPeSZ3WM2dVHKQ7b7BXH",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 634.2977023830503,
			"y": 240.1212198401596,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 220.02476524618476,
			"height": 0.13261614136118283,
			"seed": 1808190466,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "JjPGmI7M",
				"focus": -2.4723734045197814,
				"gap": 15.67024296933829
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-220.02476524618476,
					-0.13261614136118283
				]
			]
		},
		{
			"type": "text",
			"version": 264,
			"versionNonce": 1311661079,
			"isDeleted": false,
			"id": "JjPGmI7M",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 431.11496954760173,
			"y": 203.4509768708213,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 198,
			"height": 20,
			"seed": 836594974,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "lgPeSZ3WM2dVHKQ7b7BXH",
					"type": "arrow"
				}
			],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "requestBillingAccountInfo",
			"rawText": "requestBillingAccountInfo",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "requestBillingAccountInfo"
		},
		{
			"type": "arrow",
			"version": 212,
			"versionNonce": 931550425,
			"isDeleted": false,
			"id": "C-JNYKWw5OyQiAzrm-s1N",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 423.90331652343843,
			"y": 298.0060730213018,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 201.64527450394928,
			"height": 2.842170943040401e-14,
			"seed": 1354625026,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QmxYYzGR",
				"focus": 2.2986983505616108,
				"gap": 15.292625507175103
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					201.64527450394928,
					-2.842170943040401e-14
				]
			]
		},
		{
			"type": "text",
			"version": 181,
			"versionNonce": 710459703,
			"isDeleted": false,
			"id": "QmxYYzGR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 439.19594203061354,
			"y": 263.3697403404048,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 164,
			"height": 20,
			"seed": 375032094,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "C-JNYKWw5OyQiAzrm-s1N",
					"type": "arrow"
				}
			],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "sendBillingAcountInfo",
			"rawText": "sendBillingAcountInfo",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "sendBillingAcountInfo"
		},
		{
			"type": "text",
			"version": 517,
			"versionNonce": 1433948601,
			"isDeleted": false,
			"id": "IKNMa17L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 841.9387364954756,
			"y": -101.95911163050522,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 248,
			"height": 25,
			"seed": 1282335710,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "PayPal:externalPayingApp",
			"rawText": "PayPal:externalPayingApp",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "PayPal:externalPayingApp"
		},
		{
			"type": "rectangle",
			"version": 493,
			"versionNonce": 439976535,
			"isDeleted": false,
			"id": "WYABah_pOT0aJriFWCvQw",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 832.8224694134439,
			"y": -113.03291013885513,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 262.69892903852286,
			"height": 47.54578928711754,
			"seed": 558387458,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 410,
			"versionNonce": 1641525913,
			"isDeleted": false,
			"id": "kU86Nz6XEUw29NNV83vnk",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1085.9386093818566,
			"y": -75.29482829541985,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 243.45502236825723,
			"height": 0.6120481487050711,
			"seed": 853719070,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-243.45502236825723,
					0.6120481487050711
				]
			]
		},
		{
			"type": "line",
			"version": 759,
			"versionNonce": 245702519,
			"isDeleted": false,
			"id": "JGTYH1_5sB1-PATV-h7nO",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 969.1370366166425,
			"y": -60.70987113407159,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.7508238456738354,
			"height": 590.6930489263754,
			"seed": 912449246,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.7508238456738354,
					590.6930489263754
				]
			]
		},
		{
			"type": "arrow",
			"version": 565,
			"versionNonce": 1901590393,
			"isDeleted": false,
			"id": "IqGiopcmdKICfgAjYL0Vt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 683.3299410933633,
			"y": 330.69151638885506,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 259.0200346376613,
			"height": 0.926308338606475,
			"seed": 1158737630,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					259.0200346376613,
					-0.926308338606475
				]
			]
		},
		{
			"type": "text",
			"version": 72,
			"versionNonce": 1776294039,
			"isDeleted": false,
			"id": "NNjmn51U",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 754.1305358544867,
			"y": 306.17406492778065,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 103,
			"height": 20,
			"seed": 989001758,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "syncAccounts",
			"rawText": "syncAccounts",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "syncAccounts"
		},
		{
			"type": "arrow",
			"version": 562,
			"versionNonce": 909942873,
			"isDeleted": false,
			"id": "ya9uQI6IbIrsGsz50P_Qn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 944.3183916403657,
			"y": 390.53965217673164,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 256.7744213393023,
			"height": 0.11748032967483368,
			"seed": 1071099870,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-256.7744213393023,
					0.11748032967483368
				]
			]
		},
		{
			"type": "text",
			"version": 384,
			"versionNonce": 1369370039,
			"isDeleted": false,
			"id": "suPTuQwG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 765.9667765135198,
			"y": 366.9838676666312,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 87,
			"height": 20,
			"seed": 245515522,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "confirmSync",
			"rawText": "confirmSync",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "confirmSync"
		},
		{
			"type": "arrow",
			"version": 546,
			"versionNonce": 1314467129,
			"isDeleted": false,
			"id": "Lw1SitYtCxW_-RhFYIQjU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 630.9160498185759,
			"y": 427.51443647155395,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 227.01404504350057,
			"height": 0.03647346210090063,
			"seed": 1578306946,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "2QkPUjtw",
				"focus": -1.7346789630327668,
				"gap": 8.108766346296505
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-227.01404504350057,
					-0.03647346210090063
				]
			]
		},
		{
			"type": "text",
			"version": 336,
			"versionNonce": 1090920151,
			"isDeleted": false,
			"id": "2QkPUjtw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 442.80728347227927,
			"y": 398.75946123656934,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 180,
			"height": 20,
			"seed": 177210270,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "Lw1SitYtCxW_-RhFYIQjU",
					"type": "arrow"
				}
			],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "continueToTransaction",
			"rawText": "continueToTransaction",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "continueToTransaction"
		},
		{
			"type": "rectangle",
			"version": 1382,
			"versionNonce": 1202570898,
			"isDeleted": false,
			"id": "o9qmb3Axztx4EdUyRa93V",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 649.22084290454,
			"y": 25.947721086522506,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 16.971395486549547,
			"height": 500.5000649658408,
			"seed": 1830695134,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678268424861,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1647,
			"versionNonce": 253437010,
			"isDeleted": false,
			"id": "jTsVR8clxMNDDDj9A4TIW",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 960.443814961074,
			"y": 320.0655836097734,
			"strokeColor": "#000000",
			"backgroundColor": "#d1d1d1",
			"width": 16.971395486549547,
			"height": 78.28930171229354,
			"seed": 506525022,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "IqGiopcmdKICfgAjYL0Vt",
					"type": "arrow"
				},
				{
					"id": "ya9uQI6IbIrsGsz50P_Qn",
					"type": "arrow"
				},
				{
					"id": "Lw1SitYtCxW_-RhFYIQjU",
					"type": "arrow"
				}
			],
			"updated": 1678268427053,
			"link": null,
			"locked": false
		},
		{
			"type": "freedraw",
			"version": 23,
			"versionNonce": 492303097,
			"isDeleted": false,
			"id": "ANEMCyoyXxnmY1l0G5W0h",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 680.5720972585361,
			"y": 539.287840277152,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 38.52420472353674,
			"height": 20.099582290807007,
			"seed": 775298654,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.4356867348390097,
					0.47856224494637445
				],
				[
					-2.3928112247317586,
					1.1963976131307845
				],
				[
					-3.3499357146245075,
					1.9142489797854978
				],
				[
					-6.46058230754079,
					3.5892088378626568
				],
				[
					-9.810518022165411,
					5.74273094088619
				],
				[
					-13.639015981736407,
					7.896269042380027
				],
				[
					-17.94606018778336,
					10.767626513587857
				],
				[
					-22.01383127059239,
					13.160437738319729
				],
				[
					-27.99585133318692,
					16.51037345294435
				],
				[
					-31.34578704781154,
					18.18533331102151
				],
				[
					-33.97787139578145,
					19.381746922622597
				],
				[
					-35.41355813062057,
					19.86030916756897
				],
				[
					-36.60995574375124,
					19.86030916756897
				],
				[
					-37.806369355352444,
					20.099582290807007
				],
				[
					-38.52420472353674,
					20.099582290807007
				],
				[
					-38.52420472353674,
					20.099582290807007
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 2056230167,
			"isDeleted": false,
			"id": "XASJhuCfv6meUYx6aM8XQ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 642.2871656582373,
			"y": 539.0485671539141,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 38.04564247859048,
			"height": 23.210228883723175,
			"seed": 238789790,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.6749758565475759,
					1.4356707363687065
				],
				[
					2.632084347969908,
					2.1535221030234197
				],
				[
					4.067771082809031,
					3.589208837862543
				],
				[
					8.853393532272776,
					6.939128554016861
				],
				[
					14.835413594867305,
					10.767626513587857
				],
				[
					21.53526902564613,
					14.835397596396774
				],
				[
					27.756578209948998,
					18.42460643425943
				],
				[
					32.542184660942326,
					21.056706780699642
				],
				[
					35.89212037556706,
					22.492377517068462
				],
				[
					37.567080233644106,
					22.970939762014723
				],
				[
					38.04564247859048,
					23.210228883723175
				],
				[
					38.04564247859048,
					23.210228883723175
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 1739664345,
			"isDeleted": false,
			"id": "t9iov9NBiaVXWv6lm8zAb",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 985.5648377846112,
			"y": 509.272004042993,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 29.0311756673658,
			"height": 17.25630110731447,
			"seed": 829764226,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.0150709465400496,
					0.6090534269108616
				],
				[
					-2.233150652894551,
					1.2180932800881124
				],
				[
					-4.669337213070776,
					2.6391953199907903
				],
				[
					-7.714577200157919,
					4.66935078680433
				],
				[
					-11.165834706873966,
					6.699506253617756
				],
				[
					-14.820100973404806,
					8.93267048024586
				],
				[
					-18.88041190703177,
					11.368857040422085
				],
				[
					-22.737686933377063,
					13.60202126705019
				],
				[
					-25.57991816064964,
					15.226145640500931
				],
				[
					-27.610060053729512,
					16.4442389205891
				],
				[
					-28.422122240454883,
					16.850270013951786
				],
				[
					-29.0311756673658,
					17.25630110731447
				],
				[
					-29.0311756673658,
					17.25630110731447
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "freedraw",
			"version": 19,
			"versionNonce": 137026103,
			"isDeleted": false,
			"id": "lkbfAOBu1eR6FMoQ6YhCl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 952.8793958507147,
			"y": 506.4297863894541,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 33.70054002790357,
			"height": 22.940722840658736,
			"seed": 159383682,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1678217949977,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.8120621867253703,
					1.0150845202735468
				],
				[
					1.015070946539936,
					1.421115613636232
				],
				[
					2.4361865601762247,
					2.233177800361659
				],
				[
					4.669364360537884,
					3.65427984026428
				],
				[
					7.917585959972371,
					5.68443530707782
				],
				[
					11.368843466688531,
					7.308559680528674
				],
				[
					15.02313688068648,
					9.744732666971231
				],
				[
					20.30152752066806,
					12.789959080324707
				],
				[
					23.346740360287868,
					15.023136880686366
				],
				[
					25.98596282774588,
					17.459309867129036
				],
				[
					28.82816690755112,
					19.692487667490695
				],
				[
					31.26435346772746,
					20.91058094757875
				],
				[
					33.091486600992766,
					22.53469174729605
				],
				[
					33.70054002790357,
					22.940722840658736
				],
				[
					33.70054002790357,
					22.940722840658736
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": true,
			"pressures": []
		},
		{
			"type": "text",
			"version": 191,
			"versionNonce": 137382073,
			"isDeleted": false,
			"id": "qVXXSelz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 195.95256306507883,
			"y": 188.0249942201791,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 48,
			"height": 20,
			"seed": 1132926174,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1678217949978,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "[else]",
			"rawText": "[else]",
			"baseline": 14,
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "[else]"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#d1d1d1",
		"currentItemStrokeColor": "#000",
		"currentItemBackgroundColor": "#d1d1d1",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "center",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%