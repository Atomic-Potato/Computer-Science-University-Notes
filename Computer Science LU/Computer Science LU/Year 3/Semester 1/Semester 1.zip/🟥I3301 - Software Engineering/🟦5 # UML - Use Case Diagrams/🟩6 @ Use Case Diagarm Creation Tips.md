_Previous: [[🟩5 @ Detailed Textual Description (DTD)]]_ 

---


- Use a name that communicates purpose
- Define one atomic behavior per use case
- Define flow of events clearly
- Provide only essential details
- Factor common behaviors
- Factor variants