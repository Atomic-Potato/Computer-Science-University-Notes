---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
begin ^8fJKhpro

MMU accesses
the TLB ^0F3iZqZe

page in
TLB ? ^U6xgvRiC

access page
table ^HTJUz74n

page in
memeory? ^BO0sdtSL

Update TLB ^SGHPf1og

generation of
physical address ^Puou55nI

memory
full? ^2xlvswME

fetch page
from disk ^h5vH3j9f

update page
table ^cFAWgItr

page
replacement ^hBDPgMdK

yes ^We8TBnJF

no ^ZT2tNanR

yes ^7Puvav7E

no ^Z6fNEccl

yes ^pSDs0qLe

no ^wQ9DQzlC

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "8fJKhpro",
			"type": "text",
			"x": -64.81383514404297,
			"y": -165.4216766357422,
			"width": 65,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1750835918,
			"version": 10,
			"versionNonce": 1311535054,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854145533,
			"link": null,
			"locked": false,
			"text": "begin",
			"rawText": "begin",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "begin"
		},
		{
			"id": "0F3iZqZe",
			"type": "text",
			"x": -133.87090301513672,
			"y": -1.0016937255859375,
			"width": 201,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1635131918,
			"version": 44,
			"versionNonce": 1648097234,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854148735,
			"link": null,
			"locked": false,
			"text": "MMU accesses\nthe TLB",
			"rawText": "MMU accesses\nthe TLB",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "MMU accesses\nthe TLB"
		},
		{
			"id": "U6xgvRiC",
			"type": "text",
			"x": -76.32646070207875,
			"y": 263.8615788051061,
			"width": 96,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 532261714,
			"version": 48,
			"versionNonce": 773579854,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854187834,
			"link": null,
			"locked": false,
			"text": "page in\nTLB ?",
			"rawText": "page in\nTLB ?",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "page in\nTLB ?"
		},
		{
			"id": "HTJUz74n",
			"type": "text",
			"x": -98.79100799560547,
			"y": 526.9493996756418,
			"width": 169,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 509021394,
			"version": 68,
			"versionNonce": 1315385106,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854189303,
			"link": null,
			"locked": false,
			"text": "access page\ntable",
			"rawText": "access page\ntable",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "access page\ntable"
		},
		{
			"id": "BO0sdtSL",
			"type": "text",
			"x": -74.79667554582875,
			"y": 779.6806182861328,
			"width": 121,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1397042062,
			"version": 73,
			"versionNonce": 839548050,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854191271,
			"link": null,
			"locked": false,
			"text": "page in\nmemeory?",
			"rawText": "page in\nmemeory?",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "page in\nmemeory?"
		},
		{
			"id": "SGHPf1og",
			"type": "text",
			"x": -103.29059334406702,
			"y": 1002.6725868346198,
			"width": 175,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 377613262,
			"version": 19,
			"versionNonce": 1416110670,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854208157,
			"link": null,
			"locked": false,
			"text": "Update TLB",
			"rawText": "Update TLB",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "Update TLB"
		},
		{
			"id": "Puou55nI",
			"type": "text",
			"x": 351.89125654432564,
			"y": 986.7150324261377,
			"width": 226,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1908174674,
			"version": 55,
			"versionNonce": 634699410,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854415163,
			"link": null,
			"locked": false,
			"text": "generation of\nphysical address",
			"rawText": "generation of\nphysical address",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "generation of\nphysical address"
		},
		{
			"id": "2xlvswME",
			"type": "text",
			"x": -586.2629008217452,
			"y": 768.4689648340618,
			"width": 92,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 979834254,
			"version": 22,
			"versionNonce": 2079454162,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854236147,
			"link": null,
			"locked": false,
			"text": "memory\nfull?",
			"rawText": "memory\nfull?",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "memory\nfull?"
		},
		{
			"id": "h5vH3j9f",
			"type": "text",
			"x": -600.9828540862542,
			"y": 994.3728083050437,
			"width": 150,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 153134930,
			"version": 56,
			"versionNonce": 319097170,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854259552,
			"link": null,
			"locked": false,
			"text": "fetch page\nfrom disk",
			"rawText": "fetch page\nfrom disk",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "fetch page\nfrom disk"
		},
		{
			"id": "cFAWgItr",
			"type": "text",
			"x": -619.1335062904953,
			"y": 1246.5368533664277,
			"width": 173,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 540984146,
			"version": 52,
			"versionNonce": 1606249806,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854257734,
			"link": null,
			"locked": false,
			"text": "update page\ntable",
			"rawText": "update page\ntable",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "update page\ntable"
		},
		{
			"id": "hBDPgMdK",
			"type": "text",
			"x": -1002.3129322112541,
			"y": 766.3105873229011,
			"width": 161,
			"height": 69,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 59530450,
			"version": 46,
			"versionNonce": 2001492238,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854299200,
			"link": null,
			"locked": false,
			"text": "page\nreplacement",
			"rawText": "page\nreplacement",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "page\nreplacement"
		},
		{
			"id": "ir6rNzGe31EQRJY5G9AEw",
			"type": "ellipse",
			"x": -116.13064635745889,
			"y": -179.03936210511222,
			"width": 157.79628208705356,
			"height": 67.81324114118303,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1991903054,
			"version": 27,
			"versionNonce": 1396838990,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "nVfSyeeDN0QfDTTD0TYXJ",
					"type": "arrow"
				}
			],
			"updated": 1677854424768,
			"link": null,
			"locked": false
		},
		{
			"id": "wztixaDB4PgWDxrfndAJS",
			"type": "rectangle",
			"x": -163.0782781933964,
			"y": -9.506237453884523,
			"width": 254.29975237165172,
			"height": 88.67893763950894,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 665814734,
			"version": 46,
			"versionNonce": 756051666,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "nVfSyeeDN0QfDTTD0TYXJ",
					"type": "arrow"
				},
				{
					"id": "OVEo9UE8nFYnsQvZNEoxu",
					"type": "arrow"
				}
			],
			"updated": 1677854430281,
			"link": null,
			"locked": false
		},
		{
			"id": "wG4w0c2QJ23Kr6WMlZyJh",
			"type": "diamond",
			"x": -107.00187961638744,
			"y": 220.01559569343692,
			"width": 153.88392857142856,
			"height": 155.18807547433028,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 369244238,
			"version": 88,
			"versionNonce": 398158354,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "OVEo9UE8nFYnsQvZNEoxu",
					"type": "arrow"
				},
				{
					"id": "-bHQ7oFZcyFOb8uLinhVy",
					"type": "arrow"
				},
				{
					"id": "F0DXXhX5SPoKW_lMxUNwM",
					"type": "arrow"
				}
			],
			"updated": 1677854438063,
			"link": null,
			"locked": false
		},
		{
			"id": "q5NPMz-mUSuzisumrgqVP",
			"type": "rectangle",
			"x": -126.56338561527139,
			"y": 519.4810149177672,
			"width": 225.60947963169633,
			"height": 87.37479073660711,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1866961618,
			"version": 24,
			"versionNonce": 1307329486,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "-bHQ7oFZcyFOb8uLinhVy",
					"type": "arrow"
				},
				{
					"id": "zrbw4XjDFZtiu53eoV4UN",
					"type": "arrow"
				}
			],
			"updated": 1677854457230,
			"link": null,
			"locked": false
		},
		{
			"id": "VU0DGTb0XQg6V506b88_l",
			"type": "diamond",
			"x": -107.00179242330717,
			"y": 747.814755152142,
			"width": 179.9659075055805,
			"height": 142.14712960379464,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1061108242,
			"version": 98,
			"versionNonce": 1656072658,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "zrbw4XjDFZtiu53eoV4UN",
					"type": "arrow"
				},
				{
					"id": "6weu1MOgbvlJxg47xPxNl",
					"type": "arrow"
				},
				{
					"id": "iZvDoY5mp8wA4RXZOurTT",
					"type": "arrow"
				}
			],
			"updated": 1677854468207,
			"link": null,
			"locked": false
		},
		{
			"id": "kXwgSv6Aw5EhYWQ1LwcaP",
			"type": "diamond",
			"x": -618.209547375874,
			"y": 734.7738092816064,
			"width": 152.5798688616071,
			"height": 126.49780273437499,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1935451854,
			"version": 51,
			"versionNonce": 1733185038,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "iZvDoY5mp8wA4RXZOurTT",
					"type": "arrow"
				},
				{
					"id": "JxX0HgVrP1vHAvOJzZ0e5",
					"type": "arrow"
				},
				{
					"id": "1irw353CfOo-HcUWKOeW7",
					"type": "arrow"
				}
			],
			"updated": 1677854473263,
			"link": null,
			"locked": false
		},
		{
			"id": "Ho8rirs4Y2gOaioS9kn2f",
			"type": "rectangle",
			"x": -623.4259606013204,
			"y": 977.3366754925439,
			"width": 191.702880859375,
			"height": 97.80761718749977,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 2132497166,
			"version": 63,
			"versionNonce": 685383186,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "1irw353CfOo-HcUWKOeW7",
					"type": "arrow"
				},
				{
					"id": "LfCQUVvJRoFr7Ve8vUhGM",
					"type": "arrow"
				}
			],
			"updated": 1677854475855,
			"link": null,
			"locked": false
		},
		{
			"id": "lrSIzoj3CWE4WdAsDthby",
			"type": "rectangle",
			"x": -1014.65634215824,
			"y": 769.9845549568296,
			"width": 189.0947178431921,
			"height": 66.50913783482144,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 782197966,
			"version": 51,
			"versionNonce": 1113199762,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "JxX0HgVrP1vHAvOJzZ0e5",
					"type": "arrow"
				}
			],
			"updated": 1677854470968,
			"link": null,
			"locked": false
		},
		{
			"id": "9sKGS5w2qM5GCDlCVVSm-",
			"type": "rectangle",
			"x": -636.4669936649361,
			"y": 1235.5486941867402,
			"width": 211.26447405133922,
			"height": 84.76658412388406,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1273691982,
			"version": 56,
			"versionNonce": 1843687186,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "LfCQUVvJRoFr7Ve8vUhGM",
					"type": "arrow"
				},
				{
					"id": "G77C74TG5gYq_a0gXzo2z",
					"type": "arrow"
				}
			],
			"updated": 1677854479215,
			"link": null,
			"locked": false
		},
		{
			"id": "CIOL_990jyj4Fz197YCsq",
			"type": "rectangle",
			"x": -116.13051556783807,
			"y": 986.4653550405349,
			"width": 199.52741350446445,
			"height": 62.59687151227672,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 576065550,
			"version": 34,
			"versionNonce": 2036907218,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "6weu1MOgbvlJxg47xPxNl",
					"type": "arrow"
				},
				{
					"id": "q7u-OG54qAPoRg_9ZnYa4",
					"type": "arrow"
				},
				{
					"id": "G77C74TG5gYq_a0gXzo2z",
					"type": "arrow"
				}
			],
			"updated": 1677854479215,
			"link": null,
			"locked": false
		},
		{
			"id": "6g0GMa3PkPF-79yuqnvwZ",
			"type": "rectangle",
			"x": 323.3517319210014,
			"y": 972.1202622670976,
			"width": 272.5571986607142,
			"height": 92.59111676897305,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 108916242,
			"version": 56,
			"versionNonce": 1121742222,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "F0DXXhX5SPoKW_lMxUNwM",
					"type": "arrow"
				},
				{
					"id": "q7u-OG54qAPoRg_9ZnYa4",
					"type": "arrow"
				}
			],
			"updated": 1677854464817,
			"link": null,
			"locked": false
		},
		{
			"id": "nVfSyeeDN0QfDTTD0TYXJ",
			"type": "arrow",
			"x": -38.670130290679936,
			"y": -103.78600081186431,
			"width": 0,
			"height": 91.28707885742188,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1994983886,
			"version": 37,
			"versionNonce": 123306386,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854424768,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					91.28707885742188
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "ir6rNzGe31EQRJY5G9AEw",
				"focus": 0.018221278191519287,
				"gap": 7.44552992829702
			},
			"endBinding": {
				"elementId": "wztixaDB4PgWDxrfndAJS",
				"focus": -0.021562964631616735,
				"gap": 2.992684500557914
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "OVEo9UE8nFYnsQvZNEoxu",
			"type": "arrow",
			"x": -44.755945720367436,
			"y": 90.95978776235444,
			"width": 12.171630859375,
			"height": 114.10888671875,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 253777614,
			"version": 36,
			"versionNonce": 1032855374,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854430281,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12.171630859375,
					114.10888671875
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "wztixaDB4PgWDxrfndAJS",
				"focus": 0.11233279418046692,
				"gap": 11.787087576730016
			},
			"endBinding": {
				"elementId": "wG4w0c2QJ23Kr6WMlZyJh",
				"focus": 0.09548299629259675,
				"gap": 12.31691492886172
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "-bHQ7oFZcyFOb8uLinhVy",
			"type": "arrow",
			"x": -32.584314860992436,
			"y": 392.2071937682138,
			"width": 4.5644124348957575,
			"height": 114.10888671875,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1160447374,
			"version": 24,
			"versionNonce": 407560334,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854432991,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4.5644124348957575,
					114.10888671875
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "wG4w0c2QJ23Kr6WMlZyJh",
				"focus": 0.08198840811990371,
				"gap": 13.765002590446443
			},
			"endBinding": {
				"elementId": "q5NPMz-mUSuzisumrgqVP",
				"focus": -0.10464337692136559,
				"gap": 13.164934430803385
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "F0DXXhX5SPoKW_lMxUNwM",
			"type": "arrow",
			"x": 54.138402424163814,
			"y": 293.31284562368256,
			"width": 406.22762044270826,
			"height": 669.4386800130208,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 360423118,
			"version": 191,
			"versionNonce": 315714830,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854449512,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					403.94551595052087,
					4.564412434895644
				],
				[
					406.22762044270826,
					669.4386800130208
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "wG4w0c2QJ23Kr6WMlZyJh",
				"focus": -0.06763654941500864,
				"gap": 8.178062125658101
			},
			"endBinding": {
				"elementId": "6g0GMa3PkPF-79yuqnvwZ",
				"focus": 0.006792508550430471,
				"gap": 9.368736630394324
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "zrbw4XjDFZtiu53eoV4UN",
			"type": "arrow",
			"x": -15.848373291982853,
			"y": 615.860554770818,
			"width": 0,
			"height": 121.71610514322913,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 142383950,
			"version": 37,
			"versionNonce": 147138578,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854457230,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					121.71610514322913
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "q5NPMz-mUSuzisumrgqVP",
				"focus": 0.01852517452698421,
				"gap": 9.00474911644369
			},
			"endBinding": {
				"elementId": "VU0DGTb0XQg6V506b88_l",
				"focus": 0.013007634554314309,
				"gap": 8.759699320372214
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "6weu1MOgbvlJxg47xPxNl",
			"type": "arrow",
			"x": -14.326868571930845,
			"y": 895.8076576354014,
			"width": 3.04290771484375,
			"height": 77.593994140625,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1237997010,
			"version": 39,
			"versionNonce": 1213417230,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854460943,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-3.04290771484375,
					77.593994140625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "VU0DGTb0XQg6V506b88_l",
				"focus": -0.06343891156357606,
				"gap": 6.255954786903814
			},
			"endBinding": {
				"elementId": "CIOL_990jyj4Fz197YCsq",
				"focus": -0.027157468836896948,
				"gap": 13.06370326450849
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "q7u-OG54qAPoRg_9ZnYa4",
			"type": "arrow",
			"x": 93.69610099187139,
			"y": 1016.0023597838389,
			"width": 223.65336100260402,
			"height": 1.521402994791515,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 615724366,
			"version": 17,
			"versionNonce": 406510738,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854464817,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					223.65336100260402,
					1.521402994791515
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "CIOL_990jyj4Fz197YCsq",
				"focus": -0.07849792866484816,
				"gap": 10.299203055245016
			},
			"endBinding": {
				"elementId": "6g0GMa3PkPF-79yuqnvwZ",
				"focus": -0.001605341295758768,
				"gap": 6.002269926525969
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "iZvDoY5mp8wA4RXZOurTT",
			"type": "arrow",
			"x": -116.26412443130585,
			"y": 821.25657120962,
			"width": 331.6764322916665,
			"height": 16.736043294270758,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 966097490,
			"version": 37,
			"versionNonce": 204477518,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854468207,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-331.6764322916665,
					-16.736043294270758
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "VU0DGTb0XQg6V506b88_l",
				"focus": -0.10378069291096233,
				"gap": 7.599516403740083
			},
			"endBinding": {
				"elementId": "kXwgSv6Aw5EhYWQ1LwcaP",
				"focus": 0.027759108459103173,
				"gap": 16.29217633298986
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "JxX0HgVrP1vHAvOJzZ0e5",
			"type": "arrow",
			"x": -628.9933114430245,
			"y": 793.8704017760263,
			"width": 182.57415771484375,
			"height": 9.12872314453125,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 100948622,
			"version": 22,
			"versionNonce": 1112002382,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854470968,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-182.57415771484375,
					9.12872314453125
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "kXwgSv6Aw5EhYWQ1LwcaP",
				"focus": 0.1344845663886244,
				"gap": 10.079237325957386
			},
			"endBinding": {
				"elementId": "lrSIzoj3CWE4WdAsDthby",
				"focus": 0.13656714667318573,
				"gap": 13.994155157179762
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "1irw353CfOo-HcUWKOeW7",
			"type": "arrow",
			"x": -536.1847787281806,
			"y": 871.4643959166513,
			"width": 4.5643107096354925,
			"height": 92.80853271484386,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 929871246,
			"version": 37,
			"versionNonce": 907010514,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854473263,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-4.5643107096354925,
					92.80853271484386
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "kXwgSv6Aw5EhYWQ1LwcaP",
				"focus": -0.12251532442437048,
				"gap": 11.506985577013467
			},
			"endBinding": {
				"elementId": "Ho8rirs4Y2gOaioS9kn2f",
				"focus": -0.1650997259825884,
				"gap": 13.063746861048685
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "LfCQUVvJRoFr7Ve8vUhGM",
			"type": "arrow",
			"x": -536.1847787281806,
			"y": 1090.55344620962,
			"width": 4.5644124348957575,
			"height": 132.366231282552,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 2031605650,
			"version": 45,
			"versionNonce": 2146173966,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854475855,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4.5644124348957575,
					132.366231282552
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "Ho8rirs4Y2gOaioS9kn2f",
				"focus": 0.11101312314495387,
				"gap": 15.409153529576429
			},
			"endBinding": {
				"elementId": "9sKGS5w2qM5GCDlCVVSm-",
				"focus": 0.010377741972696839,
				"gap": 12.629016694568236
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "G77C74TG5gYq_a0gXzo2z",
			"type": "arrow",
			"x": -414.4686735849516,
			"y": 1277.6920163593595,
			"width": 404.70611572265625,
			"height": 224.41411336263036,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1143755342,
			"version": 127,
			"versionNonce": 183087506,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854482760,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					404.70611572265625,
					0.7606506347658524
				],
				[
					401.6632080078125,
					-223.6534627278645
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "9sKGS5w2qM5GCDlCVVSm-",
				"focus": -0.010771766473158684,
				"gap": 10.733846028645303
			},
			"endBinding": {
				"elementId": "CIOL_990jyj4Fz197YCsq",
				"focus": -0.030637186841145993,
				"gap": 4.9763270786834255
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "We8TBnJF",
			"type": "text",
			"x": 154.3759105621839,
			"y": 250.38387020050533,
			"width": 46,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 186865810,
			"version": 5,
			"versionNonce": 290446354,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854495552,
			"link": null,
			"locked": false,
			"text": "yes",
			"rawText": "yes",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "yes"
		},
		{
			"id": "ZT2tNanR",
			"type": "text",
			"x": -17.616663493805618,
			"y": 411.49643937368245,
			"width": 30,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1938109518,
			"version": 17,
			"versionNonce": 566725774,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854501375,
			"link": null,
			"locked": false,
			"text": "no",
			"rawText": "no",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "no"
		},
		{
			"id": "7Puvav7E",
			"type": "text",
			"x": 5.538426838225632,
			"y": 895.9223020038908,
			"width": 46,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 672603026,
			"version": 25,
			"versionNonce": 1944133710,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854520749,
			"link": null,
			"locked": false,
			"text": "yes",
			"rawText": "yes",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "yes"
		},
		{
			"id": "Z6fNEccl",
			"type": "text",
			"x": -181.48151131281622,
			"y": 778.4535316588388,
			"width": 30,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1150076366,
			"version": 28,
			"versionNonce": 1834766290,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854519183,
			"link": null,
			"locked": false,
			"text": "no",
			"rawText": "no",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "no"
		},
		{
			"id": "pSDs0qLe",
			"type": "text",
			"x": -744.5309497893786,
			"y": 749.760497804672,
			"width": 46,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1641276622,
			"version": 5,
			"versionNonce": 1950320974,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854525649,
			"link": null,
			"locked": false,
			"text": "yes",
			"rawText": "yes",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "yes"
		},
		{
			"id": "wQ9DQzlC",
			"type": "text",
			"x": -514.7191211760974,
			"y": 887.512979901026,
			"width": 30,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1248595406,
			"version": 14,
			"versionNonce": 1883170386,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677854533152,
			"link": null,
			"locked": false,
			"text": "no",
			"rawText": "no",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "no"
		},
		{
			"id": "DEQzpX8z",
			"type": "text",
			"x": 7.135716877287905,
			"y": 659.760497804672,
			"width": 16,
			"height": 35,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1409192210,
			"version": 9,
			"versionNonce": 688683026,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1677854507427,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": ""
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "center",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "sharp",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%