---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
In layout management ^0JeAMvXq

continuous [old] ^CT0Bbp6j

non continuous ^jO8EuawW

paging ^FId7WqEJ

page table ^p2okFgh1

single
level ^kYig3Vmo

multi
level ^imOCsHrP

inverted ^zz0ghug7

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "0JeAMvXq",
			"type": "text",
			"x": -443.65526580810547,
			"y": -20.752426147460938,
			"width": 217,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1016457194,
			"version": 26,
			"versionNonce": 1345562858,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "Zvh-O7ELaan5AwzRnkERe",
					"type": "arrow"
				},
				{
					"id": "0pH3lGo8tW9AftIcIQ7Xm",
					"type": "arrow"
				}
			],
			"updated": 1677919400550,
			"link": null,
			"locked": false,
			"text": "In layout management",
			"rawText": "In layout management",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "In layout management"
		},
		{
			"id": "CT0Bbp6j",
			"type": "text",
			"x": -85.80986785888672,
			"y": -91.04350280761719,
			"width": 160,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1103970998,
			"version": 31,
			"versionNonce": 1949370986,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "Zvh-O7ELaan5AwzRnkERe",
					"type": "arrow"
				}
			],
			"updated": 1677919389575,
			"link": null,
			"locked": false,
			"text": "continuous [old]",
			"rawText": "continuous [old]",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "continuous [old]"
		},
		{
			"id": "jO8EuawW",
			"type": "text",
			"x": -63.90099334716797,
			"y": 16.675247192382812,
			"width": 142,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 777028842,
			"version": 48,
			"versionNonce": 1991921974,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "0pH3lGo8tW9AftIcIQ7Xm",
					"type": "arrow"
				},
				{
					"id": "lazXL5yqWQALI9XMOIBAa",
					"type": "arrow"
				}
			],
			"updated": 1677919407174,
			"link": null,
			"locked": false,
			"text": "non continuous",
			"rawText": "non continuous",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "non continuous"
		},
		{
			"id": "FId7WqEJ",
			"type": "text",
			"x": 158.52320098876953,
			"y": 16.653762817382812,
			"width": 59,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 867443702,
			"version": 45,
			"versionNonce": 1428077546,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "lazXL5yqWQALI9XMOIBAa",
					"type": "arrow"
				},
				{
					"id": "tPeAV4dP0ESl-kO2B9ut5",
					"type": "arrow"
				}
			],
			"updated": 1677919409438,
			"link": null,
			"locked": false,
			"text": "paging",
			"rawText": "paging",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "paging"
		},
		{
			"id": "p2okFgh1",
			"type": "text",
			"x": 344.97071075439453,
			"y": 18.396316528320312,
			"width": 107,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1258867702,
			"version": 41,
			"versionNonce": 1044004918,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "tPeAV4dP0ESl-kO2B9ut5",
					"type": "arrow"
				},
				{
					"id": "c_-3_NJ34D8mtuE05KYSi",
					"type": "arrow"
				},
				{
					"id": "iu2A4K-lvk5Qn77QPAebV",
					"type": "arrow"
				},
				{
					"id": "-R7qiKrh2GmdvJEVE307k",
					"type": "arrow"
				}
			],
			"updated": 1677919419598,
			"link": null,
			"locked": false,
			"text": "page table",
			"rawText": "page table",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "page table"
		},
		{
			"id": "kYig3Vmo",
			"type": "text",
			"x": 259.51087188720703,
			"y": 127.16028137207024,
			"width": 52,
			"height": 49,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1723989354,
			"version": 47,
			"versionNonce": 1303443498,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "c_-3_NJ34D8mtuE05KYSi",
					"type": "arrow"
				}
			],
			"updated": 1677919412230,
			"link": null,
			"locked": false,
			"text": "single\nlevel",
			"rawText": "single\nlevel",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 42,
			"containerId": null,
			"originalText": "single\nlevel"
		},
		{
			"id": "imOCsHrP",
			"type": "text",
			"x": 386.0922439575196,
			"y": 129.99521789550772,
			"width": 46,
			"height": 49,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1572697078,
			"version": 51,
			"versionNonce": 324082794,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "iu2A4K-lvk5Qn77QPAebV",
					"type": "arrow"
				}
			],
			"updated": 1677919414606,
			"link": null,
			"locked": false,
			"text": "multi\nlevel",
			"rawText": "multi\nlevel",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 42,
			"containerId": null,
			"originalText": "multi\nlevel"
		},
		{
			"id": "zz0ghug7",
			"type": "text",
			"x": 492.4590408325197,
			"y": 144.32236633300778,
			"width": 80,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1219599862,
			"version": 49,
			"versionNonce": 1219545462,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "-R7qiKrh2GmdvJEVE307k",
					"type": "arrow"
				}
			],
			"updated": 1677919419598,
			"link": null,
			"locked": false,
			"text": "inverted",
			"rawText": "inverted",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "inverted"
		},
		{
			"id": "Zvh-O7ELaan5AwzRnkERe",
			"type": "arrow",
			"x": -215.72221627238412,
			"y": -16.922198616020466,
			"width": 120.49211335527423,
			"height": 66.74745513527893,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1516208054,
			"version": 29,
			"versionNonce": 831263350,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919394711,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					120.49211335527423,
					-66.74745513527893
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "0JeAMvXq",
				"focus": 0.7918398161523627,
				"gap": 10.933049535721352
			},
			"endBinding": {
				"elementId": "CT0Bbp6j",
				"focus": 0.9620631144174453,
				"gap": 9.42023505822317
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "0pH3lGo8tW9AftIcIQ7Xm",
			"type": "arrow",
			"x": -215.72221627238412,
			"y": -7.386864441883006,
			"width": 143.03024444469543,
			"height": 38.14139465470822,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 181204970,
			"version": 25,
			"versionNonce": 1021784758,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919400550,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					143.03024444469543,
					38.14139465470822
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "0JeAMvXq",
				"focus": -0.7477856106840289,
				"gap": 10.933049535721352
			},
			"endBinding": {
				"elementId": "jO8EuawW",
				"focus": -0.7271540780839916,
				"gap": 8.790978480520721
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "lazXL5yqWQALI9XMOIBAa",
			"type": "arrow",
			"x": 87.37429982012884,
			"y": 28.488924878473256,
			"width": 62.40468004125569,
			"height": 2.034915500314753,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1486485098,
			"version": 34,
			"versionNonce": 632751402,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919407174,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					62.40468004125569,
					2.034915500314753
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "jO8EuawW",
				"focus": -0.22301222236161,
				"gap": 9.275293167296809
			},
			"endBinding": {
				"elementId": "FId7WqEJ",
				"focus": -0.19441167056712325,
				"gap": 8.744221127385003
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "tPeAV4dP0ESl-kO2B9ut5",
			"type": "arrow",
			"x": 229.81974541326895,
			"y": 34.593716731787765,
			"width": 101.06848271856813,
			"height": 0,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 196136938,
			"version": 33,
			"versionNonce": 506122166,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919409438,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					101.06848271856813,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "FId7WqEJ",
				"focus": 0.4351963131523962,
				"gap": 12.296544424499416
			},
			"endBinding": {
				"elementId": "p2okFgh1",
				"focus": -0.2957920162773962,
				"gap": 14.08248262255745
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "c_-3_NJ34D8mtuE05KYSi",
			"type": "arrow",
			"x": 392.6145274190375,
			"y": 54.94305314441624,
			"width": 106.49489381782735,
			"height": 61.04805459025579,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 182675702,
			"version": 34,
			"versionNonce": 1285598774,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919412230,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-106.49489381782735,
					61.04805459025579
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "p2okFgh1",
				"focus": -0.4792740579723891,
				"gap": 11.546736616095927
			},
			"endBinding": {
				"elementId": "kYig3Vmo",
				"focus": -0.8963502432815973,
				"gap": 11.169173637398217
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "iu2A4K-lvk5Qn77QPAebV",
			"type": "arrow",
			"x": 395.3277783210373,
			"y": 50.87317679141654,
			"width": 8.139752705999513,
			"height": 67.83118184525534,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1545172854,
			"version": 36,
			"versionNonce": 1326507510,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919414606,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.139752705999513,
					67.83118184525534
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "p2okFgh1",
				"focus": 0.10073015760873529,
				"gap": 7.476860263096228
			},
			"endBinding": {
				"elementId": "imOCsHrP",
				"focus": -0.05126460580879306,
				"gap": 11.290859258835837
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "-R7qiKrh2GmdvJEVE307k",
			"type": "arrow",
			"x": 400.75428012503687,
			"y": 51.86045253917894,
			"width": 114.63464652382686,
			"height": 81.39739100288426,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1529657142,
			"version": 41,
			"versionNonce": 162629162,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677919419598,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					114.63464652382686,
					81.39739100288426
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "p2okFgh1",
				"focus": 0.3831128466392319,
				"gap": 8.464136010858624
			},
			"endBinding": {
				"elementId": "zz0ghug7",
				"focus": 0.2797815957556101,
				"gap": 11.06452279094458
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%