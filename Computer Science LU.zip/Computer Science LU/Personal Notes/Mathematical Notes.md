### What is log ?
==Log = exponent==
Log_x(y) = z <==> x^z = y Thats it really
Its pretty useful to find the number of digits in a number.
If you use `Log to the base of 10` and add `1` to the integer of the result you'll get the number of digits in that number (y as in the above).
