# ERD

## Creating an ERD
File -> New Model -> Model Types -> Conceptual Data Model

## ERD to RDM
- Tools->Check Model | Now fix any errors
- Tools->Generate Physical Data Model
	- DBMS: *Microsoft SQL Server 2014*
	- Pick a name