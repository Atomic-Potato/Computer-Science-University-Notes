# Case of many attributes
![[Pasted image 20220713170104.png]]
- We make two entities, one containing the most commonly used attributes
- And one containing the rest
- And we link them using a **one-to-one** relation