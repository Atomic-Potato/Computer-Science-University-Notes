In the following exercise, draw the resulting tables of the given equations:
![[Pasted image 20220719170454.png | 750]]

![[Pasted image 20220719170634.png | 750]]