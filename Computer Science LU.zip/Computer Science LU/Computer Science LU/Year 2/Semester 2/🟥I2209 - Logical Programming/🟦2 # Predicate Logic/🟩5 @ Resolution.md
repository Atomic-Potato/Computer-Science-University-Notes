Tbh i have no idea
![[Pasted image 20220620210142.png]]

*Example:*
![[Pasted image 20220620210413.png]]