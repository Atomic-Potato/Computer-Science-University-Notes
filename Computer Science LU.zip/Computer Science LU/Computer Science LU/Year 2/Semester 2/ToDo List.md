# Schedule
![[WhatsApp Image 2022-05-10 at 12.14.10 PM.jpeg | 300]]
![[Final Exams Program.png | 300]]
![[Pasted image 20220917133547.png | 300]]
![[Pasted image 20220913170444.png | 300]]
i'll maybe give 20th for 6 as well
At 22 its 33 not 7
# Due
### `L2200`


### `I2206`
- [ ] 5/29th big O lecture
- [x] Quiz 1 solutions
- [ ] Solve all the exercises about Asymptotic Analysis
	- [x] 1
	- [x] 2
	- [x] 3
	- [x] 4
	- [x] 5
	- [x] 6
	- [x] 7
	- [x] 8
	- [x] 9
	- [x] 10
	- [x] 11
	- [x] 12
	- [x] 13
	- [x] 14
	- [x] 15
	- [x] 16
	- [x] 17
	- [x] 18
	- [x] 19
	- [x] 20
	- [x] 21
	- [x] 22
	- [ ] 23
- [ ] Sorting Exercises EXTRA
- [ ] Searching Exercises
- [ ] Trees Exercises EXTRA

- [ ] Lab 9 Searching / hashing
- [ ] Quiz 8 Exercise
- [ ] See how to reverse the log2
### `I2207`


### `I2208`


### `I2209`


### `I2210`
- [ ] Install MySQL **OR** use Online SQL or SQL Fiddle
- [ ] session 23
- [ ] session 24
- [ ] session 25
- [ ] session 26
### `I2211`


### `I2234`
- [ ] Solve lecture 3 questions
- [ ] Lab 3
- [x] Lecture 6
- [ ] Lab 4
- [x] Lecture 7
      
# Personal
- [ ] see how catto converted the mouse keys into media buttons
- [x] Kanji
- [ ] Read & Speak Japanese
- [ ] Potato Punch
- [ ] Pixel art
- [ ] Keyboard touch typing
- [x] Make a linkedin
- [ ] buy Tayto Potato and send it to mike (https://www.smokonow.com/products/couch-potato-light)
- TLS & OMT 38$      

# Setup
- [ ] folder and IDs and money, your notebook
- [ ] Calculator, extra battery and a screwdriver
- [ ] Pencils, sharpener and an eraser
- [ ] Update obsidian's vault on your phone
- [ ] Music
- [ ] Alarm
- [ ] PDFs
- [ ] chargers
- [ ] podcasts
- [ ] MASKS !!!
- [ ] WOTAH !!!
- [ ] USB with SEB on it

![[Pasted image 20220927124527.png]]
![[Pasted image 20220927124458.png]]
![[Pasted image 20220927123744.png | 700]]
![[Pasted image 20220927124433.png]]

# Done
![[WhatsApp Image 2022-05-18 at 10.54.08 PM.jpeg | 600]]

### `200`
- [x] Recorded sessions
- [x] Presentation **BIIIIIIIIIIITCH AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH**

### `01`
- [x] read big O
- [x] Lab 1 (not gonna do it)
- [x] DS first practice (Revision for Imperative) not gonna do it either
- [x] Finish watching the video　(i cant bother)

### `06`
- [x] Trees exercises 1
- [x] stacks lab
- [x] Trees lab 1
- [x] Queues lecture
- [x] stacks practice 1 (Im not gonna do the last 2 questions)
- [x] Write down the Asymptotic course
- [x] Why did he take the kth step as 2 to the power i ?
- [x] write down the stacks lecture
- [x] stacks practice 2
- [x] Lab 2
- [x] Queues exercies
- [x] Queues lab
- [x] Trees session
- [x] Trees practice 2
- [x] Trees Lab 2
- [x] Sorting course 
- [x] Sorting Exercises
- [x] Searching course
- [x] Lab 7 Trees
- [x] Lab 8 Heaps

### `07`
- [x] write lecture 1
- [x] lecture 2
- [x] lecture 3 
- [x] lecture 4
- [x] Lecture 5
- [x] lecture 6
- [x] lecture 8
- [x] lecture 7
- [x] lab 2
- [x] lab 3
- [x] Lecture 9
- [x] Lab 4
- [x] Lecture 10
- [x] Lab 5
- [x] Lab 6
- [x] Lecture 11

### `08`
- [x] Start studying it you idiot, you only got 2 months before exams!!
- [x] session 1
- [x] session 2
- [x] session 3
- [x] session 4.1
- [x] session 4.2
- [x] session 5
- [x] Last chapter 5 session
- [x] 7/13 Lecture
- [x] 7/20 Lecture
- [x] 7/25 Lecture
- [x] 8/1 Lecture

### `09`
- [x] Prolog Session 02
- [x] Write session 2
- [x] Prolog Session 03
- [x] Ch1 session 1
- [x] Ch1 session 2
- [x] Ch2 session 1
- [x] Ch1 session 3 (and write down the course)
- [x] session 4
- [x] session 5
- [x] Ch2 session 2
- [x] Ch2 session 3
- [x] ch1 rev session
- [x] session 8
- [x] prolog session 1
- [x] Solve a little bit using Mars
- [x] lab1
- [x] session 11
- [x] session 12
- [x] session 13
- [x] download Prolog Interpreter (not gonna)
- [x] Write session 3

### `10`
- [x] Write down the important stuff from the last course
- [x] 19-5 lecture
- [x] Try to build an ERD leading to mange sale-operations is a given supermarket
- [x] Download Power designer or some alternative
- [x] session 8
- [x] 5/30th, write down the course
- [x] session 9
- [x] session 10
- [x] session 11
- [x] session 12
- [x] session 13
- [x] session 14
- [x] session 15
- [x] session 16
- [x] session 17
- [x] session 18
- [x] session 19
- [x] session 20
- [x] session 21
- [x] session 22
### `11`
- [x] note down the things from your images
- [x] 20-5 lecture
- [x] Install NetBeans
- [x] Check for any shenanigans in the java intro lecture
- [x] Introduction to java programming book by Daniel Liang
- [x] 6/1 packages last 20 mins
- [x] session 7
- [x] session 8
- [x] session 9
- [x] session 10
- [x] 6/13
- [x] 6/17
- [x] 6/20
- [x] 6/22
- [x] 6/24
- [x] 6/27
- [x] session 10 june 10
- [x] 6/29
- [x] 7/1
- [x] 7/4
- [x] 7/6
- [x] 7/8
- [x] 7/13 (didnt really need to watch)
- [x] 7/15 (didnt really need to watch)

### `34`
- [x] lecture 1
- [x] lecture 2
- [x] lecture 3
- [x] Lecture 4
- [x] install Octave and solve a little
- [x] Lab 1
- [x] Lecture 5
- [x] Lab 2
