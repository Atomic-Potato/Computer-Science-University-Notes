http://www.cs.bsu.edu/homepages/pvgestwicki/misc/uml/

---

![[Pasted image 20220718153057.png]]

- **Types:**
	- `-` private
	- `+` public
	- `#` [[Extra Java Notes#^protected|protected]]
- **Variables:**
	`varName : type`
- **Functions:**
	`FunctionName(varName : type) returnValue` (in case of void leave empty)

*Example:*
![[Pasted image 20220925005228.png]]

# Relations
![[Pasted image 20220925005323.png]]
![[Pasted image 20220925005356.png]]

(_Youll probably only need to know: `Aggregation`, `Composition`, `Generalization`_ | Better explained here [[🟩0 @ OOP Philosophies]]) 