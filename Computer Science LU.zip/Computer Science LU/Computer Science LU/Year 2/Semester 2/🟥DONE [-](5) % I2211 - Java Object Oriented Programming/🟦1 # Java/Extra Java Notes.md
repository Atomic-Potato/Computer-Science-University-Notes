- **Final**
	To declare a **constant** we use the `final` keyword. 
	A `final class` cannot extend any other classes.
	 `final` methods cannot be overwritten.
	
- **Booleans** use the keyword `boolean`

- Remember to create variables inside the main method in the **Testing Class** 


- **Protected VS Private**
	- `protected`: private for outside and public for subclasses ^protected
	- `private`: private for outside and private for subclasses

