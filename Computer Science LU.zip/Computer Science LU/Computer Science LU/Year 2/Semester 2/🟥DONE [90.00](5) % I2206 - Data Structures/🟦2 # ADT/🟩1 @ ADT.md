We will be asked to implement an ADT in exams

(oh yeah bro no shit)