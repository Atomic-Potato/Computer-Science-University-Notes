![[Pasted image 20220628145753.png]]
![[Pasted image 20220628145808.png]]
![[Pasted image 20220628145920.png]]
