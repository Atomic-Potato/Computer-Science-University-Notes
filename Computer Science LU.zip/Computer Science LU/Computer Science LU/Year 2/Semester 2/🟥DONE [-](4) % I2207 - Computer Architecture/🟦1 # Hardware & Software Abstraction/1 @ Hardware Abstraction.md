# Transistors
A `Transistor` is the basic element of computer. It can turn a current on and off.
A transistor contains a `Base` (B), `Collector` (C) and `Emitter` (E).
![[Pasted image 20220605192745.png | 150]]
If a current flows on B it allows for a current to flow from C to E.

## AND gate
![[Pasted image 20220605192859.png| 400]]
![[Pasted image 20220605192919.png | 200]]

## OR gate
![[Pasted image 20220605192955.png | 400]]
![[Pasted image 20220605193023.png]]

## Half adder
No circuit for this one, kind of easy since you know how AND and OR works
![[Pasted image 20220605193126.png | 300]]
