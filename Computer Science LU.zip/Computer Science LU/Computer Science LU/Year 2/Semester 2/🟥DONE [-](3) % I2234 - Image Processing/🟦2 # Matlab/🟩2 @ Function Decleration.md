Syntax:
```matlab
function [output1, output2 ... ] = function_name(input1, input2, ...)
	%%Code
end
```
If the function does not return a value, output field can be omitted.

This function must be saved in a file alone called `function_name.m`
To access it make sure youre working in the same directory, and then just write its name directly and give it input