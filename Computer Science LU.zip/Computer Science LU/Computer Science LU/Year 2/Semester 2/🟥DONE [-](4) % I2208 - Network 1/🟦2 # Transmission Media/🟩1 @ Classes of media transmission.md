![[Pasted image 20220704172845.png | 500]]

# Classes of transmission media
![[Pasted image 20220704172936.png]]
