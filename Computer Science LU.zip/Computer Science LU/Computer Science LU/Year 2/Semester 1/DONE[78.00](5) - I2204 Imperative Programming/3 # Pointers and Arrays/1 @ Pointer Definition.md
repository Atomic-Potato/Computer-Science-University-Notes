Tbh you already know, i will just add in here the stuff you dont know, you can go to `69 # other` for the definition


yeah there was nothing in here new