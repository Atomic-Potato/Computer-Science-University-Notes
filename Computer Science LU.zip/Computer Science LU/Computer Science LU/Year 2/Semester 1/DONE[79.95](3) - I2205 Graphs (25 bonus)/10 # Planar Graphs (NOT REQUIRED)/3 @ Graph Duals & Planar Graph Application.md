# Definitions
`Degree of faces:` is the total amount of edges that form the face
`dual G*` is a graph of G where the vertices of the graph are the faces and if two faces have an edge in common that forms them then we connected the vertices of the faces with an edge
![[Pasted image 20220131141717.png | 100]]

`loop:`
![[Pasted image 20220131142256.png | 350]]

# Theorems
- **Theo 1:** Sum of faces degrees = 2 nb of edges
- **Theo 2**: G of order n => G* has n faces
- (G*)*  is isomorphic to G