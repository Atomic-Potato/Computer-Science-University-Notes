# Theorems
- **Theo 1:** Every planar graph is 4-colorable
- **Theo 2:** Every planar graph is 5-colorable