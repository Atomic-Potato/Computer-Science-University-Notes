`Eulerization:` its transforming a non Eu graph into an Eu graph by:
- finding the set of vertices of odd degrees 
- getting the min distance between each vertex
- find the combination of 2 distances that has the minimum sum between them, and then add an edge for each pair in the distance sum

