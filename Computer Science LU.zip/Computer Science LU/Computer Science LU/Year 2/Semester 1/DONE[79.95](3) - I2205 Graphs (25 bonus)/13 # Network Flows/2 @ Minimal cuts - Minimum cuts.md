`value of the cut:` sum of capacities in the cut
`minimum cut:` cut with the smallest cut value
`minimal cut:` is a minimum cut with no redundant parts

**Max-Flow Min-Cut Theorem:** For any network N, the value of a maximum flow in N equals the cut value of a minimum cut.