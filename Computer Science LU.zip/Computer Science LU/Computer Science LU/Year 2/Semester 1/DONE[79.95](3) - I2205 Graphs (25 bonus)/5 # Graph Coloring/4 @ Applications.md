 ![[Flood fill.jpg | 600]]
 ![[Flood fill 2.jpg | 600]]