# My Algorithms
![[MaxColorDegreeColoring.cpp]]
![[SequentialColoring.cpp]]

# Professor's algorithms
![[MaxColorDegreeColoringP.cpp]]

![[SequentialColoringP.cpp]]