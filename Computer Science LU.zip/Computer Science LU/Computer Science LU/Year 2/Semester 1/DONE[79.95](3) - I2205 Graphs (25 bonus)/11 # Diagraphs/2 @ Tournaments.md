`Tournament:` a beats b, b beats c, a beats c
![[Pasted image 20220203125630.png]]

`score sequence:` is listing the out degrees in a sequence

`transitive tournaments:` have a degree sequence of 0,1,2...,n-1
# Theorems
- **Theo 1:**
![[Pasted image 20220203125827.png | 600]]
	- **Corollary:**
	![[Pasted image 20220203125854.png | 600]]

- **Theo 2:**
![[Pasted image 20220203125946.png | 600]]

- **Theo 3:**
![[Pasted image 20220203130021.png | 600]]

- **Theo 4:**
![[Pasted image 20220203130040.png | 600]]

- **Theo 5:**
![[Pasted image 20220203130253.png | 600]]
`k is the order`
Example:
![[Pasted image 20220203130429.png | 300]]

- **Theo 6:**
![[Pasted image 20220203130646.png | 600]]
Example:
![[Pasted image 20220203130753.png |500]]
![[Pasted image 20220203132017.png | 600]]

