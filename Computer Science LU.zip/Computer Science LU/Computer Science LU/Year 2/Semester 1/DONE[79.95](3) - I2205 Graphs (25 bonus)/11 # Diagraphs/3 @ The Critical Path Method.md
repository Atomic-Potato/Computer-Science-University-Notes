# Critical Path Method (`CPM`)
![[Pasted image 20220203132728.png | 600]]
`slack time is how much we can delay an activity, if its 0, then this activity must be done immediately`

## Computing EST and EFT
![[Pasted image 20220203133142.png | 600]]

## Computing LST and LFT
![[Pasted image 20220203133207.png | 600]]
`l for latest` 

# Definitions:
`slack time:` slack = LST(v) - EST(v)
`critical activity` slack time = 0
`critical path:` all of its activities are critical

