# Classifying edges
`Tree edge:` EXPLORED to UNVISITED
`Back edge:` EXPLORED to EXPLORED (keep track of the parent to not count bidirectional edges)
`Forward/Crorss edges from vertex with state:` EXPLORED to VISITED.

Example:
![[Pasted image 20220104160425.png | 700]]
![[Pasted image 20220104160529.png | 700]]

