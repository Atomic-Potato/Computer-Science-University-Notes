# SSSP on Weighted Graphs 
## Dijkstra Algorithm
![[Pasted image 20220206151609.png | 600]]
![[Dijkstra.cpp]]
# SSSP on Graph with Negative Weight Cycle
 Negative cycles are cycles in which the sum of the edges is negative, and if we reach it we will get stuck in an infinite loop

## Bellman-Ford Algorithm
 ![[Pasted image 20220206165735.png | 700]]
 
 **How to detect negative cycles**
 https://youtu.be/lyw4FaxrwHg