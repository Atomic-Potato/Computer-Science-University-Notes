Most array operations execute significantly faster than corresponding list operations.
*Theres a whole section in the `ipynb` file showcasing how much faster arrays are than lists, its right at the start of the section that has the same title of this note.*
