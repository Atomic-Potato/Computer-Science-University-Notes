# Visualizing Die-Roll Frequencies and Percentages

well tbh i cant be assed, just go check it out in the course `ipynb` file in case it got needed