**Front-end dev**
Front end dev takes care of all the visual aspects of the website (layout, navigation bar, etc.) its interactivity, and binds together all its elements.

**Back-end dev**
It takes care of the less visible tasks that ensure the website runs smoothly, such as managing the website's hosting services, database and applications

**Full-stack dev**
Its both