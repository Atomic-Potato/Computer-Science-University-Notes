# Product (Anti-cheat)
### What is an `Anti Cheat` ?
An `anti-cheat` is a piece of software used in the gaming industry, and specifically in online multiplayer games. It's main purpose is stop players from breaking into the games code and altering it to give them advantages against other players (like infinite ammo, infinite health, seeing other players through walls, etc.)

### What can we write in the product tab
**`The easy way`**
We can take an already existing anti cheat and see how it works and write about it and just alter its name. 
But isnt it stupid to write how youre anti cheat system works? making it a ton easier to crack ? 
Well yes thats why we will use a visual machine learning anti cheat that will learn from tons of clips of people hacking, so that the anti-cheat will know if some one is hacking based on visuals instead of algorithms to detect malfunction code.
We also have the advantage that there's already an anti cheat like that on the market and its pretty easy to understand how it works.

**`The hard way`**
Creating an anti cheat from scratch and trying to imagine how we would make an algorithm to defend against hackers, which is a quite time consuming.

**extra stuff:**
We can also talk about how the algorithms for cheating are evolving and current anti-cheat softwares are barely any effective against them. And how new ways are needed to defend against them.
So what i mean is talk about the new ways of cheating and how to defend against them with our anti-cheat software .

# Services (Finding weak spots and fixing them)
We basically take the game a game dev company has and we try to crack its code and find weak spots and fix them.
We can make multiple types of services like giving the company a couple of our developers to work for them. 
Or they could just give us their current build of the game and we will have a department in the company that is dedicated to finding these weak spots.
So either a big staff working or just giving the game company a couple of developers to help their coding team.

# Index
We basically have a smoll intro about the Anti-cheat product that we have and maybe about the our service as well.
So we could say that our anti-cheat uses machine learning to counter hackers and show a small example of it (i do have examples / videos and pictures)
And we definitely should example of companies that we partnered with in the past and that used / using our anti-cheat and benefited from our service.

# Blog
We could split the this into 3 parts
**Company's history**
We talk about how the company started from making small online indie games and their strong anti-cheat systems for them up to the current date and how they are hired for AAA companies
**Why Anti-Cheat is important for a game**
Talk about the ever expanding cheating and the new cheating techniques and how an online game will fail with out a good protection.
**How to work for our company**
Talk about the skills needed to be able to work with the company and how to achieve these skills and make like a little registering thingy where a person can try to get hired in the company

# About us
Talk about the company's partners more in depth plus where our services are provided and which platforms our anti cheat works on.
The reliability of our software and the efficiency of our services (we could use fake data).

# Contact us
This one should be almost the same for every topic