# Ex 1
Easy enough

# Ex 2
Easy enough

# Ex 3
![[Computer Science LU/Year 2/Semester 1/DONE[53.00](4) - I2202 Digital Fundamentals/Chapter 3 Logic Gates/Pictures/ex 3.jpg]]
# Ex 4

![[Computer Science LU/Year 2/Semester 1/DONE[53.00](4) - I2202 Digital Fundamentals/Chapter 3 Logic Gates/Pictures/ex 3.jpg | 400]]


# Ex 7
![[ex 7.jpg]]

# Ex 9
![[ex 9.jpg]]

# Ex 12
![[ex 12.jpg]]

# Ex 13
![[ex 13.jpg]]

# Ex 14
![[Ex 14.jpg]]

# Ex 15
![[Ex 15.jpg]]

# Ex 16
![[Pasted image 20220204172853.png | 600]]
# Ex 17
![[ex 17.jpg]]

# Ex 18
![[Pasted image 20220204173832.png]]
**`HUMONGOUS NOTE:`**
For a LED to light up it needs to have a high input from one side, so you see in the pic above we always have a constant input of 1V and the LED will only light up when we have LOW input from the NAND gate
# Ex 19
Nor gate connected like above