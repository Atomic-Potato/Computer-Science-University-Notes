# Exclusive OR Logic
![[Exclusive OR logic.jpg | 500]]

# Exclusive NOR Logic
its basically the inverse of `Exclusive OR`
![[Exclusive NOR logic.jpg | 500]]

# Implementing Combinational Logic
Implementing a `SOP` expression is done by first forming the `AND` terms; then the terms are `OR`ed together

# Universal Gates
`NAND` gates are universal
![[Universal Gates.jpg | 500]]
`NOR` gates are also universal
![[Universal Gates 2.jpg | 500]]

# Pulsed Waveforms
![[Pulsed Wavefroms.jpg | 500]]
![[Pulsed Wavefroms 2.jpg | 500]]