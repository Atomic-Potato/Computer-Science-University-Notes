# Starter Questions
## Ex 1
![[Pasted image 20220225174021.png | 600]]

## Ex 2
![[Pasted image 20220225174858.png | 600]]
![[Pasted image 20220225175017.png | 600]]

## Ex 3
![[Pasted image 20220225175545.png | 600]]
![[Pasted image 20220225180012.png | 600]]

## Ex 4
![[Pasted image 20220301151721.png | 600]]
![[Pasted image 20220301151746.png | 600]]

## `Ex 5`
![[Pasted image 20220301152552.png | 600]]
![[Pasted image 20220301152631.png | 400]]

## `Ex 6`
![[Pasted image 20220301153157.png | 600]]

## `Ex 7`
![[Pasted image 20220301154454.png | 600]]
![[Pasted image 20220301154937.png | 600]]
![[Pasted image 20220301155557.png | 600]]
![[Pasted image 20220301155625.png  | 600]]
![[Pasted image 20220301181837.png | 500]]

## `Ex 8`
![[Pasted image 20220301182318.png | 600]]
![[Pasted image 20220301182808.png | 600]]
![[Pasted image 20220301183301.png | 600]]

# Ex 9
![[Pasted image 20220301184832.png | 600]]
