# Joint Probability Density
The joint probability distribution function (pdf) of a couple of random variables X and Y is a function f(x,y) having the following properties:
![[Pasted image 20220204191906.png | 700]]
