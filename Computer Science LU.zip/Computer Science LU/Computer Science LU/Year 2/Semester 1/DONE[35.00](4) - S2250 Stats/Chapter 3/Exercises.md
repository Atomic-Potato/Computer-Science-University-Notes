# Extra
## Ex 1
![[Pasted image 20220122175323.png | 600]]
