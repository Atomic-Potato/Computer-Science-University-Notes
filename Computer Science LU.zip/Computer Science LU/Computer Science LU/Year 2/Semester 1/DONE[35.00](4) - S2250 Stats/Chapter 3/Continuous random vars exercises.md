# Ex 1
`a`
![[Pasted image 20220205181726.png | 600]]

`b`
![[Pasted image 20220205182325.png | 600]]

`c`
![[Pasted image 20220205182551.png ]]

`d`
![[Pasted image 20220205182737.png | 500]]


# Ex 4
![[Pasted image 20220205183551.png | 800]]
