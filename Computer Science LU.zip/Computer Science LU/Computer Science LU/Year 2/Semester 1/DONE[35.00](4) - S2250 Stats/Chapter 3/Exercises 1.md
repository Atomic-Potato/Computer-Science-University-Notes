# Extra
## Ex 1
![[Pasted image 20220201213221.png | 600]]
![[Pasted image 20220201213139.png | 600]]
![[Pasted image 20220201213927.png | 600]]
![[Pasted image 20220201213953.png | 600]]
