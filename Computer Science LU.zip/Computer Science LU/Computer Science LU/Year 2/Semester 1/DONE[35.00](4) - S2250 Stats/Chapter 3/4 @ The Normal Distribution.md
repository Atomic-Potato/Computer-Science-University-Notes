A random variable X with pdf
![[Pasted image 20220201200355.png | 500]]
is called normal distribution with parameter u and sigma, denoted N(u, sigma^2)

![[Pasted image 20220201201137.png | 600]]

# The standard normal distribution
 ![[Pasted image 20220201203002.png | 650]]

# The standard normal table
 ![[Pasted image 20220201203852.png]]
 ![[Pasted image 20220201203818.png]]
**`NOTES:`**
- THAT IF YOU GET A z GREATER THAN 3.99 THEN THE ANSWER FOR THE PROBABILITY IS "1"
- if you get a Z less than 0 then the probability will be 0
- P(y < X < z) = P(Z) - P(y)
- Remember that the value youre getting from the table is the area to the left and if you want something with probability greater than some value you just reduce the result from 1
# Transformation of normal variables
This operation transforms and curve into the standard curve, and by doing so we can find the area that we want using the standard normal table instead
 ![[Pasted image 20220201204955.png | 750]]
We can do the same thing but in reverse
![[Pasted image 20220201204915.png | 750]]
We dont also have to just transform to the normal, we can transform any curve to another by just transforming the first to normal and the normal to second