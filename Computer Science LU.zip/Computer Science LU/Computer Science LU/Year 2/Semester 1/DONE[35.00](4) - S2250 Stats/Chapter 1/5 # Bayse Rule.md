# Total probability formula
![[total proba formula.jpg]]

# Bayes Rule
When the second action depends on the first action, we use `Bayes` rule

![[bayes rule.jpg]]