# Main
# Ex 1
![[ex 1 a.jpg | 300]]
![[ex 1 b.jpg | 500]]
![[ex 1 c.jpg | 500]]

# Ex 4
![[Computer Science LU/Year 2/Semester 1/DONE[35.00](4) - S2250 Stats/Chapter 2/Exercises/Pictures/ex 4.jpg | 500]]

# Ex 5
![[ex 5.jpg | 500]]
![[ex 5 second method.jpg | 500]]
# Ex 8
![[Ex 8.jpg | 500]]

# Ex 9
(This is one of the series you took last year)
![[Ex 9 a.jpg | 500]]
# Extra
## Ex 1
Three fair dice are rolled repeatedly until the sum of their up faces exceed 16. Find the expected number of rolling needed:

You have 2 outcomes, 666 (1 time) or 665 (3 times)
The the probability of success is:
$p = \frac{4}{6^3}$
And so the expected value is:
$E(X) = \frac{6^3}{4}$

## Ex 2
A certain basketball player makes a foul shot with probability 0.45. Find the probability that his second basket occur between the eight and the tenth shot.

We have 0.55 in and 0.45 out.
![[Extra 2 1.jpg | 400]]
Let  X be the nb of shots until the second basked occur
NB(r=2, p=0.55)
![[Ex 2 2.jpg | 400]]

